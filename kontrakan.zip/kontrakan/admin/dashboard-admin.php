<?php
// Sambungkan ke database
require_once '../config/db.php';
session_start();

if (!isset($_SESSION['admin_user_id'])) {
    header("Location: ../public/login.php");
    exit();
}

// Ambil data user
$user_id = $_SESSION['admin_user_id'];

// Hitung jumlah booking yang aktif
$query_booking = "SELECT COUNT(*) as total_booking FROM booking WHERE status_booking IN ('menunggu', 'terkonfirmasi')";
$result_booking = mysqli_query($conn, $query_booking);
$row_booking = mysqli_fetch_assoc($result_booking);
$total_booking = $row_booking['total_booking'];

// Hitung jumlah kamar terisi (kontrakan yang statusnya tidak tersedia)
$query_kamar_terisi = "SELECT COUNT(*) as total_kamar_terisi FROM data_kontrakan WHERE status = 'tidak tersedia'";
$result_kamar_terisi = mysqli_query($conn, $query_kamar_terisi);
$row_kamar_terisi = mysqli_fetch_assoc($result_kamar_terisi);
$total_kamar_terisi = $row_kamar_terisi['total_kamar_terisi'];

// Hitung jumlah kontrakan tersedia
$query_kontrakan_tersedia = "SELECT COUNT(*) as total_kontrakan_tersedia FROM data_kontrakan WHERE status = 'tersedia'";
$result_kontrakan_tersedia = mysqli_query($conn, $query_kontrakan_tersedia);
$row_kontrakan_tersedia = mysqli_fetch_assoc($result_kontrakan_tersedia);
$total_kontrakan_tersedia = $row_kontrakan_tersedia['total_kontrakan_tersedia'];

// Hitung jumlah penyewa (pengguna dengan sewa aktif)
$query_penyewa = "SELECT COUNT(DISTINCT id_penyewa) as total_penyewa FROM penyewaan WHERE status_sewa = 'aktif'";
$result_penyewa = mysqli_query($conn, $query_penyewa);
$row_penyewa = mysqli_fetch_assoc($result_penyewa);
$total_penyewa = $row_penyewa['total_penyewa'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin | H. Sagio</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- CSS Custom -->
    <link rel="stylesheet" href="../assets/css/dashboard-admin.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
</head>
<body>
    <div class="main-container">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content" id="main-content">
            <div class="content-header">
                <h1>Dashboard</h1>
                <div class="user-info">
                    <span>Selamat datang, Admin!</span>
                </div>
            </div>
            
            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-icon booking">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $total_booking; ?></h3>
                        <p>Booking Aktif</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon terisi">
                        <i class="fas fa-door-closed"></i>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $total_kamar_terisi; ?></h3>
                        <p>Kamar Terisi</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon tersedia">
                        <i class="fas fa-home"></i>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $total_kontrakan_tersedia; ?></h3>
                        <p>Kontrakan Tersedia</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon penyewa">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-details">
                        <h3><?php echo $total_penyewa; ?></h3>
                        <p>Penyewa</p>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-welcome">
                <h2>Selamat datang di Panel Admin H. Sagio</h2>
                <p>Gunakan panel admin ini untuk mengelola data kontrakan, penyewa, dan transaksi penyewaan. Silahkan pilih menu di sidebar untuk mengakses fitur yang Anda butuhkan.</p>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="../assets/js/dashboard-admin.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
        const logoutLink = document.getElementById('logout-link');

        if (logoutLink) {
            logoutLink.addEventListener('click', function (e) {
                e.preventDefault(); // cegah langsung logout

                Swal.fire({
                    title: 'Yakin ingin logout?',
                    text: "Kamu akan keluar dari sesi ini.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, logout',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = logoutLink.href; // redirect ke logout.php
                    }
                });
            });
        }
    });

    </script>
</body>
</html>