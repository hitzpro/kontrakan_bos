<?php
// Start the session
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_user_id'])) {
    header("Location: login-admin.php");
    exit();
}

// Include database connection
require_once '../config/db.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kontrakan yang Disewa</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/sewa_kontrakan.css">
</head>
<body>
    <div class="main-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content" id="main-content">
            <div class="content-header">
                <h1>Data Kontrakan yang Disewa</h1>
                <div class="search-container">
                    <input type="text" id="searchInput" placeholder="Cari data...">
                    <button id="searchButton"><i class="fas fa-search"></i></button>
                </div>
            </div>
            
            <div class="table-container">
                <div class="table-wrapper">
                    <table id="sewaTable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Kontrakan</th>
                                <th>Nama Penyewa</th>
                                <th>Tanggal Mulai</th>
                                <th>Tanggal Selesai</th>
                                <th>Durasi</th>
                                <th>Total Bayar</th>
                                <th>Status Pembayaran</th>
                                <th>Status Sewa</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="sewaTableBody">
                            <!-- Data will be loaded here -->
                        </tbody>
                    </table>
                </div>
                
                <div class="pagination" id="pagination">
                    <!-- Pagination will be generated here -->
                </div>
            </div>
        </div>
    </div>

    <?php include '../logic/admin/load_data.php'; ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script src="../assets/js/sewa_kontrakan.js"></script>
</body>
</html>