<?php
require_once '../config/db.php';
session_start();

// Function to get all kontrakan data
function getAllKontrakan() {
    global $conn;

    $sql = "SELECT dk.*, GROUP_CONCAT(fk.foto) AS foto_lain 
            FROM data_kontrakan dk
            LEFT JOIN foto_kontrakan fk ON dk.id = fk.id_kontrakan
            GROUP BY dk.id
            ORDER BY dk.id DESC";

    $result = mysqli_query($conn, $sql);
    $data = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Ubah foto_lain jadi array
            $row['foto_lain'] = !empty($row['foto_lain']) ? explode(',', $row['foto_lain']) : [];
            $data[] = $row;
        }
    }

    return $data;
}


// Function to get pemilik kontrakan for dropdown
// function getAllPemilik() {
//     global $conn;
//     $sql = "SELECT nama_kontrakan, kontak_pemilik FROM data_kontrakan ORDER BY nama_kontrakan ASC";
//     $result = mysqli_query($conn, $sql);
//     $data = [];

//     if ($result && mysqli_num_rows($result) > 0) {
//         while ($row = mysqli_fetch_assoc($result)) {
//             $data[] = $row;
//         }
//     }

//     return $data;
// }




// Delete kontrakan
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    
    // Get foto info first
    $foto_query = "SELECT foto FROM data_kontrakan WHERE id = '$id'";
    $result = mysqli_query($conn, $foto_query);
    $row = mysqli_fetch_assoc($result);
    $foto = $row['foto'];
    
    // Delete the record
    $sql = "DELETE FROM data_kontrakan WHERE id = '$id'";
    
    if (mysqli_query($conn, $sql)) {
        // Delete the image file if exists
        if (!empty($foto)) {
            $file_path = "../uploads/kontrakan/" . $foto;
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        
        $_SESSION['message'] = "Data kontrakan berhasil dihapus";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Gagal menghapus data: " . mysqli_error($conn);
        $_SESSION['message_type'] = "error";
    }
    
    header("Location: data_kontrakan.php");
    exit();
}

// Get all kontrakan data
$kontrakan_data = getAllKontrakan();
// $pemilik_data = getAllPemilik();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kontrakan - Admin Panel</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/data_kontrakan.css">
    <!-- Bootstrap 5 CSS -->
    <style>
        .sidebar-menu ul{
                padding: 0 !important;
            }
        p{
            margin:0;
        }
    </style>

</head>
<body>
<div class="main-container">
    <?php include 'sidebar.php'; ?>

    <div class="main-content" id="main-content">
        <div class="page-header">
            <div class="title">
                <h1>Data Kontrakan</h1>

                <div class="breadcrumb">
                    <span>Dashboard</span>
                    <span class="divider">/</span>
                    <span class="active">Data kontrakan</span>
                </div>
            </div>
            <button class="btn btn-primary" id="btnTambahKontrakan">
                <i class="fas fa-plus"></i> Tambah Kontrakan
            </button>
        </div>

        <div class="filter-section">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Cari kontrakan...">
            </div>
            <div class="filter-options">
                <select id="filterStatus">
                    <option value="">Semua Status</option>
                    <option value="tersedia">Tersedia</option>
                    <option value="tidak tersedia">Tidak Tersedia</option>
                </select>
                <select id="filterTipe">
                    <option value="">Semua Tipe</option>
                    <option value="bulanan">Bulanan</option>
                    <option value="tahunan">Tahunan</option>
                </select>
            </div>
        </div>

        <div class="kontrakan-container">
            <?php if (empty($kontrakan_data)): ?>
                <div class="empty-state">
                    <i class="fas fa-home"></i>
                    <p>Belum ada data kontrakan</p>
                    <button class="btn btn-primary" id="btnEmptyAdd">
                        <i class="fas fa-plus"></i> Tambah Kontrakan Sekarang
                    </button>
                </div>
            <?php else: ?>
                <?php foreach($kontrakan_data as $kontrakan): ?>
                    <div class="kontrakan-card" data-id="<?= $kontrakan['id'] ?>" data-nama="<?= $kontrakan['nama_kontrakan'] ?>" data-status="<?= $kontrakan['status'] ?>" data-tipe="<?= $kontrakan['tipe_kontrakan'] ?>">
                        <div class="kontrakan-image">
                            <?php if (!empty($kontrakan['foto'])): ?>
                                <img src="../images/kontrakan/<?= $kontrakan['foto'] ?>" alt="<?= $kontrakan['nama_kontrakan'] ?>">
                            <?php else: ?>
                                <div class="no-image">
                                    <i class="fas fa-home"></i>
                                </div>
                            <?php endif; ?>
                            <div class="kontrakan-badges">
                                <span class="badge badge-<?= $kontrakan['status'] == 'tersedia' ? 'success' : 'danger' ?>">
                                    <?= $kontrakan['status'] == 'tersedia' ? 'Tersedia' : 'Tidak Tersedia' ?>
                                </span>
                                <span class="badge badge-info">
                                    <?= $kontrakan['tipe_kontrakan'] == 'bulanan' ? 'Bulanan' : 'Tahunan' ?>
                                </span>
                            </div>
                        </div>
                        <div class="kontrakan-details">
                            <h3 class="kontrakan-title"><?= $kontrakan['nama_kontrakan'] ?></h3>
                            <p class="kontrakan-location">
                                <i class="fas fa-map-marker-alt"></i> <?= $kontrakan['lokasi'] ?>
                            </p>
                            <p class="kontrakan-price">
                                <i class="fas fa-tag"></i> Rp <?= number_format($kontrakan['harga'], 0, ',', '.') ?>/<?= $kontrakan['tipe_kontrakan'] == 'bulanan' ? 'bulan' : 'tahun' ?>
                            </p>
                            <p class="kontrakan-owner">
                                <i class="fas fa-user"></i> <?= $kontrakan['nama_pemilik'] ?? 'Tidak ada pemilik' ?>
                            </p>
                            <div class="kontrakan-actions">
                                <button class="btn-view" onclick="viewKontrakan(<?= $kontrakan['id'] ?>)">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn-edit" onclick="editKontrakan(<?= $kontrakan['id'] ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn-delete" onclick="deleteKontrakan(<?= $kontrakan['id'] ?>, '<?= $kontrakan['nama_kontrakan'] ?>')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Mobile List View -->
        <div class="kontrakan-list">
            <?php if (empty($kontrakan_data)): ?>
                <div class="empty-state">
                    <i class="fas fa-home"></i>
                    <p>Belum ada data kontrakan</p>
                    <button class="btn btn-primary" id="btnEmptyAddMobile">
                        <i class="fas fa-plus"></i> Tambah Kontrakan
                    </button>
                </div>
            <?php else: ?>
                <?php foreach($kontrakan_data as $kontrakan): ?>
                    <div class="kontrakan-list-item" data-id="<?= $kontrakan['id'] ?>" data-nama="<?= $kontrakan['nama_kontrakan'] ?>" data-status="<?= $kontrakan['status'] ?>" data-tipe="<?= $kontrakan['tipe_kontrakan'] ?>">
                        <div class="list-item-content">
                            <h3 class="list-item-title"><?= $kontrakan['nama_kontrakan'] ?></h3>
                            <span class="badge badge-<?= $kontrakan['status'] == 'tersedia' ? 'success' : 'danger' ?>">
                                <?= $kontrakan['status'] == 'tersedia' ? 'Tersedia' : 'Tidak Tersedia' ?>
                            </span>
                        </div>
                        <div class="list-item-actions">
                            <button class="btn-view" onclick="viewKontrakan(<?= $kontrakan['id'] ?>)">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn-edit" onclick="editKontrakan(<?= $kontrakan['id'] ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-delete" onclick="deleteKontrakan(<?= $kontrakan['id'] ?>, '<?= $kontrakan['nama_kontrakan'] ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="modal" id="kontrakanModal">
  <div class="modal-content">
    <div class="modal-header">
      <h2 id="modalTitle">Tambah Kontrakan Baru</h2>
      <span class="close-modal">&times;</span>
    </div>
    <div class="modal-body">
      <form id="kontrakanForm" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" id="formAction" value="add">
        <input type="hidden" name="id" id="kontrak_id">

        <!-- Input Fields -->
        <div class="form-group">
          <label for="nama_kontrakan">Nama Kontrakan</label>
          <input type="text" name="nama_kontrakan" id="nama_kontrakan" required>
        </div>
        <div class="form-group">
          <label for="lokasi">Lokasi</label>
          <input type="text" name="lokasi" id="lokasi" required>
        </div>
        <div class="form-group">
          <label for="alamat_lengkap">Alamat Lengkap</label>
          <textarea name="alamat_lengkap" id="alamat_lengkap" rows="3" required></textarea>
        </div>
        <div class="form-group">
          <label for="harga">Harga (Rp)</label>
          <input type="number" name="harga" id="harga" required>
        </div>
        <div class="form-row">
          <div class="form-group half">
            <label for="luas">Luas</label>
            <input type="text" name="luas" id="luas" placeholder="Contoh: 5x6 m²" required>
          </div>
          <div class="form-group half">
            <label for="tipe_kontrakan">Tipe Kontrakan</label>
            <select name="tipe_kontrakan" id="tipe_kontrakan" required>
              <option value="bulanan">Bulanan</option>
              <option value="tahunan">Tahunan</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label for="fasilitas">Fasilitas</label>
          <textarea name="fasilitas" id="fasilitas" rows="3" placeholder="Pisahkan dengan koma"></textarea>
        </div>
        <div class="form-group">
          <label for="deskripsi">Deskripsi</label>
          <textarea name="deskripsi" id="deskripsi" rows="4"></textarea>
        </div>
        <div class="form-group">
          <label for="status">Status</label>
          <select name="status" id="status" required>
            <option value="tersedia">Tersedia</option>
            <option value="tidak tersedia">Tidak Tersedia</option>
          </select>
        </div>
        <div class="form-group">
          <label for="kontak_pemilik">Kontak Pemilik</label>
          <input type="text" name="kontak_pemilik" id="kontak_pemilik">
        </div>

        <!-- Foto Utama -->
        <div class="form-group">
          <label for="foto">Foto Utama Kontrakan</label>
          <input type="file" name="foto" id="foto" accept="image/*" class="form-control">
          <div id="fotoUtamaPreview" class="mt-2"></div>
        </div>

        <!-- Foto Tambahan -->
        <div class="form-group mt-3">
          <label for="foto_lain">Foto Tambahan (maks 5 foto, max 5MB per file)</label>
          <input type="file" name="foto_lain[]" id="foto_lain" class="form-control" accept="image/*" multiple>
          <div id="previewGrid" class="d-flex flex-wrap gap-2 mt-2"></div>

          <!-- Carousel Preview -->
          <div id="carouselPreview" class="carousel slide mt-3" data-bs-ride="carousel" style="display:none;">
            <div class="carousel-inner" id="carouselImages"></div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselPreview" data-bs-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselPreview" data-bs-slide="next">
              <span class="carousel-control-next-icon"></span>
            </button>
          </div>
          <div id="fotoLainPreview" class="d-flex gap-2 flex-wrap mt-3"></div>
        </div>

        <!-- Tombol Aksi -->
        <div class="form-actions">
          <button type="button" class="btn btn-secondary" id="btnCancel">Batal</button>
          <button type="submit" class="btn btn-primary" id="btnSubmit">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>

    <!-- Modal untuk View Detail Kontrakan -->
    <div class="modal" id="viewModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="viewModalTitle">Detail Kontrakan</h2>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body" id="viewModalBody">
                <div class="detail-container">
                    <div class="detail-image">
                        <div id="view-image"></div>
                    </div>
                    <div class="detail-content">
                        <div class="detail-header">
                            <h3 id="view-nama"></h3>
                            <div class="detail-badges">
                                <span id="view-status" class="badge"></span>
                                <span id="view-tipe" class="badge badge-info"></span>
                            </div>
                        </div>
                        <div class="detail-info">
                            <div class="info-item">
                                <i class="fas fa-map-marker-alt"></i>
                                <span id="view-lokasi"></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-home"></i>
                                <span id="view-luas"></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-tag"></i>
                                <span id="view-harga"></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-user"></i>
                                <span id="view-pemilik"></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-phone"></i>
                                <span id="view-kontak"></span>
                            </div>
                        </div>
                        <div class="detail-section">
                            <h4>Alamat Lengkap</h4>
                            <p id="view-alamat"></p>
                        </div>
                        <div class="detail-section">
                            <h4>Deskripsi</h4>
                            <p id="view-deskripsi"></p>
                        </div>
                        <div class="detail-section">
                            <h4>Fasilitas</h4>
                            <div id="view-fasilitas" class="fasilitas-list"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary close-view">Tutup</button>
            </div>
        </div>
    </div>
</div>

    <!-- JavaScript -->
    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="../assets/js/data_kontrakan.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script>
// JavaScript Internal - Hanya untuk fitur tambahan yang tidak ada di external JS
document.addEventListener('DOMContentLoaded', function() {
  // Show Toast from sessionStorage (khusus untuk after page reload)
  var msg = sessionStorage.getItem('message');
  var type = sessionStorage.getItem('message_type');
  if (msg) {
    showToastInternal(msg, type || 'info');
    sessionStorage.removeItem('message');
    sessionStorage.removeItem('message_type');
  }

  // Setup foto_lain input handler (fitur tambahan yang tidak ada di external)
  var fotoLainInput = document.getElementById('foto_lain');
  if (fotoLainInput) {
    fotoLainInput.addEventListener('change', handleFotoLainChangeInternal);
  }

  // Setup foto utama preview (jika belum ada di external)
  var fotoUtamaInput = document.getElementById('foto');
  if (fotoUtamaInput) {
    fotoUtamaInput.addEventListener('change', handleFotoUtamaPreview);
  }
});

// Constants untuk foto tambahan
var MAX_FILES_INTERNAL = 5;
var MAX_SIZE_INTERNAL = 5 * 1024 * 1024; // 5MB

// Handle Preview Foto Utama
function handleFotoUtamaPreview(e) {
  var file = e.target.files[0];
  var preview = document.getElementById('fotoUtamaPreview');
  
  if (!preview) return;
  
  if (file) {
    if (!file.type.startsWith('image/')) {
      alert('Hanya file gambar yang diperbolehkan.');
      e.target.value = '';
      return;
    }
    
    if (file.size > MAX_SIZE_INTERNAL) {
      alert('Ukuran file maksimal 5MB.');
      e.target.value = '';
      return;
    }
    
    var reader = new FileReader();
    reader.onload = function(e) {
      preview.innerHTML = '<img src="' + e.target.result + '" class="img-thumbnail" style="width:150px;height:150px;object-fit:cover;">';
    };
    reader.readAsDataURL(file);
  } else {
    preview.innerHTML = '';
  }
}

// Handle Preview Foto Lain (Multiple files)
function handleFotoLainChangeInternal(e) {
  var input = e.target;
  var files = Array.from(input.files);
  var existingCount = document.querySelectorAll('#previewGrid .position-relative').length;

  // Validasi jumlah file
  if (existingCount + files.length > MAX_FILES_INTERNAL) {
    alert('Maksimal ' + MAX_FILES_INTERNAL + ' foto. Saat ini sudah ada ' + existingCount + ' foto.');
    input.value = '';
    return;
  }

  // Reset containers
  var previewGrid = document.getElementById('previewGrid');
  var carouselInner = document.getElementById('carouselImages');
  var carouselPreview = document.getElementById('carouselPreview');
  
  if (files.length > 0) {
    // Clear existing previews untuk file baru
    if (previewGrid) previewGrid.innerHTML = '';
    if (carouselInner) carouselInner.innerHTML = '';
  }

  files.forEach(function(file, index) {
    // Validasi file
    if (!file.type.startsWith('image/')) {
      alert('Hanya file gambar yang diperbolehkan.');
      input.value = '';
      return;
    }
    
    if (file.size > MAX_SIZE_INTERNAL) {
      alert('Ukuran file maksimal 5MB per file.');
      input.value = '';
      return;
    }

    var reader = new FileReader();
    reader.onload = function(e) {
      var imgSrc = e.target.result;
      addFotoToCarouselInternal(imgSrc, index === 0);
      addFotoToGridInternal(imgSrc, index, function() {
        // Remove file from input when deleted
        removeFileFromInput(input, index);
      });
    };
    reader.readAsDataURL(file);
  });

  // Show carousel jika ada file
  if (files.length > 0 && carouselPreview) {
    carouselPreview.style.display = 'block';
  }
}

// Add to Carousel
function addFotoToCarouselInternal(imgSrc, isActive) {
  var carouselInner = document.getElementById('carouselImages');
  if (!carouselInner) return;

  var item = document.createElement('div');
  item.className = 'carousel-item' + (isActive ? ' active' : '');
  item.innerHTML = '<img src="' + imgSrc + '" class="d-block w-100" style="height:300px;object-fit:cover;">';
  
  carouselInner.appendChild(item);
}

// Add to Thumbnail Grid
function addFotoToGridInternal(imgSrc, index, onDelete) {
  var previewGrid = document.getElementById('previewGrid');
  if (!previewGrid) return;

  var thumb = document.createElement('div');
  thumb.className = 'position-relative me-2 mb-2';
  thumb.style.width = '100px';
  thumb.setAttribute('data-index', index);

  thumb.innerHTML = 
    '<img src="' + imgSrc + '" class="img-thumbnail" style="width:100px;height:100px;object-fit:cover;">' +
    '<button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 rounded-circle" style="padding:2px 6px;">&times;</button>';

  var deleteBtn = thumb.querySelector('button');
  deleteBtn.addEventListener('click', function() {
    if (confirm('Hapus foto ini?')) {
      thumb.remove();
      removeFromCarouselInternal(imgSrc);
      onDelete();
    }
  });

  previewGrid.appendChild(thumb);
}

// Remove from Carousel
function removeFromCarouselInternal(imgSrc) {
  var items = document.querySelectorAll('#carouselImages .carousel-item');
  var removedActive = false;
  
  items.forEach(function(item) {
    var img = item.querySelector('img');
    if (img && img.src === imgSrc) {
      if (item.classList.contains('active')) {
        removedActive = true;
      }
      item.remove();
    }
  });

  var remaining = document.querySelectorAll('#carouselImages .carousel-item');
  if (remaining.length === 0) {
    document.getElementById('carouselPreview').style.display = 'none';
  } else if (removedActive && remaining.length > 0) {
    remaining[0].classList.add('active');
  }
}

// Remove file from input (untuk new files)
function removeFileFromInput(input, indexToRemove) {
  var dt = new DataTransfer();
  var files = Array.from(input.files);
  
  files.forEach(function(file, index) {
    if (index !== indexToRemove) {
      dt.items.add(file);
    }
  });
  
  input.files = dt.files;
}

// Enhanced editKontrakan function dengan foto tambahan
function editKontrakanEnhanced(id) {
  // Show loading
  if (typeof Swal !== 'undefined') {
    Swal.fire({
      title: 'Memuat Data...',
      allowOutsideClick: false,
      didOpen: function() { Swal.showLoading(); }
    });
  }

  fetch('../logic/admin/get_kontrakan.php?action=get_kontrakan&id=' + id)
    .then(function(response) {
      return response.json();
    })
    .then(function(result) {
      if (typeof Swal !== 'undefined') Swal.close();
      
      if (result.status === 'success') {
        populateModalWithPhotos(result.data);
        document.getElementById('modalTitle').textContent = 'Edit Kontrakan';
        document.getElementById('kontrakanModal').style.display = 'block';
      } else {
        showToastInternal('Gagal memuat data: ' + result.message, 'error');
      }
    })
    .catch(function(error) {
      if (typeof Swal !== 'undefined') Swal.close();
      console.error('Error:', error);
      showToastInternal('Terjadi kesalahan saat memuat data', 'error');
    });
}

// Populate Modal dengan foto tambahan
function populateModalWithPhotos(data) {
  // Set form action
  document.getElementById('formAction').value = 'update';
  document.getElementById('kontrak_id').value = data.id;

  // Fill basic fields
  var fields = ['nama_kontrakan', 'lokasi', 'alamat_lengkap', 'harga', 'luas', 'tipe_kontrakan', 'status', 'fasilitas', 'deskripsi', 'kontak_pemilik'];
  
  fields.forEach(function(fieldId) {
    var element = document.getElementById(fieldId);
    if (element && data.hasOwnProperty(fieldId)) {
      element.value = data[fieldId] || '';
    }
  });

  // Handle foto utama preview
  var fotoUtamaPreview = document.getElementById('fotoUtamaPreview');
  if (fotoUtamaPreview) {
    if (data.foto && data.foto.trim()) {
      fotoUtamaPreview.innerHTML = '<img src="../images/kontrakan/' + data.foto + '" class="img-thumbnail" style="width:150px;height:150px;object-fit:cover;">';
    } else {
      fotoUtamaPreview.innerHTML = '';
    }
  }

  // Reset preview containers untuk foto tambahan
  var carouselImages = document.getElementById('carouselImages');
  var previewGrid = document.getElementById('previewGrid');
  var carouselPreview = document.getElementById('carouselPreview');
  
  if (carouselImages) carouselImages.innerHTML = '';
  if (previewGrid) previewGrid.innerHTML = '';
  if (carouselPreview) carouselPreview.style.display = 'none';

  // Show existing additional photos
  if (Array.isArray(data.foto_lain)) {
    var validPhotos = data.foto_lain.filter(function(f) {
      return f && f.trim();
    });
    
    validPhotos.forEach(function(foto, i) {
      var imgSrc = '../images/kontrakan/' + foto;
      addFotoToCarouselInternal(imgSrc, i === 0);
      addExistingToGridInternal(foto, data.id);
    });
    
    if (validPhotos.length > 0 && carouselPreview) {
      carouselPreview.style.display = 'block';
    }
  }

  // Reset file inputs
  var fotoInput = document.getElementById('foto');
  var fotoLainInput = document.getElementById('foto_lain');
  if (fotoInput) fotoInput.value = '';
  if (fotoLainInput) fotoLainInput.value = '';
}

// Add existing photo to grid dengan tombol delete
function addExistingToGridInternal(fotoName, kontrakanId) {
  var previewGrid = document.getElementById('previewGrid');
  if (!previewGrid) return;

  var thumb = document.createElement('div');
  thumb.className = 'position-relative me-2 mb-2';
  thumb.style.width = '100px';

  var imgSrc = '../images/kontrakan/' + fotoName;
  thumb.innerHTML = 
    '<img src="' + imgSrc + '" class="img-thumbnail" style="width:100px;height:100px;object-fit:cover;">' +
    '<button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 rounded-circle" ' +
    'style="padding:2px 6px;" data-foto="' + fotoName + '" data-kontrakan-id="' + kontrakanId + '">&times;</button>';

  var deleteBtn = thumb.querySelector('button');
  deleteBtn.addEventListener('click', function() {
    if (confirm('Apakah Anda yakin ingin menghapus foto ini?')) {
      deleteFotoExistingInternal(this.dataset.foto, this.dataset.kontrakanId, thumb);
    }
  });

  previewGrid.appendChild(thumb);
}

// Delete existing photo
function deleteFotoExistingInternal(fotoName, kontrakanId, thumbElement) {
  var formData = new FormData();
  formData.append('action', 'delete_foto');
  formData.append('foto', fotoName);
  formData.append('kontrakan_id', kontrakanId);

  fetch('../logic/admin/delete_foto.php', {
    method: 'POST',
    body: formData
  })
    .then(function(res) {
      return res.json();
    })
    .then(function(data) {
      if (data.status === 'success') {
        thumbElement.remove();
        removeFromCarouselInternal('../images/kontrakan/' + fotoName);
        showToastInternal('Foto berhasil dihapus', 'success');
      } else {
        showToastInternal(data.message || 'Gagal menghapus foto', 'error');
      }
    })
    .catch(function(err) {
      console.error(err);
      showToastInternal('Terjadi kesalahan saat menghapus foto', 'error');
    });
}

// Toast function khusus internal (tidak konflik dengan external)
function showToastInternal(message, type) {
  type = type || 'info';
  
  if (typeof Swal !== 'undefined') {
    var icon = type === 'success' ? 'success' : type === 'error' ? 'error' : 'info';
    
    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: icon,
      title: message,
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true
    });
  } else {
    // Fallback
    alert(message);
  }
}

// Override editKontrakan global function untuk menggunakan enhanced version
if (typeof window.editKontrakan === 'undefined') {
  window.editKontrakan = editKontrakanEnhanced;
}
</script>




</body>
</html>