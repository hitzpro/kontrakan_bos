<?php
require_once '../config/db.php';
session_start();

// Function to get all kontrakan data
function getAllKontrakan() {
    global $conn;

    $sql = "SELECT * FROM data_kontrakan ORDER BY id DESC";
    $result = mysqli_query($conn, $sql);
    $data = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
    }

    return $data;
}


// Function to get pemilik kontrakan for dropdown
// function getAllPemilik() {
//     global $conn;
//     $sql = "SELECT nama_kontrakan, kontak_pemilik FROM data_kontrakan ORDER BY nama_kontrakan ASC";
//     $result = mysqli_query($conn, $sql);
//     $data = [];

//     if ($result && mysqli_num_rows($result) > 0) {
//         while ($row = mysqli_fetch_assoc($result)) {
//             $data[] = $row;
//         }
//     }

//     return $data;
// }




// Delete kontrakan
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    
    // Get foto info first
    $foto_query = "SELECT foto FROM data_kontrakan WHERE id = '$id'";
    $result = mysqli_query($conn, $foto_query);
    $row = mysqli_fetch_assoc($result);
    $foto = $row['foto'];
    
    // Delete the record
    $sql = "DELETE FROM data_kontrakan WHERE id = '$id'";
    
    if (mysqli_query($conn, $sql)) {
        // Delete the image file if exists
        if (!empty($foto)) {
            $file_path = "../uploads/kontrakan/" . $foto;
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        
        $_SESSION['message'] = "Data kontrakan berhasil dihapus";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Gagal menghapus data: " . mysqli_error($conn);
        $_SESSION['message_type'] = "error";
    }
    
    header("Location: data_kontrakan.php");
    exit();
}

// Get all kontrakan data
$kontrakan_data = getAllKontrakan();
// $pemilik_data = getAllPemilik();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kontrakan - Admin Panel</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/data_kontrakan.css">
</head>
<body>
<div class="main-container">
    <?php include 'sidebar.php'; ?>

    <div class="main-content" id="main-content">
        <div class="page-header">
            <div class="title">
                <h1>Data Kontrakan</h1>

                <div class="breadcrumb">
                    <span>Dashboard</span>
                    <span class="divider">/</span>
                    <span class="active">Data kontrakan</span>
                </div>
            </div>
            <button class="btn btn-primary" id="btnTambahKontrakan">
                <i class="fas fa-plus"></i> Tambah Kontrakan
            </button>
        </div>

        <div class="filter-section">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Cari kontrakan...">
            </div>
            <div class="filter-options">
                <select id="filterStatus">
                    <option value="">Semua Status</option>
                    <option value="tersedia">Tersedia</option>
                    <option value="tidak tersedia">Tidak Tersedia</option>
                </select>
                <select id="filterTipe">
                    <option value="">Semua Tipe</option>
                    <option value="bulanan">Bulanan</option>
                    <option value="tahunan">Tahunan</option>
                </select>
            </div>
        </div>

        <div class="kontrakan-container">
            <?php if (empty($kontrakan_data)): ?>
                <div class="empty-state">
                    <i class="fas fa-home"></i>
                    <p>Belum ada data kontrakan</p>
                    <button class="btn btn-primary" id="btnEmptyAdd">
                        <i class="fas fa-plus"></i> Tambah Kontrakan Sekarang
                    </button>
                </div>
            <?php else: ?>
                <?php foreach($kontrakan_data as $kontrakan): ?>
                    <div class="kontrakan-card" data-id="<?= $kontrakan['id'] ?>" data-nama="<?= $kontrakan['nama_kontrakan'] ?>" data-status="<?= $kontrakan['status'] ?>" data-tipe="<?= $kontrakan['tipe_kontrakan'] ?>">
                        <div class="kontrakan-image">
                            <?php if (!empty($kontrakan['foto'])): ?>
                                <img src="../images/kontrakan/<?= $kontrakan['foto'] ?>" alt="<?= $kontrakan['nama_kontrakan'] ?>">
                            <?php else: ?>
                                <div class="no-image">
                                    <i class="fas fa-home"></i>
                                </div>
                            <?php endif; ?>
                            <div class="kontrakan-badges">
                                <span class="badge badge-<?= $kontrakan['status'] == 'tersedia' ? 'success' : 'danger' ?>">
                                    <?= $kontrakan['status'] == 'tersedia' ? 'Tersedia' : 'Tidak Tersedia' ?>
                                </span>
                                <span class="badge badge-info">
                                    <?= $kontrakan['tipe_kontrakan'] == 'bulanan' ? 'Bulanan' : 'Tahunan' ?>
                                </span>
                            </div>
                        </div>
                        <div class="kontrakan-details">
                            <h3 class="kontrakan-title"><?= $kontrakan['nama_kontrakan'] ?></h3>
                            <p class="kontrakan-location">
                                <i class="fas fa-map-marker-alt"></i> <?= $kontrakan['lokasi'] ?>
                            </p>
                            <p class="kontrakan-price">
                                <i class="fas fa-tag"></i> Rp <?= number_format($kontrakan['harga'], 0, ',', '.') ?>/<?= $kontrakan['tipe_kontrakan'] == 'bulanan' ? 'bulan' : 'tahun' ?>
                            </p>
                            <p class="kontrakan-owner">
                                <i class="fas fa-user"></i> <?= $kontrakan['nama_pemilik'] ?? 'Tidak ada pemilik' ?>
                            </p>
                            <div class="kontrakan-actions">
                                <button class="btn-view" onclick="viewKontrakan(<?= $kontrakan['id'] ?>)">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn-edit" onclick="editKontrakan(<?= $kontrakan['id'] ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn-delete" onclick="deleteKontrakan(<?= $kontrakan['id'] ?>, '<?= $kontrakan['nama_kontrakan'] ?>')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Mobile List View -->
        <div class="kontrakan-list">
            <?php if (empty($kontrakan_data)): ?>
                <div class="empty-state">
                    <i class="fas fa-home"></i>
                    <p>Belum ada data kontrakan</p>
                    <button class="btn btn-primary" id="btnEmptyAddMobile">
                        <i class="fas fa-plus"></i> Tambah Kontrakan
                    </button>
                </div>
            <?php else: ?>
                <?php foreach($kontrakan_data as $kontrakan): ?>
                    <div class="kontrakan-list-item" data-id="<?= $kontrakan['id'] ?>" data-nama="<?= $kontrakan['nama_kontrakan'] ?>" data-status="<?= $kontrakan['status'] ?>" data-tipe="<?= $kontrakan['tipe_kontrakan'] ?>">
                        <div class="list-item-content">
                            <h3 class="list-item-title"><?= $kontrakan['nama_kontrakan'] ?></h3>
                            <span class="badge badge-<?= $kontrakan['status'] == 'tersedia' ? 'success' : 'danger' ?>">
                                <?= $kontrakan['status'] == 'tersedia' ? 'Tersedia' : 'Tidak Tersedia' ?>
                            </span>
                        </div>
                        <div class="list-item-actions">
                            <button class="btn-view" onclick="viewKontrakan(<?= $kontrakan['id'] ?>)">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn-edit" onclick="editKontrakan(<?= $kontrakan['id'] ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-delete" onclick="deleteKontrakan(<?= $kontrakan['id'] ?>, '<?= $kontrakan['nama_kontrakan'] ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal untuk Tambah/Edit Kontrakan -->
    <div class="modal" id="kontrakanModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Tambah Kontrakan Baru</h2>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body">
                <form id="kontrakanForm" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" id="formAction" value="add">
                    <input type="hidden" name="id" id="kontrak_id">
                    
                    <div class="form-group">
                        <label for="nama_kontrakan">Nama Kontrakan</label>
                        <input type="text" name="nama_kontrakan" id="nama_kontrakan" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="lokasi">Lokasi</label>
                        <input type="text" name="lokasi" id="lokasi" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="alamat_lengkap">Alamat Lengkap</label>
                        <textarea name="alamat_lengkap" id="alamat_lengkap" rows="3" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="harga">Harga (Rp)</label>
                        <input type="number" name="harga" id="harga" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group half">
                            <label for="luas">Luas</label>
                            <input type="text" name="luas" id="luas" placeholder="Contoh: 5x6 m²" required>
                        </div>
                        
                        <div class="form-group half">
                            <label for="tipe_kontrakan">Tipe Kontrakan</label>
                            <select name="tipe_kontrakan" id="tipe_kontrakan" required>
                                <option value="bulanan">Bulanan</option>
                                <option value="tahunan">Tahunan</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="fasilitas">Fasilitas</label>
                        <textarea name="fasilitas" id="fasilitas" rows="3" placeholder="Masukkan fasilitas yang tersedia, pisahkan dengan koma"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <textarea name="deskripsi" id="deskripsi" rows="4"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="status" required>
                            <option value="tersedia">Tersedia</option>
                            <option value="tidak tersedia">Tidak Tersedia</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="kontak_pemilik">Kontak Pemilik</label>
                        <input type="text" name="kontak_pemilik" id="kontak_pemilik">
                    </div>
                    
                    <div class="form-group">
                        <label for="foto">Foto Kontrakan</label>
                        <div class="file-upload">
                            <input type="file" name="foto" id="foto" accept="image/*">
                            <label for="foto" class="file-label">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <span id="file-name">Pilih Foto</span>
                            </label>
                        </div>
                        <div id="image-preview" class="hidden"></div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary" id="btnCancel">Batal</button>
                        <button type="submit" class="btn btn-primary" id="btnSubmit">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal untuk View Detail Kontrakan -->
    <div class="modal" id="viewModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="viewModalTitle">Detail Kontrakan</h2>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body" id="viewModalBody">
                <div class="detail-container">
                    <div class="detail-image">
                        <div id="view-image"></div>
                    </div>
                    <div class="detail-content">
                        <div class="detail-header">
                            <h3 id="view-nama"></h3>
                            <div class="detail-badges">
                                <span id="view-status" class="badge"></span>
                                <span id="view-tipe" class="badge badge-info"></span>
                            </div>
                        </div>
                        <div class="detail-info">
                            <div class="info-item">
                                <i class="fas fa-map-marker-alt"></i>
                                <span id="view-lokasi"></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-home"></i>
                                <span id="view-luas"></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-tag"></i>
                                <span id="view-harga"></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-user"></i>
                                <span id="view-pemilik"></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-phone"></i>
                                <span id="view-kontak"></span>
                            </div>
                        </div>
                        <div class="detail-section">
                            <h4>Alamat Lengkap</h4>
                            <p id="view-alamat"></p>
                        </div>
                        <div class="detail-section">
                            <h4>Deskripsi</h4>
                            <p id="view-deskripsi"></p>
                        </div>
                        <div class="detail-section">
                            <h4>Fasilitas</h4>
                            <div id="view-fasilitas" class="fasilitas-list"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary close-view">Tutup</button>
            </div>
        </div>
    </div>
</div>

    <!-- JavaScript -->
    <script src="../assets/js/data_kontrakan.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script>
        // Handle session messages with SweetAlert
        <?php if(isset($_SESSION['message'])): ?>
            showToast('<?= $_SESSION['message'] ?>', '<?= $_SESSION['message_type'] ?>');
            <?php 
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            ?>
        <?php endif; ?>
    </script>
</body>
</html>