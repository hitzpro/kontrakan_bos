<?php
// Include database connection
include_once '../config/db.php';
session_start();

// Function to get count of rentals by status
function getStatusCount($status) {
    global $conn;
    // Use prepared statement to prevent SQL injection
    $query = "SELECT COUNT(*) as count FROM penyewaan WHERE status_sewa = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $status);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    return $row['count'];
}

// Get counts for each status
$menungguCount = getStatusCount('menunggu konfirmasi');
$aktifCount = getStatusCount('aktif');
$selesaiCount = getStatusCount('selesai');
$dibatalkanCount = getStatusCount('dibatalkan');

// Pagination settings
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Filter settings
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Build WHERE clause securely
$whereConditions = [];
$params = [];
$types = "";

if (!empty($statusFilter)) {
    $whereConditions[] = "p.status_sewa = ?";
    $params[] = $statusFilter;
    $types .= "s";
}

if (!empty($searchTerm)) {
    $whereConditions[] = "(dk.nama_kontrakan LIKE ? OR pg.nama_pengguna LIKE ?)";
    $searchWildcard = "%$searchTerm%";
    $params[] = $searchWildcard;
    $params[] = $searchWildcard;
    $types .= "ss";
}

$whereClause = !empty($whereConditions) ? "WHERE " . implode(" AND ", $whereConditions) : "";

// Query untuk total records (paginasi)
$countQuery = "SELECT COUNT(*) as total 
               FROM penyewaan p 
               LEFT JOIN data_kontrakan dk ON p.id_kontrakan = dk.id
               LEFT JOIN pengguna pg ON p.id_penyewa = pg.id 
               $whereClause";

$countStmt = mysqli_prepare($conn, $countQuery);
if (!empty($params)) {
    mysqli_stmt_bind_param($countStmt, $types, ...$params);
}
mysqli_stmt_execute($countStmt);
$countResult = mysqli_stmt_get_result($countStmt);
$totalRecords = mysqli_fetch_assoc($countResult)['total'];
$totalPages = ceil($totalRecords / $limit);
mysqli_stmt_close($countStmt);

// Query utama
$query = "SELECT p.id, p.id_penyewa, p.id_kontrakan, p.tanggal_mulai, p.tanggal_selesai,
                 p.durasi_sewa, p.total_bayar, p.status_pembayaran, p.status_sewa, 
                 p.metode_pembayaran, p.kode_pembayaran, p.keterangan, 
                 dk.nama_kontrakan, pg.nama_pengguna 
          FROM penyewaan p
          LEFT JOIN data_kontrakan dk ON p.id_kontrakan = dk.id
          LEFT JOIN pengguna pg ON p.id_penyewa = pg.id 
          $whereClause
          ORDER BY p.id DESC
          LIMIT ?, ?";

// Add pagination parameters
$params[] = $start;
$params[] = $limit;
$types .= "ii";

// Execute the final query
$stmt = mysqli_prepare($conn, $query);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Check for any server-side message to display
$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$messageType = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : '';

// Clear the session message after retrieving
if(isset($_SESSION['message'])) {
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Penyewaan</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/penyewaan.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="main-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content" id="main-content">
            <h1>Manajemen Penyewaan</h1>
            
            <!-- Stats Container -->
            <div class="stats-container">
                <div class="stat-card waiting">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-info">
                        <h3>Menunggu Konfirmasi</h3>
                        <p><?php echo $menungguCount; ?></p>
                    </div>
                </div>
                <div class="stat-card active">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-info">
                        <h3>Aktif</h3>
                        <p><?php echo $aktifCount; ?></p>
                    </div>
                </div>
                <div class="stat-card completed">
                    <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
                    <div class="stat-info">
                        <h3>Selesai</h3>
                        <p><?php echo $selesaiCount; ?></p>
                    </div>
                </div>
                <div class="stat-card cancelled">
                    <div class="stat-icon"><i class="fas fa-ban"></i></div>
                    <div class="stat-info">
                        <h3>Dibatalkan</h3>
                        <p><?php echo $dibatalkanCount; ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Search and Filter Container -->
            <div class="controls-container">
                <div class="search-container">
                    <input type="text" id="searchInput" placeholder="Cari penyewa atau kontrakan..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                    <button id="searchButton"><i class="fas fa-search"></i></button>
                </div>
                
                <div class="filter-container">
                    <select id="statusFilter">
                        <option value="">Semua Status</option>
                        <option value="menunggu konfirmasi" <?php echo $statusFilter == 'menunggu konfirmasi' ? 'selected' : ''; ?>>Menunggu Konfirmasi</option>
                        <option value="aktif" <?php echo $statusFilter == 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                        <option value="selesai" <?php echo $statusFilter == 'selesai' ? 'selected' : ''; ?>>Selesai</option>
                        <option value="dibatalkan" <?php echo $statusFilter == 'dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                    </select>
                </div>
            </div>
            
            <!-- Table Container -->
            <div class="table-container">
                <table>
                    <!-- Tabel Header -->
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Penyewa</th>
                            <th>Kontrakan</th>
                            <th>Tanggal Mulai</th>
                            <th>Tanggal Selesai</th>
                            <th>Total Bayar</th>
                            <th>Status Pembayaran</th>
                            <th>Status Sewa</th>
                            <th>Aksi</th>
                            <th>Reupload Bukti</th>
                        </tr>
                    </thead>

                    <!-- Tabel Body -->
                    <tbody id="penyewaanTable">
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($row['id']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['nama_pengguna']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['nama_kontrakan']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['tanggal_mulai']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['tanggal_selesai']) . '</td>';
                            echo '<td>Rp ' . number_format($row['total_bayar'], 0, ',', '.') . '</td>';
                            echo '<td><span class="status-badge ' . strtolower(str_replace(' ', '-', $row['status_pembayaran'])) . '">' . htmlspecialchars($row['status_pembayaran']) . '</span></td>';
                            echo '<td><span class="status-badge ' . strtolower(str_replace(' ', '-', $row['status_sewa'])) . '">' . htmlspecialchars($row['status_sewa']) . '</span></td>';

                            // Kolom Aksi
                            echo '<td class="action-buttons">';
                            echo '<button class="btn-detail" data-id="' . htmlspecialchars($row['id']) . '"><i class="fas fa-eye"></i></button>';
                            if ($row['status_sewa'] === 'menunggu konfirmasi') {
                                echo '<button class="btn-approve" data-id="' . htmlspecialchars($row['id']) . '"><i class="fas fa-check"></i></button>';
                                echo '<button class="btn-reject" data-id="' . htmlspecialchars($row['id']) . '"><i class="fas fa-times"></i></button>';
                            } elseif ($row['status_sewa'] === 'aktif') {
                                echo '<button class="btn-complete" data-id="' . htmlspecialchars($row['id']) . '"><i class="fas fa-flag-checkered"></i></button>';
                            }
                            echo '</td>';

                            // Kolom Reupload Bukti
                            echo '<td>';
                            $status = strtolower($row['status_sewa']);
                            $metode = strtolower($row['metode_pembayaran']);
                            if ($metode === 'transfer' && $status !== 'selesai' && $status !== 'dibatalkan') {
                                echo '<button class="btn-reupload" data-id="' . htmlspecialchars($row['id']) . '" 
                                        data-penyewa="' . htmlspecialchars($row['nama_pengguna']) . '" 
                                        data-kontrakan="' . htmlspecialchars($row['nama_kontrakan']) . '" 
                                        title="Minta Upload Ulang Bukti">
                                        <i class="fas fa-upload"></i></button>';
                            } else {
                                echo '<span class="text-muted">-</span>';
                            }
                            echo '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="10" class="no-data">Tidak ada data penyewaan</td></tr>';
                    }
                    ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="pagination">
                <?php
                if ($totalPages > 1) {
                    echo '<ul>';
                    
                    // Previous button
                    if ($page > 1) {
                        echo '<li><a href="#" data-page="' . ($page - 1) . '"><i class="fas fa-chevron-left"></i></a></li>';
                    } else {
                        echo '<li class="disabled"><span><i class="fas fa-chevron-left"></i></span></li>';
                    }
                    
                    // Page numbers
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $startPage + 4);
                    
                    if ($startPage > 1) {
                        echo '<li><a href="#" data-page="1">1</a></li>';
                        if ($startPage > 2) {
                            echo '<li class="dots"><span>...</span></li>';
                        }
                    }
                    
                    for ($i = $startPage; $i <= $endPage; $i++) {
                        if ($i == $page) {
                            echo '<li class="active"><span>' . $i . '</span></li>';
                        } else {
                            echo '<li><a href="#" data-page="' . $i . '">' . $i . '</a></li>';
                        }
                    }
                    
                    if ($endPage < $totalPages) {
                        if ($endPage < $totalPages - 1) {
                            echo '<li class="dots"><span>...</span></li>';
                        }
                        echo '<li><a href="#" data-page="' . $totalPages . '">' . $totalPages . '</a></li>';
                    }
                    
                    // Next button
                    if ($page < $totalPages) {
                        echo '<li><a href="#" data-page="' . ($page + 1) . '"><i class="fas fa-chevron-right"></i></a></li>';
                    } else {
                        echo '<li class="disabled"><span><i class="fas fa-chevron-right"></i></span></li>';
                    }
                    
                    echo '</ul>';
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Server message for toast -->
    <div id="serverMessage" 
         data-message="<?php echo htmlspecialchars($message); ?>" 
         data-type="<?php echo htmlspecialchars($messageType); ?>">
    </div>
    
    <script src="../assets/js/penyewaan.js"></script>
    <script src="../assets/js/sidebar.js"></script>
</body>
</html>