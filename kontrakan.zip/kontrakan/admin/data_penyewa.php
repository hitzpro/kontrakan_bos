<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['admin_user_id'])) {
    header('Location: ../public/login.php');
    exit();
}

// Debug: Tambahkan logging untuk melihat semua booking
error_log("=== DEBUG DATA PENGGUNA ===");

// Cek semua booking untuk debugging
$debugQuery = "SELECT b.id, b.id_penyewa, b.status_booking, b.metode_pembayaran, 
               b.tanggal_booking, p.nama_pengguna 
               FROM booking b 
               JOIN pengguna p ON b.id_penyewa = p.id 
               ORDER BY b.tanggal_booking DESC LIMIT 20";
$debugResult = $conn->query($debugQuery);
if ($debugResult) {
    while ($debugRow = $debugResult->fetch_assoc()) {
        error_log("Booking ID: {$debugRow['id']}, User: {$debugRow['nama_pengguna']}, Status: {$debugRow['status_booking']}, Metode: {$debugRow['metode_pembayaran']}, Tanggal: {$debugRow['tanggal_booking']}");
    }
}

// Pagination setup
$limit = 10;
$bookingPage = isset($_GET['booking_page']) ? (int)$_GET['booking_page'] : 1;
$sewaPage = isset($_GET['sewa_page']) ? (int)$_GET['sewa_page'] : 1;
$bookingOffset = ($bookingPage - 1) * $limit;
$sewaOffset = ($sewaPage - 1) * $limit;

// Get total counts for pagination - PERBAIKAN QUERY
// Untuk booking: ambil semua booking yang belum selesai prosesnya
$totalBookingQuery = "SELECT COUNT(DISTINCT b.id) as total 
                      FROM pengguna p 
                      JOIN booking b ON p.id = b.id_penyewa 
                      WHERE b.status_booking IN ('belum bayar', 'belum lunas', 'menunggu')
                      AND NOT EXISTS (
                          SELECT 1 FROM penyewaan ps 
                          WHERE ps.id_booking = b.id 
                          AND ps.status_sewa IN ('aktif', 'selesai')
                      )";

// Untuk sewa: ambil penyewaan yang aktif
$totalSewaQuery = "SELECT COUNT(DISTINCT ps.id) as total 
                   FROM pengguna p 
                   JOIN penyewaan ps ON p.id = ps.id_penyewa 
                   WHERE ps.status_sewa = 'aktif'";

$totalBooking = $conn->query($totalBookingQuery)->fetch_assoc()['total'];
$totalSewa = $conn->query($totalSewaQuery)->fetch_assoc()['total'];

error_log("Total Booking: $totalBooking, Total Sewa: $totalSewa");

// Get booking data - PERBAIKAN QUERY untuk mencegah duplikasi dengan penyewaan
$bookingQuery = "SELECT p.id, p.nama_pengguna, p.email, p.no_telepon, 
                 b.id as id_booking, b.tanggal_mulai, b.tanggal_selesai, 
                 b.total_bayar, b.status_booking, b.metode_pembayaran, b.tanggal_booking
                 FROM pengguna p
                 JOIN booking b ON p.id = b.id_penyewa
                 WHERE b.status_booking IN ('belum bayar', 'belum lunas', 'menunggu')
                 AND NOT EXISTS (
                     SELECT 1 FROM penyewaan ps 
                     WHERE ps.id_booking = b.id 
                     AND ps.status_sewa IN ('aktif', 'selesai')
                 )
                 ORDER BY b.tanggal_booking DESC
                 LIMIT $limit OFFSET $bookingOffset";
$bookingData = $conn->query($bookingQuery);

error_log("Booking Query: $bookingQuery");

// Get sewa data - penyewaan yang sedang aktif
$sewaQuery = "SELECT p.id, p.nama_pengguna, p.email, p.no_telepon, 
              ps.id as id_penyewaan, ps.tanggal_mulai, ps.tanggal_selesai, 
              ps.durasi_sewa, ps.total_bayar, ps.status_pembayaran
              FROM pengguna p
              JOIN penyewaan ps ON p.id = ps.id_penyewa
              WHERE ps.status_sewa = 'aktif'
              ORDER BY ps.tanggal_mulai DESC
              LIMIT $limit OFFSET $sewaOffset";
$sewaData = $conn->query($sewaQuery);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengguna - Sistem Kontrakan</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/data_pengguna.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        td a[onclick^="kirimPesanWhatsApp"] {
            display: inline-block;
            background-color: #25D366; /* WhatsApp green */
            color: white;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 14px;
            text-decoration: none;
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        td a[onclick^="kirimPesanWhatsApp"]:hover {
            background-color: #1EBE5D;
            transform: scale(1.03);
        }

        td a[onclick^="kirimPesanWhatsApp"]:active {
            transform: scale(0.98);
        }
    </style>
</head>
<body>
    <div class="main-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content" id="main-content">
            <div class="content-header">
                <h1>Data Penyewa</h1>
                <div class="breadcrumb">
                    <span>Dashboard</span>
                    <span class="divider">/</span>
                    <span class="active">Data Penyewa</span>
                </div>
            </div>
            
            <div class="content-body">
                <div class="card">
                    <div class="card-header">
                        <div class="tabs">
                            <button class="tab-button active" data-tab="booking">Booking <span class="badge"><?= $totalBooking ?></span></button>
                            <button class="tab-button" data-tab="sewa">Sewa <span class="badge"><?= $totalSewa ?></span></button>
                        </div>
                        <div class="search-box">
                            <input type="text" id="searchInput" placeholder="Cari pengguna...">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <!-- Booking Tab Content -->
                        <div id="bookingTab" class="tab-content active">
                            <div class="table-responsive">
                                <table id="bookingTable">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Pengguna</th>
                                            <th>Email</th>
                                            <th>No. Telepon</th>
                                            <th>Tanggal Mulai</th>
                                            <th>Tanggal Selesai</th>
                                            <th>Total Bayar</th>
                                            <th>Metode Pembayaran</th>
                                            <th>Status Booking</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = $bookingOffset + 1;
                                        if ($bookingData && $bookingData->num_rows > 0):
                                            while ($row = $bookingData->fetch_assoc()): 
                                        ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= htmlspecialchars($row['nama_pengguna']) ?></td>
                                            <td><?= htmlspecialchars($row['email']) ?></td>
                                            <td>
                                                <a href="#" onclick="kirimPesanWhatsApp('<?= htmlspecialchars($row['no_telepon']) ?>')" title="Kirim Pesan ke Whatsapp">
                                                    <i class="fab fa-whatsapp"></i> <?= htmlspecialchars($row['no_telepon']) ?>
                                                </a>
                                            </td>
                                            <td><?= date('d M Y', strtotime($row['tanggal_mulai'])) ?></td>
                                            <td><?= date('d M Y', strtotime($row['tanggal_selesai'])) ?></td>
                                            <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                            <td><?= htmlspecialchars($row['metode_pembayaran'] ?: 'N/A') ?></td>
                                            <td>
                                                <span class="status-badge <?= 
                                                    $row['status_booking'] == 'belum bayar' ? 'warning' : 
                                                    ($row['status_booking'] == 'menunggu' ? 'info' : 'warning') 
                                                ?>">
                                                    <?= 
                                                        $row['status_booking'] == 'belum bayar' ? 'Belum Bayar' : 
                                                        ($row['status_booking'] == 'belum lunas' ? 'Belum Lunas' : 
                                                        ($row['status_booking'] == 'menunggu' ? 'Menunggu Konfirmasi' : 
                                                        ucfirst($row['status_booking']))) 
                                                    ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php 
                                            endwhile;
                                        else: 
                                        ?>
                                        <tr>
                                            <td colspan="9" class="text-center">Tidak ada data booking</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Pagination untuk booking -->
                            <div class="pagination">
                                <?php
                                $totalBookingPages = ceil($totalBooking / $limit);
                                if ($totalBookingPages > 1):
                                ?>
                                <div class="pagination-controls">
                                    <?php if ($bookingPage > 1): ?>
                                        <a href="?booking_page=<?= $bookingPage - 1 ?>" class="pagination-button"><i class="fas fa-chevron-left"></i></a>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = 1; $i <= $totalBookingPages; $i++): ?>
                                        <a href="?booking_page=<?= $i ?>" class="pagination-button <?= $i == $bookingPage ? 'active' : '' ?>"><?= $i ?></a>
                                    <?php endfor; ?>
                                    
                                    <?php if ($bookingPage < $totalBookingPages): ?>
                                        <a href="?booking_page=<?= $bookingPage + 1 ?>" class="pagination-button"><i class="fas fa-chevron-right"></i></a>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Sewa Tab Content -->
                        <div id="sewaTab" class="tab-content">
                            <div class="table-responsive">
                                <table id="sewaTable">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Pengguna</th>
                                            <th>Email</th>
                                            <th>No. Telepon</th>
                                            <th>Tanggal Mulai</th>
                                            <th>Tanggal Selesai</th>
                                            <th>Durasi (Bulan)</th>
                                            <th>Total Bayar</th>
                                            <th>Status Pembayaran</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = $sewaOffset + 1;
                                        if ($sewaData && $sewaData->num_rows > 0):
                                            while ($row = $sewaData->fetch_assoc()): 
                                        ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= htmlspecialchars($row['nama_pengguna']) ?></td>
                                            <td><?= htmlspecialchars($row['email']) ?></td>
                                            <td>
                                                <a href="#" onclick="kirimPesanWhatsApp('<?= htmlspecialchars($row['no_telepon']) ?>')" title="Kirim Pesan ke Whatsapp">
                                                    <i class="fab fa-whatsapp"></i> <?= htmlspecialchars($row['no_telepon']) ?>
                                                </a>
                                            </td>
                                            <td><?= date('d M Y', strtotime($row['tanggal_mulai'])) ?></td>
                                            <td><?= date('d M Y', strtotime($row['tanggal_selesai'])) ?></td>
                                            <td><?= $row['durasi_sewa'] ?></td>
                                            <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                            <td>
                                                <span class="status-badge <?= $row['status_pembayaran'] == 'lunas' ? 'success' : 'warning' ?>">
                                                    <?= $row['status_pembayaran'] == 'lunas' ? 'Lunas' : 'Belum Bayar' ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php 
                                            endwhile;
                                        else: 
                                        ?>
                                        <tr>
                                            <td colspan="9" class="text-center">Tidak ada data penyewaan aktif</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Pagination untuk sewa -->
                            <div class="pagination">
                                <?php
                                $totalSewaPages = ceil($totalSewa / $limit);
                                if ($totalSewaPages > 1):
                                ?>
                                <div class="pagination-controls">
                                    <?php if ($sewaPage > 1): ?>
                                        <a href="?sewa_page=<?= $sewaPage - 1 ?>" class="pagination-button"><i class="fas fa-chevron-left"></i></a>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = 1; $i <= $totalSewaPages; $i++): ?>
                                        <a href="?sewa_page=<?= $i ?>" class="pagination-button <?= $i == $sewaPage ? 'active' : '' ?>"><?= $i ?></a>
                                    <?php endfor; ?>
                                    
                                    <?php if ($sewaPage < $totalSewaPages): ?>
                                        <a href="?sewa_page=<?= $sewaPage + 1 ?>" class="pagination-button"><i class="fas fa-chevron-right"></i></a>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/data_pengguna.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script>
    // Debug: Monitor perubahan data
    console.log('=== DATA PENGGUNA DEBUG ===');
    console.log('Total Booking:', <?= $totalBooking ?>);
    console.log('Total Sewa:', <?= $totalSewa ?>);
    console.log('Current URL:', window.location.href);
    
    // Monitor jika ada AJAX calls yang mengubah status
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
        console.log('FETCH Call:', args[0]);
        return originalFetch.apply(this, arguments);
    };
    
    const originalXHR = window.XMLHttpRequest;
    window.XMLHttpRequest = function() {
        const xhr = new originalXHR();
        const originalOpen = xhr.open;
        xhr.open = function(method, url) {
            console.log('XHR Call:', method, url);
            return originalOpen.apply(this, arguments);
        };
        return xhr;
    };

    function kirimPesanWhatsApp(nomor) {
        const pesanOptions = {
            "1": "Halo, terima kasih telah melakukan pemesanan. Kami akan segera memproses pesanan Anda.",
            "2": "Mohon maaf, bukti pembayaran yang Anda kirimkan belum lengkap. Silakan kirim ulang dengan lengkap ya.",
            "3": "Kami ingin mengonfirmasi data Anda. Mohon cek kembali informasi yang telah Anda berikan.",
        };

        Swal.fire({
            title: 'Pilih Pesan untuk Dikirim',
            input: 'select',
            inputOptions: {
                '1': 'Terima kasih telah memesan',
                '2': 'Bukti pembayaran belum lengkap',
                '3': 'Konfirmasi data'
            },
            inputPlaceholder: 'Pilih jenis pesan',
            showCancelButton: true,
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                const pesan = pesanOptions[result.value];

                Swal.fire({
                    title: 'Edit Pesan (opsional)',
                    input: 'textarea',
                    inputLabel: 'Pesan WhatsApp',
                    inputValue: pesan,
                    inputAttributes: {
                        'aria-label': 'Tulis pesan Anda di sini'
                    },
                    showCancelButton: true,
                    confirmButtonText: 'Kirim ke WhatsApp'
                }).then((pesanResult) => {
                    if (pesanResult.isConfirmed) {
                        const pesanFinal = encodeURIComponent(pesanResult.value);
                        const nomorBersih = nomor.replace(/\D/g, ''); // hilangkan +, spasi, dll
                        const linkWA = `https://wa.me/${nomorBersih}?text=${pesanFinal}`;
                        window.open(linkWA, '_blank');
                    }
                });
            }
        });
    }
    </script>
</body>
</html>