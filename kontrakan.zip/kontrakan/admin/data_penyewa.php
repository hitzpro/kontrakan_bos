<?php
require_once '../config/db.php';
session_start();

// Check if user is logged in and has admin role
if (!isset($_SESSION['admin_user_id'])) {
    header('Location: ../public/login.php');
    exit();
}

// Pagination setup
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Get total counts for pagination
$totalBookingQuery = "SELECT COUNT(DISTINCT b.id) as total 
                      FROM pengguna p 
                      JOIN booking b ON p.id = b.id_penyewa 
                      WHERE b.status_booking = 'menunggu'";
$totalSewaQuery = "SELECT COUNT(DISTINCT ps.id) as total 
                   FROM pengguna p 
                   JOIN penyewaan ps ON p.id = ps.id_penyewa 
                   WHERE ps.status_sewa = 'aktif'";

$totalBooking = $conn->query($totalBookingQuery)->fetch_assoc()['total'];
$totalSewa = $conn->query($totalSewaQuery)->fetch_assoc()['total'];

// Get booking data
$bookingQuery = "SELECT p.id, p.nama_pengguna, p.email, p.no_telepon, 
                 b.id as id_booking, b.tanggal_mulai, b.tanggal_selesai, 
                 b.total_bayar, b.status_booking, b.metode_pembayaran
                 FROM pengguna p
                 JOIN booking b ON p.id = b.id_penyewa
                 WHERE b.status_booking = 'menunggu'
                 LIMIT $limit OFFSET $offset";
$bookingData = $conn->query($bookingQuery);

// Get sewa data (unchanged)
$sewaQuery = "SELECT p.id, p.nama_pengguna, p.email, p.no_telepon, 
              ps.id as id_penyewaan, ps.tanggal_mulai, ps.tanggal_selesai, 
              ps.durasi_sewa, ps.total_bayar, ps.status_pembayaran
              FROM pengguna p
              JOIN penyewaan ps ON p.id = ps.id_penyewa
              WHERE ps.status_sewa = 'aktif'
              LIMIT $limit OFFSET $offset";
$sewaData = $conn->query($sewaQuery);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengguna - Sistem Kontrakan</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/data_pengguna.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        td a[onclick^="kirimPesanWhatsApp"] {
            display: inline-block;
            background-color: #25D366; /* WhatsApp green */
            color: white;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 14px;
            text-decoration: none;
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        td a[onclick^="kirimPesanWhatsApp"]:hover {
            background-color: #1EBE5D;
            transform: scale(1.03);
        }

        td a[onclick^="kirimPesanWhatsApp"]:active {
            transform: scale(0.98);
        }
        </style>

</head>
<body>
    <div class="main-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content" id="main-content">
            <div class="content-header">
                <h1>Data Penyewa</h1>
                <div class="breadcrumb">
                    <span>Dashboard</span>
                    <span class="divider">/</span>
                    <span class="active">Data Penyewa</span>
                </div>
            </div>
            
            <div class="content-body">
                <div class="card">
                    <div class="card-header">
                        <div class="tabs">
                            <button class="tab-button active" data-tab="booking">Booking <span class="badge"><?= $totalBooking ?></span></button>
                            <button class="tab-button" data-tab="sewa">Sewa <span class="badge"><?= $totalSewa ?></span></button>
                        </div>
                        <div class="search-box">
                            <input type="text" id="searchInput" placeholder="Cari pengguna...">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <!-- Booking Tab Content -->
                        <div id="bookingTab" class="tab-content active">
                            <div class="table-responsive">
                                <table id="bookingTable">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Pengguna</th>
                                            <th>Email</th>
                                            <th>No. Telepon</th>
                                            <th>Tanggal Mulai</th>
                                            <th>Tanggal Selesai</th>
                                            <th>Total Bayar</th>
                                            <th>Metode Pembayaran</th>
                                            <th>Status Pembayaran</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = $offset + 1;
                                        while ($row = $bookingData->fetch_assoc()): 
                                        ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= htmlspecialchars($row['nama_pengguna']) ?></td>
                                            <td><?= htmlspecialchars($row['email']) ?></td>
                                            <td>
                                                <a href="#" onclick="kirimPesanWhatsApp('<?= $row['no_telepon'] ?>')" title="Kirim Pesan ke Whatsapp">
                                                    <i class="fab fa-whatsapp"></i> <?= htmlspecialchars($row['no_telepon']) ?>
                                                </a>
                                            </td>


                                            <td><?= date('d M Y', strtotime($row['tanggal_mulai'])) ?></td>
                                            <td><?= date('d M Y', strtotime($row['tanggal_selesai'])) ?></td>
                                            <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                            <td><?= htmlspecialchars($row['metode_pembayaran'] ?: 'N/A') ?></td>
                                            <td>
                                                <span class="status-badge <?= $row['status_booking'] == 'belum bayar' ? 'warning' : 'success' ?>">
                                                    <?= $row['status_booking'] == 'belum bayar' ? 'Belum Bayar' : 'Pembayaran telah dikonfirmasi user' ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="pagination">
                                <?php
                                $totalPages = ceil($totalBooking / $limit);
                                if ($totalPages > 1):
                                ?>
                                <div class="pagination-controls">
                                    <?php if ($page > 1): ?>
                                        <a href="?page=<?= $page - 1 ?>" class="pagination-button"><i class="fas fa-chevron-left"></i></a>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                        <a href="?page=<?= $i ?>" class="pagination-button <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $totalPages): ?>
                                        <a href="?page=<?= $page + 1 ?>" class="pagination-button"><i class="fas fa-chevron-right"></i></a>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Sewa Tab Content -->
                        <div id="sewaTab" class="tab-content">
                            <div class="table-responsive">
                                <table id="sewaTable">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Pengguna</th>
                                            <th>Email</th>
                                            <th>No. Telepon</th>
                                            <th>Tanggal Mulai</th>
                                            <th>Tanggal Selesai</th>
                                            <th>Durasi (Bulan)</th>
                                            <th>Total Bayar</th>
                                            <th>Status Pembayaran</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = $offset + 1;
                                        while ($row = $sewaData->fetch_assoc()): 
                                        ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= htmlspecialchars($row['nama_pengguna']) ?></td>
                                            <td><?= htmlspecialchars($row['email']) ?></td>
                                            <td>
                                                <a href="#" onclick="kirimPesanWhatsApp('<?= $row['no_telepon'] ?>')" title="Kirim Pesan ke Whatsapp">
                                                    <i class="fab fa-whatsapp"></i> <?= htmlspecialchars($row['no_telepon']) ?>
                                                </a>
                                            </td>

                                            <td><?= date('d M Y', strtotime($row['tanggal_mulai'])) ?></td>
                                            <td><?= date('d M Y', strtotime($row['tanggal_selesai'])) ?></td>
                                            <td><?= $row['durasi_sewa'] ?></td>
                                            <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                            <td>
                                                <span class="status-badge <?= $row['status_pembayaran'] == 'lunas' ? 'success' : 'warning' ?>">
                                                    <?= $row['status_pembayaran'] == 'lunas' ? 'Lunas' : 'Belum Bayar' ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="pagination">
                                <?php
                                $totalPages = ceil($totalSewa / $limit);
                                if ($totalPages > 1):
                                ?>
                                <div class="pagination-controls">
                                    <?php if ($page > 1): ?>
                                        <a href="?page=<?= $page - 1 ?>" class="pagination-button"><i class="fas fa-chevron-left"></i></a>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                        <a href="?page=<?= $i ?>" class="pagination-button <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $totalPages): ?>
                                        <a href="?page=<?= $page + 1 ?>" class="pagination-button"><i class="fas fa-chevron-right"></i></a>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/data_pengguna.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script>
    function kirimPesanWhatsApp(nomor) {
        const pesanOptions = {
            "1": "Halo, terima kasih telah melakukan pemesanan. Kami akan segera memproses pesanan Anda.",
            "2": "Mohon maaf, bukti pembayaran yang Anda kirimkan belum lengkap. Silakan kirim ulang dengan lengkap ya.",
            "3": "Kami ingin mengonfirmasi data Anda. Mohon cek kembali informasi yang telah Anda berikan.",
        };

        Swal.fire({
            title: 'Pilih Pesan untuk Dikirim',
            input: 'select',
            inputOptions: {
                '1': 'Terima kasih telah memesan',
                '2': 'Bukti pembayaran belum lengkap',
                '3': 'Konfirmasi data'
            },
            inputPlaceholder: 'Pilih jenis pesan',
            showCancelButton: true,
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                const pesan = pesanOptions[result.value];

                Swal.fire({
                    title: 'Edit Pesan (opsional)',
                    input: 'textarea',
                    inputLabel: 'Pesan WhatsApp',
                    inputValue: pesan,
                    inputAttributes: {
                        'aria-label': 'Tulis pesan Anda di sini'
                    },
                    showCancelButton: true,
                    confirmButtonText: 'Kirim ke WhatsApp'
                }).then((pesanResult) => {
                    if (pesanResult.isConfirmed) {
                        const pesanFinal = encodeURIComponent(pesanResult.value);
                        const nomorBersih = nomor.replace(/\D/g, ''); // hilangkan +, spasi, dll
                        const linkWA = `https://wa.me/${nomorBersih}?text=${pesanFinal}`;
                        window.open(linkWA, '_blank');
                    }
                });
            }
        });
    }
    </script>

</body>
</html>