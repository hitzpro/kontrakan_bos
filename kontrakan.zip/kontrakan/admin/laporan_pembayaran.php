<?php
session_start();
require_once '../config/db.php';

// Fungsi untuk mengirim respon
function sendResponse($status, $message, $data = null) {
    header('Content-Type: application/json');
    $response = [
        'status' => $status,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
    exit;
}

// Cek apakah ini adalah API request
if (isset($_GET['action'])) {
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['admin_user_id'])) {
        sendResponse('error', 'Anda harus login terlebih dahulu');
    }

    // Fungsi untuk mendapatkan data pembayaran
    function getDaftarPembayaran($conn, $filters = [], $page = 1, $limit = 10) {
        $offset = ($page - 1) * $limit;
        
        $whereClauses = [];
        $params = [];
        $types = "";
        
        // Filter berdasarkan periode (tanggal)
        if (isset($filters['tanggal_mulai']) && !empty($filters['tanggal_mulai'])) {
            $whereClauses[] = "p.tanggal_pembayaran >= ?";
            $params[] = $filters['tanggal_mulai'] . " 00:00:00";
            $types .= "s";
        }
        
        if (isset($filters['tanggal_selesai']) && !empty($filters['tanggal_selesai'])) {
            $whereClauses[] = "p.tanggal_pembayaran <= ?";
            $params[] = $filters['tanggal_selesai'] . " 23:59:59";
            $types .= "s";
        }
        
        // Filter berdasarkan metode pembayaran
        if (isset($filters['metode']) && !empty($filters['metode']) && $filters['metode'] !== 'all') {
            $whereClauses[] = "p.metode = ?";
            $params[] = $filters['metode'];
            $types .= "s";
        }
        
        $whereClause = !empty($whereClauses) ? "WHERE " . implode(" AND ", $whereClauses) : "";
        
        // Query untuk menghitung total data
        $queryCount = "SELECT COUNT(*) as total FROM pembayaran p
                    JOIN penyewaan ps ON p.id_penyewaan = ps.id
                    JOIN pengguna u ON ps.id_penyewa = u.id
                    JOIN data_kontrakan k ON ps.id_kontrakan = k.id
                    $whereClause";
        
        $stmtCount = $conn->prepare($queryCount);
        
        if (!empty($params)) {
            $stmtCount->bind_param($types, ...$params);
        }
        
        $stmtCount->execute();
        $resultCount = $stmtCount->get_result();
        $totalData = $resultCount->fetch_assoc()['total'];
        $stmtCount->close();
        
        // Query untuk mendapatkan data dengan pagination
        $query = "SELECT p.id, u.nama_pengguna AS nama_penyewa, k.nama_kontrakan, 
                p.jumlah, p.tanggal_pembayaran, p.metode, ps.status_pembayaran,
                p.bukti_pembayaran, p.keterangan
                FROM pembayaran p
                JOIN penyewaan ps ON p.id_penyewaan = ps.id
                JOIN pengguna u ON ps.id_penyewa = u.id
                JOIN data_kontrakan k ON ps.id_kontrakan = k.id
                $whereClause
                ORDER BY p.tanggal_pembayaran DESC
                LIMIT ?, ?";
        
        $stmt = $conn->prepare($query);
        
        if (!empty($params)) {
            $params[] = $offset;
            $params[] = $limit;
            $types .= "ii";
            $stmt->bind_param($types, ...$params);
        } else {
            $stmt->bind_param("ii", $offset, $limit);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $row['tanggal_pembayaran'] = date('d-m-Y H:i', strtotime($row['tanggal_pembayaran']));
            $data[] = $row;
        }
        
        $stmt->close();
        
        return [
            'data' => $data,
            'total' => $totalData,
            'pages' => ceil($totalData / $limit),
            'current_page' => $page
        ];
    }

    // Fungsi untuk mendapatkan statistik pembayaran
    function getStatistikPembayaran($conn, $filters = []) {
        $whereClauses = [];
        $params = [];
        $types = "";
        
        // Filter berdasarkan periode (tanggal)
        if (isset($filters['tanggal_mulai']) && !empty($filters['tanggal_mulai'])) {
            $whereClauses[] = "p.tanggal_pembayaran >= ?";
            $params[] = $filters['tanggal_mulai'] . " 00:00:00";
            $types .= "s";
        }
        
        if (isset($filters['tanggal_selesai']) && !empty($filters['tanggal_selesai'])) {
            $whereClauses[] = "p.tanggal_pembayaran <= ?";
            $params[] = $filters['tanggal_selesai'] . " 23:59:59";
            $types .= "s";
        }
        
        // Filter berdasarkan metode pembayaran
        if (isset($filters['metode']) && !empty($filters['metode']) && $filters['metode'] !== 'all') {
            $whereClauses[] = "p.metode = ?";
            $params[] = $filters['metode'];
            $types .= "s";
        }
        
        $whereClause = !empty($whereClauses) ? "WHERE " . implode(" AND ", $whereClauses) : "";
        
        // Query untuk mendapatkan statistik pembayaran
        $query = "SELECT 
                COUNT(*) as jumlah_transaksi,
                SUM(p.jumlah) as total_pendapatan,
                SUM(CASE WHEN p.metode = 'tunai' THEN p.jumlah ELSE 0 END) as pendapatan_tunai,
                SUM(CASE WHEN p.metode = 'transfer' THEN p.jumlah ELSE 0 END) as pendapatan_transfer
                FROM pembayaran p
                JOIN penyewaan ps ON p.id_penyewaan = ps.id
                $whereClause";
        
        $stmt = $conn->prepare($query);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $stats = $result->fetch_assoc();
        $stmt->close();
        
        // Konversi ke angka untuk mengatasi NULL
        $stats['jumlah_transaksi'] = (int)$stats['jumlah_transaksi'];
        $stats['total_pendapatan'] = (float)$stats['total_pendapatan'] ?: 0;
        $stats['pendapatan_tunai'] = (float)$stats['pendapatan_tunai'] ?: 0;
        $stats['pendapatan_transfer'] = (float)$stats['pendapatan_transfer'] ?: 0;
        
        return $stats;
    }

    // Fungsi untuk mendapatkan detail pembayaran
    function getDetailPembayaran($conn, $id) {
        $query = "SELECT p.id, u.nama_pengguna AS nama_penyewa, k.nama_kontrakan, 
                p.jumlah, p.tanggal_pembayaran, p.metode, ps.status_pembayaran,
                p.bukti_pembayaran, p.keterangan, ps.tanggal_mulai, ps.tanggal_selesai,
                ps.durasi_sewa, ps.harga_sewa, ps.total_bayar, u.no_telepon,
                k.lokasi, k.alamat_lengkap
                FROM pembayaran p
                JOIN penyewaan ps ON p.id_penyewaan = ps.id
                JOIN pengguna u ON ps.id_penyewa = u.id
                JOIN data_kontrakan k ON ps.id_kontrakan = k.id
                WHERE p.id = ?";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return null;
        }
        
        $detail = $result->fetch_assoc();
        $detail['tanggal_pembayaran'] = date('d-m-Y H:i', strtotime($detail['tanggal_pembayaran']));
        $detail['tanggal_mulai'] = date('d-m-Y', strtotime($detail['tanggal_mulai']));
        $detail['tanggal_selesai'] = date('d-m-Y', strtotime($detail['tanggal_selesai']));
        
        $stmt->close();
        return $detail;
    }

    // Handle API Request
    $action = isset($_GET['action']) ? trim($_GET['action']) : '';

    try {
        switch ($action) {
            case 'get_data':
                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
                
                // Filters
                $filters = [];
                
                if (isset($_GET['tanggal_mulai']) && !empty($_GET['tanggal_mulai'])) {
                    $filters['tanggal_mulai'] = $_GET['tanggal_mulai'];
                }
                
                if (isset($_GET['tanggal_selesai']) && !empty($_GET['tanggal_selesai'])) {
                    $filters['tanggal_selesai'] = $_GET['tanggal_selesai'];
                }
                
                if (isset($_GET['metode']) && !empty($_GET['metode'])) {
                    $filters['metode'] = $_GET['metode'];
                }
                
                $result = getDaftarPembayaran($conn, $filters, $page, $limit);
                $statistik = getStatistikPembayaran($conn, $filters);
                
                sendResponse('success', 'Data berhasil dimuat', [
                    'pembayaran' => $result,
                    'statistik' => $statistik
                ]);
                break;
                
            case 'get_detail':
                if (!isset($_GET['id']) || empty($_GET['id'])) {
                    sendResponse('error', 'ID Pembayaran tidak valid');
                }
                
                $id = (int)$_GET['id'];
                $detail = getDetailPembayaran($conn, $id);
                
                if ($detail === null) {
                    sendResponse('error', 'Data pembayaran tidak ditemukan');
                }
                
                sendResponse('success', 'Detail pembayaran berhasil dimuat', $detail);
                break;
                
            default:
                sendResponse('error', 'Action tidak valid');
        }
    } catch (Exception $e) {
        // Log error untuk debugging
        error_log("Error in laporan_pembayaran.php: " . $e->getMessage());
        sendResponse('error', 'Terjadi kesalahan pada server: ' . $e->getMessage());
    }
}
// Jika bukan API request, tampilkan halaman HTML
else {
    // Mulai output HTML
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pembayaran</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <link rel="stylesheet" href="../assets/css/laporan-pembayaran.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="main-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content" id="main-content">
            <div class="page-header">
                <h1>Laporan Pembayaran</h1>
                <div class="header-actions">
                    <button id="downloadPdf" class="btn btn-primary" style="display: none;">
                        <i class="fas fa-download"></i> Download PDF
                    </button>
                    <button class="btn btn-primary" onclick="downloadInvoicePDF()">
                        <i class="fas fa-download"></i> Download PDF
                    </button>

                </div>
            </div>
            
            <div class="filter-container" style="display: none;">
                <div class="filter-group">
                    <label for="periode">Periode:</label>
                    <select id="periode" class="form-control">
                        <option value="all">Semua</option>
                        <option value="daily">Harian</option>
                        <option value="monthly">Bulanan</option>
                        <option value="yearly">Tahunan</option>
                    </select>
                </div>
                
                <!-- <div class="filter-group" id="dateFilterContainer">
                    <label for="tanggalMulai">Dari:</label>
                    <input type="date" id="tanggalMulai" class="form-control">
                    
                    <label for="tanggalSelesai">Sampai:</label>
                    <input type="date" id="tanggalSelesai" class="form-control">
                </div> -->
                
                <div class="filter-group">
                    <label for="metode">Metode Pembayaran:</label>
                    <select id="metode" class="form-control">
                        <option value="all">Semua</option>
                        <option value="tunai">Tunai</option>
                        <option value="transfer">Transfer</option>
                    </select>
                </div>
                
                <button id="btnFilter" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
            
            <div class="stats-container">
                <div class="stat-card total-pendapatan">
                    <div class="stat-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Total Pendapatan</h3>
                        <p class="stat-value" id="totalPendapatan">Rp 0</p>
                    </div>
                </div>
                
                <div class="stat-card jumlah-transaksi">
                    <div class="stat-icon">
                        <i class="fas fa-exchange-alt"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Jumlah Transaksi</h3>
                        <p class="stat-value" id="jumlahTransaksi">0</p>
                    </div>
                </div>
                
                <div class="stat-card tunai">
                    <div class="stat-icon">
                        <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Pendapatan Tunai</h3>
                        <p class="stat-value" id="pendapatanTunai">Rp 0</p>
                    </div>
                </div>
                
                <div class="stat-card transfer">
                    <div class="stat-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Pendapatan Transfer</h3>
                        <p class="stat-value" id="pendapatanTransfer">Rp 0</p>
                    </div>
                </div>
            </div>
            
            <div class="table-container">
                <h2>Data Pembayaran</h2>
                <div class="table-responsive">
                    <table id="pembayaranTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Penyewa</th>
                                <th>Kontrakan</th>
                                <th>Jumlah</th>
                                <th>Tanggal Pembayaran</th>
                                <th>Metode</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="pembayaranData">
                            <!-- Data akan dimuat di sini -->
                        </tbody>
                    </table>
                </div>
                
                <div class="pagination-container">
                    <div class="pagination-info">
                        Menampilkan <span id="showingFrom">0</span> - <span id="showingTo">0</span> dari <span id="totalData">0</span> data
                    </div>
                    <div class="pagination-controls">
                        <button id="btnPrev" class="btn btn-pagination" disabled>
                            <i class="fas fa-chevron-left"></i> Sebelumnya
                        </button>
                        <div id="pageNumbers" class="page-numbers">
                            <!-- Nomor halaman akan dimuat di sini -->
                        </div>
                        <button id="btnNext" class="btn btn-pagination" disabled>
                            Selanjutnya <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Modal Detail Pembayaran -->
            <div class="modal" id="detailModal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>Detail Pembayaran</h2>
                        <span class="close-modal">&times;</span>
                    </div>
                    <div class="modal-body" id="detailContent">
                        <!-- Detail pembayaran akan dimuat di sini -->
                    </div>
                </div>
            </div>
            
               <!-- Template Invoice untuk PDF dengan Kop Surat -->
<div class="invoice-template" id="invoiceTemplate" style="display: none;">
    <!-- Watermark (opsional) -->
    <div class="invoice-watermark">LAPORAN RESMI</div>
    
    <!-- Header/Kop Surat -->
    <div class="invoice-header">
        <div class="company-info">
            <h1>SISTEM KONTRAKAN</h1>
            <p>Jl. Raya Kontrakan No. 123, Kota</p>
            <p>Telp: (021) 123-4567 | Email: info@sistemkontrakan.com</p>
            <p>Website: www.sistemkontrakan.com</p>
        </div>
        <div class="invoice-logo">
            <!-- Ganti dengan logo perusahaan Anda -->
            <img src="../images/logo.png" alt="Logo Perusahaan">
        </div>
    </div>
    
    <!-- Info Invoice -->
    <div class="invoice-info">
        <div class="invoice-info-left">
            <h2>LAPORAN PEMBAYARAN</h2>
            <p><strong>Tanggal Laporan:</strong> <span id="invoiceDate"></span></p>
            <p><strong>Dihasilkan pada:</strong> <span id="invoiceGeneratedDate"></span></p>
        </div>
        <div class="invoice-info-right">
            <h2>PERIODE</h2>
            <p><span id="invoicePeriode"></span></p>
        </div>
    </div>
    
    <!-- Statistik -->
    <div class="invoice-stats">
        <div class="stat-item">
            <span class="stat-label">Total Pendapatan</span>
            <span class="stat-value" id="invoiceTotalPendapatan"></span>
        </div>
        <div class="stat-item">
            <span class="stat-label">Jumlah Transaksi</span>
            <span class="stat-value" id="invoiceJumlahTransaksi"></span>
        </div>
        <div class="stat-item">
            <span class="stat-label">Pendapatan Tunai</span>
            <span class="stat-value" id="invoicePendapatanTunai"></span>
        </div>
        <div class="stat-item">
            <span class="stat-label">Pendapatan Transfer</span>
            <span class="stat-value" id="invoicePendapatanTransfer"></span>
        </div>
    </div>
    
    <!-- Tabel Data -->
    <div class="invoice-table-container">
        <table class="invoice-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Penyewa</th>
                    <th>Nama Kontrakan</th>
                    <th>Jumlah</th>
                    <th>Tanggal</th>
                    <th>Metode</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody id="invoiceData">
                <?php

                $sql = "SELECT p.id, u.nama_pengguna AS nama_penyewa, k.nama_kontrakan, 
                            p.jumlah, p.tanggal_pembayaran, p.metode, ps.status_pembayaran
                        FROM pembayaran p
                        JOIN penyewaan ps ON p.id_penyewaan = ps.id
                        JOIN pengguna u ON ps.id_penyewa = u.id
                        JOIN data_kontrakan k ON ps.id_kontrakan = k.id
                        ORDER BY p.tanggal_pembayaran DESC";

                $query = mysqli_query($conn, $sql);

                while($row = mysqli_fetch_assoc($query)) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . htmlspecialchars($row['nama_penyewa']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['nama_kontrakan']) . "</td>";
                    echo "<td>Rp " . number_format($row['jumlah'], 0, ',', '.') . "</td>";
                    echo "<td>" . date('d-m-Y H:i', strtotime($row['tanggal_pembayaran'])) . "</td>";
                    echo "<td>" . ucfirst($row['metode']) . "</td>";
                    echo "<td><span style='color: white; background-color: green; padding: 2px 8px; border-radius: 5px;'>"
                        . ucfirst($row['status_pembayaran']) . "</span></td>";
                    echo "</tr>";
                }
                ?>
                </tbody>

        </table>
    </div>
    
    <!-- Footer -->
    <div class="invoice-footer">
        <p>Laporan ini dihasilkan secara otomatis oleh Sistem Manajemen Kontrakan.</p>
        <p>&copy; 2025 Sistem Kontrakan - Semua hak dilindungi undang-undang</p>
    </div>
    
    <!-- Tanda Tangan -->
    <style>
        .signature-box p {
            font-family: 'Great Vibes', cursive;
            font-size: 24px;
            font-weight: normal;
            margin: 0;
        }
    </style>

    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">

    <div class="invoice-signature">
        <div class="signature-box">
            <p>H. Sagio</p>
        </div>
    </div>

</div>


        </div>
    </div>
    
    <!-- Load HTML2PDF library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script src="../assets/js/laporan-pembayaran.js"></script>
    <script src="../assets/js/sidebar.js"></script>
    <script>
function downloadInvoicePDF() {
    Swal.fire({
        title: 'Membuat PDF...',
        html: 'Mohon tunggu...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    // Ambil filter
    const filters = {
        tanggal_mulai: document.getElementById('tanggalMulai')?.value || '',
        tanggal_selesai: document.getElementById('tanggalSelesai')?.value || '',
        metode: document.getElementById('metode')?.value || 'all'
    };

    let url = 'laporan_pembayaran.php?action=get_data';
    if (filters.tanggal_mulai) url += `&tanggal_mulai=${filters.tanggal_mulai}`;
    if (filters.tanggal_selesai) url += `&tanggal_selesai=${filters.tanggal_selesai}`;
    if (filters.metode && filters.metode !== 'all') url += `&metode=${filters.metode}`;
    url += '&limit=1000';

    fetch(url)
        .then(res => res.json())
        .then(result => {
            if (result.status === 'success') {
                isiTemplateInvoice(result.data.pembayaran.data, result.data.statistik, filters);
                buatPDF();
            } else {
                Swal.close();
                alert('Gagal mengambil data: ' + result.message);
            }
        })
        .catch(err => {
            Swal.close();
            alert('Terjadi error saat mengambil data: ' + err.message);
        });
}

function formatTanggal(tanggalStr) {
    const parsedDate = new Date(tanggalStr);

    if (isNaN(parsedDate)) {
        // Coba manual parsing kalau tidak valid
        const parts = tanggalStr.split(/[- :T]/); // split fleksibel
        if (parts.length >= 5) {
            // Format: yyyy-mm-dd hh:mm:ss atau sejenis
            const date = new Date(parts[0], parts[1] - 1, parts[2], parts[3], parts[4]);
            if (!isNaN(date)) {
                return date.toLocaleString('id-ID');
            }
        }
        return 'Tanggal tidak valid';
    }

    return parsedDate.toLocaleString('id-ID');
}


function isiTemplateInvoice(pembayaranData, statistik, filters) {
    // Format angka menjadi rupiah
    const formatRupiah = val => new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR'
    }).format(val);

    const now = new Date();
    const tanggalFormat = now.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const waktuFormat = now.toLocaleTimeString('id-ID');

    document.getElementById('invoiceDate').textContent = tanggalFormat;
    document.getElementById('invoiceGeneratedDate').textContent = `${tanggalFormat} ${waktuFormat}`;

    let periode = 'Semua Transaksi';
    if (filters.tanggal_mulai && filters.tanggal_selesai) {
        periode = `${new Date(filters.tanggal_mulai).toLocaleDateString('id-ID')} sampai ${new Date(filters.tanggal_selesai).toLocaleDateString('id-ID')}`;
    } else if (filters.metode && filters.metode !== 'all') {
        periode = `Metode: ${filters.metode}`;
    }
    document.getElementById('invoicePeriode').textContent = periode;

    // Statistik
    document.getElementById('invoiceTotalPendapatan').textContent = formatRupiah(statistik.total_pendapatan);
    document.getElementById('invoiceJumlahTransaksi').textContent = statistik.jumlah_transaksi;
    document.getElementById('invoicePendapatanTunai').textContent = formatRupiah(statistik.pendapatan_tunai);
    document.getElementById('invoicePendapatanTransfer').textContent = formatRupiah(statistik.pendapatan_transfer);

    // Isi tabel data
    const tbody = document.getElementById('invoiceData');
    tbody.innerHTML = '';
    let no = 1;
    pembayaranData.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${no++}</td>
            <td>${item.nama_penyewa}</td>
            <td>${item.nama_kontrakan}</td>
            <td>${formatRupiah(item.jumlah)}</td>
            <td>${formatTanggal(item.tanggal_pembayaran)}</td>
            <td>${item.metode.charAt(0).toUpperCase() + item.metode.slice(1)}</td>
            <td><span style="color:white;background-color:green;padding:2px 8px;border-radius:5px;">
                ${item.status_pembayaran.charAt(0).toUpperCase() + item.status_pembayaran.slice(1)}
            </span></td>
        `;
        tbody.appendChild(tr);
    });

    // Tampilkan elemen untuk PDF
    document.getElementById('invoiceTemplate').style.display = 'block';
}

function buatPDF() {
    const element = document.getElementById('invoiceTemplate');

    html2pdf().set({
        margin: 0.5,
        filename: `Laporan_Pembayaran_${new Date().getTime()}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
    }).from(element).save().then(() => {
        Swal.close();
        // Sembunyikan template kembali
        document.getElementById('invoiceTemplate').style.display = 'none';
    });
}
</script>

    
</body>
</html>
<?php
}
?>