<?php

// Ambil data admin dari session
$admin_name = isset($_SESSION['admin_user_nama_pengguna']) ? $_SESSION['admin_user_nama_pengguna'] : "Admin";
$admin_photo = isset($_SESSION['admin_user_foto']) ? $_SESSION['admin_user_foto'] : "../images/logo.png";
?>

<button id="mobile-toggle-sidebar" class="toggle-btn mobile-toggle" style="display: none;">
    <i class="fas fa-bars"></i>
</button>

<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo-container">
            <h2 class="logo">H. Sagio</h2>
            <button id="toggle-sidebar" class="toggle-btn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </div>
    
    <div class="profile-container">
        <div class="profile-image">
            <img src="../images/<?php echo $admin_photo; ?>" alt="Admin">
        </div>
        <div class="profile-info">
            <h3><?php echo $admin_name; ?></h3>
            <p>Administrator</p>
        </div>
    </div>
    
    <nav class="sidebar-menu">
        <ul>
            <li>
                <a href="dashboard-admin.php" class="nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'dashboard-admin.php') echo 'active'; ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            <li class="menu-category">
                <span>MASTER DATA</span>
            </li>
            <li>
                <a href="data_kontrakan.php" class="nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'data_kontrakan.php') echo 'active'; ?>">
                    <i class="fas fa-home"></i>
                    <span>Data Kontrakan</span>
                </a>
            </li>
            <li>
                <a href="data_penyewa.php" class="nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'data_penyewa.php') echo 'active'; ?>">
                    <i class="fas fa-users"></i>
                    <span>Data Penyewa</span>
                </a>
            </li>
            
            <li class="menu-category">
                <span>TRANSAKSI</span>
            </li>
            <li>
                <a href="booking.php" class="nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'booking.php') echo 'active'; ?>">
                    <i class="fas fa-calendar-check"></i>
                    <span>Booking</span>
                </a>
            </li>
            <li>
                <a href="sewa_kontrakan.php" class="nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'sewa_kontrakan.php') echo 'active'; ?>">
                    <i class="fas fa-key"></i>
                    <span>Sewa Kontrakan</span>
                </a>
            </li>
            <li>
                <a href="perpanjangan.php" class="nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'perpanjangan.php') echo 'active'; ?>">
                    <i class="fas fa-sync-alt"></i>
                    <span>Perpanjangan</span>
                </a>
            </li>
            
            <li class="menu-category">
                <span>LAPORAN</span>
            </li>
            <li>
                <a href="penyewaan.php" class="nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'penyewaan.php') echo 'active'; ?>">
                    <i class="fas fa-file-alt"></i>
                    <span>Penyewaan</span>
                </a>
            </li>
            <li>
                <a href="laporan_pembayaran.php" class="nav-link <?php if(basename($_SERVER['PHP_SELF']) == 'laporan_pembayaran.php') echo 'active'; ?>">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Pembayaran</span>
                </a>
            </li>
        </ul>
        
        <div class="sidebar-footer">
            <a href="#" class="nav-link logout-link" id="logout-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <script>
        document.getElementById('logout-link').addEventListener('click', function(e) {
            e.preventDefault(); // Mencegah langsung ke logout.php

            Swal.fire({
                title: 'Yakin ingin logout?',
                text: "Kamu akan keluar dari akun admin.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#aaa',
                confirmButtonText: 'Ya, logout',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../logic/admin/logout.php';
                }
            });
        });
        </script>


    </nav>
</div>

