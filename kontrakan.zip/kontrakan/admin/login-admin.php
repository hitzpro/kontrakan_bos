<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts - Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- CSS (pakai yang sama dengan user) -->
    <link rel="stylesheet" href="../assets/css/login-user.css">
</head>
<body>
    <div class="container">
        <div class="login-form-container">
            <form id="login-form" action="../logic/admin/login.php" method="post">
                <h2>Masuk Admin</h2>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-envelope"></i></span>
                        <input type="email" name="email" placeholder="Email" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" id="admin-password" placeholder="Kata Sandi" required>
                        <span class="toggle-password" onclick="togglePassword('admin-password')">
                            <i class="fas fa-eye" id="admin-eye-icon"></i>
                        </span>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn-submit">Masuk</button>
                </div>
            </form>
        </div>
    </div>

    <?php if (isset($_SESSION['message'])): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: '<?php echo $_SESSION['status']; ?>',
                title: '<?php echo $_SESSION['title']; ?>',
                text: '<?php echo $_SESSION['message']; ?>',
                timer: 3000,
                timerProgressBar: true
            }).then(() => {
                <?php if ($_SESSION['status'] === 'success' && $_SESSION['redirect']): ?>
                    const userId = '<?php echo $_SESSION['admin_user_id']; ?>';
                    window.location.href = "dashboard-admin.php?id=" + userId;
                <?php endif; ?>
            });
        });
    </script>
    <?php
        unset($_SESSION['message'], $_SESSION['status'], $_SESSION['title'], $_SESSION['redirect']);
    endif;
    ?>

    <script src="../assets/js/login-user.js"></script>
</body>
</html>
