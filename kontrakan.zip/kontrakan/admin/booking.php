<?php
// Start the session
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_user_id'])) {
    header("Location: login-admin.php");
    exit();
}

// Include database connection
require_once '../config/db.php';

// Waktu sekarang (timestamp)
$currentTimestamp = time();

// PERBAIKAN: Hanya ambil booking yang memiliki deadline dan status yang perlu dicek
$query = "
    SELECT id, payment_upload_deadline, status_booking, metode_pembayaran
    FROM booking 
    WHERE status_booking IN ('belum bayar', 'belum lunas') 
    AND payment_upload_deadline IS NOT NULL
    AND payment_upload_deadline > 0
";

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bookingId = (int) $row['id'];
        $deadline = (int) $row['payment_upload_deadline'];
        $currentStatus = $row['status_booking'];
        $metode_pembayaran = $row['metode_pembayaran'];

        // Jika sekarang sudah lewat dari deadline
        if ($currentTimestamp > $deadline) {
            
            // Tentukan pesan berdasarkan metode pembayaran
            $cancelMessage = '';
            if ($metode_pembayaran === 'tunai') {
                $cancelMessage = ' | Sistem: Tidak melakukan pembayaran tunai tepat waktu.';
            } else if ($currentStatus === 'belum lunas') {
                $cancelMessage = ' | Sistem: Tidak melunasi pembayaran transfer tepat waktu.';
            } else {
                $cancelMessage = ' | Sistem: Tidak membayar booking tepat waktu.';
            }
            
            $update = $conn->prepare("
                UPDATE booking 
                SET status_booking = 'dibatalkan', 
                    keterangan = CONCAT(IFNULL(keterangan, ''), ?)
                WHERE id = ?
            ");
            $update->bind_param("si", $cancelMessage, $bookingId);
            $update->execute();
            $update->close();
            
            // Optional: Log untuk debugging
            error_log("Auto-cancelled booking ID: $bookingId, Method: $metode_pembayaran, Status: $currentStatus");
        }
    }
}

// OPSIONAL: Untuk booking dengan status 'menunggu' yang sudah terlalu lama (misal > 7 hari) tanpa konfirmasi admin
$longPendingQuery = "
    SELECT id, payment_upload_deadline, status_booking 
    FROM booking 
    WHERE status_booking = 'menunggu' 
    AND payment_upload_deadline IS NOT NULL
    AND payment_upload_deadline > 0
";

$longPendingResult = $conn->query($longPendingQuery);

if ($longPendingResult && $longPendingResult->num_rows > 0) {
    while ($row = $longPendingResult->fetch_assoc()) {
        $bookingId = (int) $row['id'];
        $deadline = (int) $row['payment_upload_deadline'];

        // Jika sudah lewat deadline konfirmasi admin (7 hari)
        if ($currentTimestamp > $deadline) {
            $update = $conn->prepare("
                UPDATE booking 
                SET status_booking = 'dibatalkan', 
                    keterangan = CONCAT(IFNULL(keterangan, ''), ' | Sistem: Tidak dikonfirmasi admin dalam batas waktu.')
                WHERE id = ?
            ");
            $update->bind_param("i", $bookingId);
            $update->execute();
            $update->close();
            
            error_log("Auto-cancelled pending booking ID: $bookingId due to admin confirmation timeout");
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Booking Kontrakan</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/booking.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    
</head>
<body>
<input type="hidden" id="adminUserId" value="<?php echo $_SESSION['admin_user_id']; ?>">

    <div class="main-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content" id="main-content">
            <div class="page-header">
                <h1>Manajemen Booking</h1>
                <div class="header-actions">
                    <div class="search-container">
                        <input type="text" id="searchInput" placeholder="Cari data booking...">
                        <i class="fas fa-search search-icon"></i>
                    </div>
                </div>
            </div>
            
            <div class="booking-stats">
                <div class="stat-card">
                    <i class="fas fa-clock stat-icon pending-icon"></i>
                    <div class="stat-details">
                        <h3 id="pendingCount">0</h3>
                        <p>Menunggu Konfirmasi</p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-check-circle stat-icon confirmed-icon"></i>
                    <div class="stat-details">
                        <h3 id="confirmedCount">0</h3>
                        <p>Terkonfirmasi</p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-times-circle stat-icon cancelled-icon"></i>
                    <div class="stat-details">
                        <h3 id="cancelledCount">0</h3>
                        <p>Dibatalkan</p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="fas fa-money-bill-wave stat-icon unpaid-icon"></i>
                    <div class="stat-details">
                        <h3 id="unpaidCount">0</h3>
                        <p>Belum Bayar</p>
                    </div>
                </div>
            </div>
            
            <div class="booking-filters">
                <button class="filter-btn active" data-filter="all">Semua</button>
                <button class="filter-btn" data-filter="menunggu">Menunggu</button>
                <button class="filter-btn" data-filter="terkonfirmasi">Terkonfirmasi</button>
                <button class="filter-btn" data-filter="belum bayar">Belum Bayar</button>
                <button class="filter-btn" data-filter="dibatalkan">Dibatalkan</button>
            </div>
            
            <div class="booking-table-container">
                <div class="table-responsive">
                    <table class="booking-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Penyewa</th>
                                <th>Nama Kontrakan</th>
                                <th>Tanggal Booking</th>
                                <th>Periode Sewa</th>
                                <th>Total Bayar</th>
                                <th>Metode Pembayaran</th>
                                <th>Status</th>
                                <th>Kirim Notif</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="bookingTableBody">
                            <!-- Data will be loaded dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="pagination-container">
                <div class="pagination" id="pagination">
                    <!-- Pagination will be generated dynamically -->
                </div>
                <div class="pagination-info">
                    Menampilkan <span id="currentShowing">0</span> dari <span id="totalItems">0</span> data
                </div>
            </div>

    
    <!-- Modal untuk detail booking -->
    <div id="bookingDetailModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Detail Booking</h2>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body" id="bookingDetailContent">
                <!-- Detail content will be loaded dynamically -->
            </div>
            <div class="modal-footer">
                <div class="modal-actions" id="modalActions">
                    <!-- Action buttons will be loaded dynamically -->
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="../assets/js/booking.js"></script>
    <script src="../assets/js/sidebar.js"></script>
</body>
</html>