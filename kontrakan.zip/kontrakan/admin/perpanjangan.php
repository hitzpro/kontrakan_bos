<?php
// Include database configuration
require_once '../config/db.php';
// include_once '../logic/admin/functions.php';

session_start();


// Check if admin is logged in
if (!isset($_SESSION['admin_user_id'])) {
    header("Location: login-admin.php");
    exit();
}

// Process AJAX requests
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    
    switch ($action) {
        case 'get_perpanjangan':
            getPerpanjanganData($conn);
            break;
        case 'update_status':
            updatePerpanjanganStatus($conn);
            break;
        default:
            echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
            break;
    }
    exit;
}

/**
 * Fetch perpanjangan sewa data with pagination and search
 */
function getPerpanjanganData($conn) {
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $offset = ($page - 1) * $limit;
    
    // Base query
    $query = "SELECT ps.*, dk.nama_kontrakan, p.nama_pengguna as nama_penyewa
              FROM perpanjangan_sewa ps
              JOIN data_kontrakan dk ON ps.id_kontrakan = dk.id
              JOIN pengguna p ON ps.id_penyewa = p.id";
    
    // Add search condition if provided
    if (!empty($search)) {
        $search = "%$search%";
        $query .= " WHERE p.nama_pengguna LIKE ? OR dk.nama_kontrakan LIKE ? OR ps.status LIKE ?";
        $countQuery = "SELECT COUNT(*) as total FROM perpanjangan_sewa ps 
                      JOIN data_kontrakan dk ON ps.id_kontrakan = dk.id
                      JOIN pengguna p ON ps.id_penyewa = p.id
                      WHERE p.nama_pengguna LIKE ? OR dk.nama_kontrakan LIKE ? OR ps.status LIKE ?";
        
        // Prepare count statement
        $countStmt = $conn->prepare($countQuery);
        $countStmt->bind_param("sss", $search, $search, $search);
    } else {
        $countQuery = "SELECT COUNT(*) as total FROM perpanjangan_sewa";
        $countStmt = $conn->prepare($countQuery);
    }
    
    // Get total records for pagination
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $totalRows = $countResult->fetch_assoc()['total'];
    $totalPages = ceil($totalRows / $limit);
    
    // Add pagination
    $query .= " ORDER BY ps.tanggal_pengajuan DESC LIMIT ? OFFSET ?";
    
    // Prepare and execute the query
    $stmt = $conn->prepare($query);
    
    if (!empty($search)) {
        $stmt->bind_param("sssii", $search, $search, $search, $limit, $offset);
    } else {
        $stmt->bind_param("ii", $limit, $offset);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    
    echo json_encode([
        'status' => 'success',
        'data' => $data,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total_rows' => $totalRows,
            'total_pages' => $totalPages
        ]
    ]);
}

/**
 * Update perpanjangan sewa status
 */
/**
 * Update perpanjangan sewa status (approve or reject)
 * @param mysqli $conn Database connection
 * @return void Outputs JSON response directly
 */
function updatePerpanjanganStatus($conn) {
    // Check required parameters
    if (!isset($_POST['id']) || !isset($_POST['status'])) {
        echo json_encode(['status' => 'error', 'message' => 'Parameter yang diperlukan tidak lengkap']);
        return;
    }
    
    // Get and validate parameters
    $id = intval($_POST['id']);
    $status = $_POST['status'];
    
    // Validate status value
    $allowedStatuses = ['disetujui', 'ditolak'];
    if (!in_array($status, $allowedStatuses)) {
        echo json_encode(['status' => 'error', 'message' => 'Nilai status tidak valid']);
        return;
    }
    
    // Begin transaction
    $conn->begin_transaction();
    
    try {
        // First, make sure the keterangan column exists in pembayaran table
        ensureKeteranganColumnExists($conn);
        
        // Update the status
        $query = "UPDATE perpanjangan_sewa SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("si", $status, $id);
        $stmt->execute();
        
        // If approved, update related tables and create payment record
        if ($status === 'disetujui') {
            // Get perpanjangan data with additional details for penyewa and kontrakan names
            $getPerpanjangan = "SELECT ps.*, dk.nama_kontrakan, p.nama_pengguna as nama_penyewa 
                               FROM perpanjangan_sewa ps
                               JOIN data_kontrakan dk ON ps.id_kontrakan = dk.id
                               JOIN pengguna p ON ps.id_penyewa = p.id
                               WHERE ps.id = ?";
            $stmtGet = $conn->prepare($getPerpanjangan);
            $stmtGet->bind_param("i", $id);
            $stmtGet->execute();
            $result = $stmtGet->get_result();
            $perpanjangan = $result->fetch_assoc();
            
            // Update the original penyewaan if there's an association
            if (isset($perpanjangan['id_penyewaan']) && $perpanjangan['id_penyewaan'] > 0) {
                $updatePenyewaan = "UPDATE penyewaan SET tanggal_selesai = ? WHERE id = ?";
                $stmtUpdate = $conn->prepare($updatePenyewaan);
                $stmtUpdate->bind_param("si", $perpanjangan['tanggal_selesai'], $perpanjangan['id_penyewaan']);
                $stmtUpdate->execute();
            }
            
            // Create payment record
            $keterangan = "Hasil dari perpanjangan sewa " . $perpanjangan['nama_penyewa'] . " untuk " . $perpanjangan['nama_kontrakan'];
            $metode = isset($perpanjangan['metode_pembayaran']) ? $perpanjangan['metode_pembayaran'] : 'transfer';
            
            $insertPayment = "INSERT INTO pembayaran (id_penyewaan, jumlah, metode, bukti_pembayaran, keterangan) 
                              VALUES (?, ?, ?, ?, ?)";
            $stmtPayment = $conn->prepare($insertPayment);
            $stmtPayment->bind_param(
                "idsss", 
                $perpanjangan['id_penyewaan'],
                $perpanjangan['total_bayar'],
                $metode,
                $perpanjangan['bukti_pembayaran'],
                $keterangan
            );
            $stmtPayment->execute();
        }
        
        // Commit the transaction
        $conn->commit();
        
        // Return success response
        echo json_encode([
            'status' => 'success', 
            'message' => $status === 'disetujui' ? 'Perpanjangan berhasil disetujui' : 'Perpanjangan berhasil ditolak'
        ]);
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui status: ' . $e->getMessage()]);
    }
}


/**
 * Ensure keterangan column exists in pembayaran table
 * This function checks if keterangan column exists and adds it if not
 * @param mysqli $conn Database connection
 * @return void
 */
function ensureKeteranganColumnExists($conn) {
    // Check if column exists
    $checkColumn = "SHOW COLUMNS FROM pembayaran LIKE 'keterangan'";
    $result = $conn->query($checkColumn);
    
    // If column doesn't exist, add it
    if ($result->num_rows === 0) {
        $addColumn = "ALTER TABLE pembayaran ADD COLUMN keterangan TEXT NULL AFTER bukti_pembayaran";
        $conn->query($addColumn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpanjangan Sewa - Manajemen Kontrakan</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/perpanjangan_sewa.css">
</head>
<body>
    <div class="main-container">
        <?php include 'sidebar.php'; ?>
        
        <div class="main-content" id="main-content">
            <div class="header">
                <h1 class="page-title">Perpanjangan Sewa</h1>
                
                <div class="action-bar">
                    <div class="search-container">
                        <input type="text" id="searchInput" placeholder="Cari perpanjangan...">
                        <i class="fas fa-search search-icon"></i>
                    </div>
                </div>
            </div>
            
            <div class="data-container">
                <div class="table-wrapper">
                    <table id="perpanjanganTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Kontrakan</th>
                                <th>Penyewa</th>
                                <th>Tgl Pengajuan</th>
                                <th>Tgl Mulai</th>
                                <th>Tgl Selesai</th>
                                <th>Durasi</th>
                                <th>Total Bayar</th>
                                <th>Status</th>
                                <th>Metode Pembayaran</th>
                                <th>Bukti Pembayaran</th>
                                <th>Keterangan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="perpanjanganTableBody">
                            <!-- Data will be loaded here via JavaScript -->
                            <tr>
                                <td colspan="13" class="loading-data">Memuat data...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="pagination-container">
                    <div class="pagination-info">
                        Menampilkan <span id="currentDisplayed">0</span> dari <span id="totalRecords">0</span> data
                    </div>
                    <div class="pagination-controls" id="pagination">
                        <!-- Pagination buttons will be generated by JavaScript -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Custom JavaScript -->
    <script src="../assets/js/sidebar.js"></script>
    <script src="../assets/js/perpanjangan_sewa.js"></script>
</body>
</html>