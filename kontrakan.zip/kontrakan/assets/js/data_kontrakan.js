document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const kontrakanModal = document.getElementById('kontrakanModal');
    const kontrakanModal2 = document.getElementById('viewModal');
    const viewModal = document.getElementById('viewModal');
    const modalTitle = document.getElementById('modalTitle');
    const kontrakanForm = document.getElementById('kontrakanForm');
    const formAction = document.getElementById('formAction');
    const btnTambahKontrakan = document.getElementById('btnTambahKontrakan');
    const btnEmptyAdd = document.getElementById('btnEmptyAdd');
    const btnEmptyAddMobile = document.getElementById('btnEmptyAddMobile');
    const btnCancel = document.getElementById('btnCancel');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const closeViewBtns = document.querySelectorAll('.close-view');
    const searchInput = document.getElementById('searchInput');
    const filterStatus = document.getElementById('filterStatus');
    const filterTipe = document.getElementById('filterTipe');
    const fotoInput = document.getElementById('foto');
    const fileNameSpan = document.getElementById('file-name');
    const imagePreview = document.getElementById('image-preview');

    // Event Listeners for Opening Modal
    if (btnTambahKontrakan) {
        btnTambahKontrakan.addEventListener('click', openAddModal);
    }
    
    if (btnEmptyAdd) {
        btnEmptyAdd.addEventListener('click', openAddModal);
    }
    
    if (btnEmptyAddMobile) {
        btnEmptyAddMobile.addEventListener('click', openAddModal);
    }

    // Event Listeners for Closing Modals
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            kontrakanModal.style.display = 'none';
            kontrakanModal2.style.display = 'none';
            resetForm();
        });
    });

    closeViewBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            viewModal.style.display = 'none';
        });
    });

    // Close modal when clicking outside of it
    window.addEventListener('click', (e) => {
        if (e.target === kontrakanModal) {
            kontrakanModal.style.display = 'none';
            resetForm();
        }
        if (e.target === viewModal) {
            viewModal.style.display = 'none';
        }
    });

    // Cancel button
    if (btnCancel) {
        btnCancel.addEventListener('click', () => {
            kontrakanModal.style.display = 'none';
            resetForm();
        });
    }

    // Form submission
    if (kontrakanForm) {
        kontrakanForm.addEventListener('submit', handleFormSubmit);
    }

    // Image upload preview
    if (fotoInput) {
        fotoInput.addEventListener('change', handleImageUpload);
    }

    // Search and filter functionality
    if (searchInput) {
        searchInput.addEventListener('input', applyFilters);
    }
    
    if (filterStatus) {
        filterStatus.addEventListener('change', applyFilters);
    }
    
    if (filterTipe) {
        filterTipe.addEventListener('change', applyFilters);
    }

    // Functions
    function openAddModal() {
        resetForm();
        modalTitle.textContent = 'Tambah Kontrakan Baru';
        formAction.value = 'add';
        kontrakanModal.style.display = 'block';
    }

    function resetForm() {
        kontrakanForm.reset();
        document.getElementById('kontrak_id').value = '';
        formAction.value = 'add';
        imagePreview.innerHTML = '';
        imagePreview.classList.add('hidden');
        fileNameSpan.textContent = 'Pilih Foto';
    }

    function handleImageUpload(e) {
        const file = e.target.files[0];
        if (file) {
            fileNameSpan.textContent = file.name;
            
            // Show image preview
            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                imagePreview.classList.remove('hidden');
            }
            reader.readAsDataURL(file);
        } else {
            fileNameSpan.textContent = 'Pilih Foto';
            imagePreview.innerHTML = '';
            imagePreview.classList.add('hidden');
        }
    }

    function handleFormSubmit(e) {
        e.preventDefault();
        
        // Form validation
        const kontrakanForm = document.getElementById('kontrakanForm');
        const formAction = document.getElementById('formAction');
        const required = kontrakanForm.querySelectorAll('[required]');
        let isValid = true;
        
        required.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('error');
            } else {
                field.classList.remove('error');
            }
        });
        
        if (!isValid) {
            showToast('Harap isi semua field yang wajib diisi', 'error');
            return;
        }
        
        // Show loading state
        const btnSubmit = document.getElementById('btnSubmit');
        const originalText = btnSubmit.textContent;
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
        
        // Submit form using AJAX
        const formData = new FormData(kontrakanForm);
        
        // Add the action for the PHP handler
        if (formAction.value === 'add') {
            formData.append('action', 'add');
        } else {
            formData.append('action', 'update');
        }
        
        fetch('../logic/admin/tambah_edit_kontrakan.php', {
            method: 'POST',
            body: formData
        })
        .then(async response => {
            const text = await response.text(); // tangkap respons asli
            console.log("Raw Response Text:", text); // tampilkan isinya di console
        
            try {
                const data = JSON.parse(text); // coba parse manual
                btnSubmit.disabled = false;
                btnSubmit.textContent = originalText;
        
                if (data.status === 'success') {
                    // Close the modal
                    const kontrakanModal = document.getElementById('kontrakanModal');
                    kontrakanModal.style.display = 'none';
                    
                    window.location.reload();
                } else {
                    showToast(data.message, 'error');
                }
            } catch (err) {
                console.error("JSON parse error:", err);
                showToast("Terjadi kesalahan saat memproses respons dari server", "error");
            }
        })
        
        .catch(async error => {
            const responseText = await error.response?.text?.();
            console.error('Error:', error);
            console.error('Response Text:', responseText);
            showToast('Terjadi kesalahan, silakan coba lagi', 'error');
        });
        
    }

    function applyFilters() {
        const searchValue = searchInput.value.toLowerCase();
        const statusValue = filterStatus.value.toLowerCase();
        const tipeValue = filterTipe.value.toLowerCase();
        
        // Filter cards
        const cards = document.querySelectorAll('.kontrakan-card');
        cards.forEach(card => {
            const nama = card.getAttribute('data-nama').toLowerCase();
            const status = card.getAttribute('data-status').toLowerCase();
            const tipe = card.getAttribute('data-tipe').toLowerCase();
            
            const matchSearch = nama.includes(searchValue);
            const matchStatus = statusValue === '' || status === statusValue;
            const matchTipe = tipeValue === '' || tipe === tipeValue;
            
            if (matchSearch && matchStatus && matchTipe) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });
        
        // Filter list items (mobile view)
        const listItems = document.querySelectorAll('.kontrakan-list-item');
        listItems.forEach(item => {
            const nama = item.getAttribute('data-nama').toLowerCase();
            const status = item.getAttribute('data-status').toLowerCase();
            const tipe = item.getAttribute('data-tipe').toLowerCase();
            
            const matchSearch = nama.includes(searchValue);
            const matchStatus = statusValue === '' || status === statusValue;
            const matchTipe = tipeValue === '' || tipe === tipeValue;
            
            if (matchSearch && matchStatus && matchTipe) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
        
        // Check if no results
        checkEmptyResults(cards, listItems);
    }

    function checkEmptyResults(cards, listItems) {
        const visibleCards = [...cards].filter(card => card.style.display !== 'none').length;
        const visibleListItems = [...listItems].filter(item => item.style.display !== 'none').length;
        
        const cardContainer = document.querySelector('.kontrakan-container');
        const listContainer = document.querySelector('.kontrakan-list');
        
        // Handle empty state for card view
        let emptyStateCard = cardContainer.querySelector('.empty-filter-state');
        if (visibleCards === 0 && !emptyStateCard && cardContainer) {
            emptyStateCard = document.createElement('div');
            emptyStateCard.className = 'empty-filter-state';
            emptyStateCard.innerHTML = `
                <i class="fas fa-search"></i>
                <p>Tidak ada kontrakan yang sesuai dengan filter</p>
                <button class="btn btn-secondary" id="btnResetFilter">
                    <i class="fas fa-redo"></i> Reset Filter
                </button>
            `;
            cardContainer.appendChild(emptyStateCard);
            
            document.getElementById('btnResetFilter').addEventListener('click', resetFilters);
        } else if (visibleCards > 0 && emptyStateCard) {
            emptyStateCard.remove();
        }
        
        // Handle empty state for list view
        let emptyStateList = listContainer.querySelector('.empty-filter-state');
        if (visibleListItems === 0 && !emptyStateList && listContainer) {
            emptyStateList = document.createElement('div');
            emptyStateList.className = 'empty-filter-state';
            emptyStateList.innerHTML = `
                <i class="fas fa-search"></i>
                <p>Tidak ada kontrakan yang sesuai dengan filter</p>
                <button class="btn btn-secondary" id="btnResetFilterMobile">
                    <i class="fas fa-redo"></i> Reset Filter
                </button>
            `;
            listContainer.appendChild(emptyStateList);
            
            document.getElementById('btnResetFilterMobile').addEventListener('click', resetFilters);
        } else if (visibleListItems > 0 && emptyStateList) {
            emptyStateList.remove();
        }
    }

    function resetFilters() {
        searchInput.value = '';
        filterStatus.value = '';
        filterTipe.value = '';
        applyFilters();
    }
});

// Global functions for view, edit, and delete
function viewKontrakan(id) {
    // Show loading state
    Swal.fire({
        title: 'Memuat Data...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    // Fetch kontrakan details
    fetch(`../logic/admin/view_kontrakan.php?action=get_kontrakan&id=${id}`)
        .then(response => response.json())
        .then(data => {
            Swal.close();
            
            if (data.status === 'success') {
                const kontrakan = data.data;
                
                // Fill view modal with data
                document.getElementById('viewModalTitle').textContent = `Detail Kontrakan - ${kontrakan.nama_kontrakan}`;
                document.getElementById('view-nama').textContent = kontrakan.nama_kontrakan;
                
                // Status badge
                const statusBadge = document.getElementById('view-status');
                statusBadge.textContent = kontrakan.status === 'tersedia' ? 'Tersedia' : 'Tidak Tersedia';
                statusBadge.className = `badge badge-${kontrakan.status === 'tersedia' ? 'success' : 'danger'}`;
                
                // Tipe badge
                document.getElementById('view-tipe').textContent = kontrakan.tipe_kontrakan === 'bulanan' ? 'Bulanan' : 'Tahunan';
                
                document.getElementById('view-lokasi').textContent = kontrakan.lokasi;
                document.getElementById('view-luas').textContent = kontrakan.luas;
                document.getElementById('view-harga').textContent = `Rp ${numberFormat(kontrakan.harga)}/${kontrakan.tipe_kontrakan === 'bulanan' ? 'bulan' : 'tahun'}`;
                document.getElementById('view-pemilik').textContent = kontrakan.nama_pemilik || 'Admin';
                document.getElementById('view-kontak').textContent = kontrakan.kontak_pemilik || 'Tidak Ada Kontak';
                document.getElementById('view-alamat').textContent = kontrakan.alamat_lengkap;
                document.getElementById('view-deskripsi').textContent = kontrakan.deskripsi || 'Tidak ada deskripsi';
                
                // Image preview
                const imageContainer = document.getElementById('view-image');
                if (kontrakan.foto) {
                    imageContainer.innerHTML = `<img src="../images/kontrakan/${kontrakan.foto}" alt="${kontrakan.nama_kontrakan}">`;
                } else {
                    imageContainer.innerHTML = `<div class="no-image"><i class="fas fa-home"></i></div>`;
                }
                
                // Fasilitas
                const fasilitasContainer = document.getElementById('view-fasilitas');
                if (kontrakan.fasilitas && kontrakan.fasilitas.trim() !== '') {
                    const fasilitas = kontrakan.fasilitas.split(',').map(item => item.trim());
                    let fasilitasHTML = '';
                    
                    fasilitas.forEach(item => {
                        fasilitasHTML += `<span class="fasilitas-item"><i class="fas fa-check-circle"></i> ${item}</span>`;
                    });
                    
                    fasilitasContainer.innerHTML = fasilitasHTML;
                } else {
                    fasilitasContainer.innerHTML = '<p>Tidak ada fasilitas</p>';
                }
                
                // Show view modal
                document.getElementById('viewModal').style.display = 'block';
            } else {
                showToast('Gagal memuat data kontrakan', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.close();
            showToast('Terjadi kesalahan saat memuat data', 'error');
        });
}

function editKontrakan(id) {
    // Show loading state
    Swal.fire({
        title: 'Memuat Data...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    // Fetch kontrakan details
    fetch(`../logic/admin/get_kontrakan.php?action=get_kontrakan&id=${id}`)
        .then(response => response.json())
        .then(data => {
            // Close loading dialog
            Swal.close();
            
            // Tampilkan data dari server untuk debugging
            console.log('JSON Response:', data);

            if (data.status === 'success') {
                const kontrakan = data.data;

                // Set form action to edit
                const formAction = document.getElementById('formAction');
                if (formAction) {
                    formAction.value = 'edit';
                } else {
                    console.error("Element with ID 'formAction' not found");
                }
                
                // Set modal title
                const modalTitle = document.getElementById('modalTitle');
                if (modalTitle) {
                    modalTitle.textContent = 'Edit Kontrakan';
                }
                
                // Function to safely set input value
                const setInputValue = (id, value) => {
                    const element = document.getElementById(id);
                    if (element) {
                        element.value = value || '';
                    } else {
                        console.error(`Element with ID '${id}' not found`);
                    }
                };
                
                // Fill form with data - using safe set function
                setInputValue('kontrak_id', kontrakan.id);
                // setInputValue('id_pemilik', kontrakan.id_pemilik);
                setInputValue('nama_kontrakan', kontrakan.nama_kontrakan);
                setInputValue('lokasi', kontrakan.lokasi);
                setInputValue('alamat_lengkap', kontrakan.alamat_lengkap);
                setInputValue('harga', kontrakan.harga);
                setInputValue('luas', kontrakan.luas);
                setInputValue('tipe_kontrakan', kontrakan.tipe_kontrakan);
                setInputValue('fasilitas', kontrakan.fasilitas);
                setInputValue('deskripsi', kontrakan.deskripsi);
                setInputValue('status', kontrakan.status);
                setInputValue('kontak_pemilik', kontrakan.kontak_pemilik);
                
                // Reset file input if exists
                const fileName = document.getElementById('file-name');
                if (fileName) {
                    fileName.textContent = 'Pilih Foto';
                }
                
                // Show image preview if available
                const imagePreview = document.getElementById('image-preview');
                if (imagePreview) {
                    if (kontrakan.foto) {
                        imagePreview.innerHTML = `<img src="../images/kontrakan/${kontrakan.foto}" alt="${kontrakan.nama_kontrakan}"><p class="file-hint">Foto saat ini: ${kontrakan.foto}</p>`;
                        imagePreview.classList.remove('hidden');
                    } else {
                        imagePreview.innerHTML = '';
                        imagePreview.classList.add('hidden');
                    }
                }
                
                // Show edit modal
                const kontrakanModal = document.getElementById('kontrakanModal');
                if (kontrakanModal) {
                    kontrakanModal.style.display = 'block';
                } else {
                    console.error("Element with ID 'kontrakanModal' not found");
                    showToast('Modal tidak ditemukan', 'error');
                }
            } else {
                showToast(data.message || 'Gagal memuat data kontrakan', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.close();
            showToast('Terjadi kesalahan saat memuat data', 'error');
        });
}



function deleteKontrakan(id, nama) {
    // Confirm delete
    Swal.fire({
        title: 'Hapus Kontrakan?',
        text: `Anda yakin ingin menghapus "${nama}"?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {            
            // Send delete request
            const formData = new FormData();
            formData.append('action', 'delete_kontrakan');
            formData.append('id', id);
            
            fetch('../logic/admin/hapus_kontrakan.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                Swal.close();
                
                if (data.status === 'success') {
                    window.location.reload();
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.close();
                showToast('Terjadi kesalahan saat menghapus data', 'error');
            });
        }
    });
}

// Helper functions
function showToast(message, type = 'success') {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
        }
    });
    
    Toast.fire({
        icon: type,
        title: message
    });
}

function numberFormat(number) {
    return new Intl.NumberFormat('id-ID').format(number);
}