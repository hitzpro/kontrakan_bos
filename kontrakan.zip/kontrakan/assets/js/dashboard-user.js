
document.addEventListener('DOMContentLoaded', function() {
    // Toggle sidebar for mobile
    const toggleButton = document.querySelector('.toggle-sidebar');
    const sidebar = document.querySelector('.sidebar');
    
    if (toggleButton && sidebar) {
        toggleButton.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                const isClickInsideSidebar = sidebar.contains(event.target);
                const isClickOnToggleButton = toggleButton.contains(event.target);
                
                if (!isClickInsideSidebar && !isClickOnToggleButton && sidebar.classList.contains('active')) {
                    sidebar.classList.remove('active');
                }
            }
        });
    }


    
    
    // Menu navigation
    const menuItems = document.querySelectorAll('.menu-item');
    const contentSections = document.querySelectorAll('.content-section');
    const contentHeader = document.querySelector('.content-header h1');
    
    if (menuItems.length && contentSections.length) {
        menuItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                
                const target = this.getAttribute('data-target');
                
                // Update active menu item
                menuItems.forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                
                // Show corresponding content section
                contentSections.forEach(section => {
                    section.classList.remove('active');
                    if (section.id === target) {
                        section.classList.add('active');
                        // Update header title based on active section
                        if (contentHeader) {
                            if (target === 'profile') {
                                contentHeader.textContent = 'Dashboard';
                            } else if (target === 'kelola-penyewaan') {
                                contentHeader.textContent = 'Kelola Penyewaan';
                            } else if (target === 'perpanjang-penyewaan') {
                                contentHeader.textContent = 'Perpanjang Penyewaan';
                            }
                        }
                    }
                });
                
                // Close sidebar on mobile after selection
                if (window.innerWidth <= 768 && sidebar) {
                    sidebar.classList.remove('active');
                }
            });
        });
    }
    
    // User dropdown menu
    const dropdownTrigger = document.querySelector('.dropdown-trigger');
    const dropdownMenu = document.querySelector('.dropdown-menu');
    
    if (dropdownTrigger && dropdownMenu) {
        dropdownTrigger.addEventListener('click', function(e) {
            e.stopPropagation();
            dropdownMenu.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!dropdownTrigger.contains(e.target)) {
                dropdownMenu.classList.remove('active');
            }
        });
        
        // Handle dropdown menu item clicks
        const dropdownItems = document.querySelectorAll('.dropdown-item');
        dropdownItems.forEach(item => {
            item.addEventListener('click', function(e) {
                if (this.getAttribute('data-target')) {
                    e.preventDefault();
                    const target = this.getAttribute('data-target');
                    
                    // Update active menu item in sidebar
                    menuItems.forEach(i => {
                        i.classList.remove('active');
                        if (i.getAttribute('data-target') === target) {
                            i.classList.add('active');
                        }
                    });
                    
                    // Show corresponding content section
                    contentSections.forEach(section => {
                        section.classList.remove('active');
                        if (section.id === target) {
                            section.classList.add('active');
                            // Update header title
                            if (contentHeader) {
                                if (target === 'profile') {
                                    contentHeader.textContent = 'Dashboard';
                                } else if (target === 'kelola-penyewaan') {
                                    contentHeader.textContent = 'Kelola Penyewaan';
                                } else if (target === 'perpanjang-penyewaan') {
                                    contentHeader.textContent = 'Perpanjang Penyewaan';
                                }
                            }
                        }
                    });
                    
                    // Close dropdown
                    dropdownMenu.classList.remove('active');
                }
            });
        });
    }
    
    // Image preview for profile photo upload
    const profileInput = document.getElementById('foto');
    const profilePreview = document.getElementById('profile-preview');
    const previewPlaceholder = document.getElementById('profile-preview-placeholder');
    
    if (profileInput) {
        profileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    // If preview image exists, update its src
                    if (profilePreview) {
                        profilePreview.src = e.target.result;
                        profilePreview.style.display = 'block';
                        
                        // Hide placeholder if it exists
                        if (previewPlaceholder) {
                            previewPlaceholder.style.display = 'none';
                        }
                    } else {
                        // If only placeholder exists, replace it with a new image
                        const newImage = document.createElement('img');
                        newImage.src = e.target.result;
                        newImage.id = 'profile-preview';
                        newImage.alt = 'Foto Profil';
                        
                        const photoContainer = document.querySelector('.photo-container');
                        if (photoContainer) {
                            // Remove placeholder
                            if (previewPlaceholder) {
                                previewPlaceholder.style.display = 'none';
                            }
                            photoContainer.appendChild(newImage);
                        }
                    }
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
    
    // Form validation before submit
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            const passwordNew = document.getElementById('kata_sandi_baru');
            const passwordConfirm = document.getElementById('konfirmasi_kata_sandi');
            const passwordCurrent = document.getElementById('kata_sandi_sekarang');
            
            // Get values, handling null elements
            const passwordNewValue = passwordNew ? passwordNew.value : '';
            const passwordConfirmValue = passwordConfirm ? passwordConfirm.value : '';
            const passwordCurrentValue = passwordCurrent ? passwordCurrent.value : '';
            
            // Validate password fields if any password field is filled
            if (passwordNewValue || passwordConfirmValue || passwordCurrentValue) {
                // Check if current password is provided when trying to change password
                if (!passwordCurrentValue && (passwordNewValue || passwordConfirmValue)) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'Masukkan kata sandi sekarang untuk mengubah kata sandi',
                        confirmButtonColor: '#3085d6'
                    });
                    return;
                }
                
                // Check if new password and confirmation match
                if (passwordNewValue !== passwordConfirmValue) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'Kata sandi baru dan konfirmasi tidak cocok',
                        confirmButtonColor: '#3085d6'
                    });
                    return;
                }
                
                // Validate password strength if new password is provided
                if (passwordNewValue) {
                    if (passwordNewValue.length < 8) {
                        e.preventDefault();
                        Swal.fire({
                            icon: 'error',
                            title: 'Kata Sandi Terlalu Lemah',
                            text: 'Kata sandi harus terdiri dari minimal 8 karakter',
                            confirmButtonColor: '#3085d6'
                        });
                        return;
                    }
                }
            }
            
            // Phone number validation
            const phoneNumber = document.getElementById('no_telepon');
            if (phoneNumber) {
                const phoneRegex = /^[0-9+\-\s()]{10,15}$/;
                if (!phoneRegex.test(phoneNumber.value)) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Nomor Telepon Tidak Valid',
                        text: 'Masukkan nomor telepon yang valid (10-15 digit)',
                        confirmButtonColor: '#3085d6'
                    });
                    return;
                }
            }
            
            // Email validation
            const email = document.getElementById('email');
            if (email) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email.value)) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Email Tidak Valid',
                        text: 'Masukkan alamat email yang valid',
                        confirmButtonColor: '#3085d6'
                    });
                    return;
                }
            }
        });
    }
    
    // Unified logout functionality
    const logoutBtns = document.querySelectorAll('#logout-btn, #logoutBtn');
    logoutBtns.forEach(btn => {
        if (btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                
                Swal.fire({
                    title: 'Yakin ingin keluar?',
                    text: "Anda akan keluar dari dashboard pengguna",
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, Keluar!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "../logic/user/logout.php";
                    }
                });
            });
        }
    });
    
    // Tabs within kelola-penyewaan
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    if (tabButtons.length && tabContents.length) {
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                const target = this.getAttribute('data-tab');
                
                if (target) {
                    const targetElement = document.getElementById(target);
                    
                    if (targetElement) {
                        tabButtons.forEach(btn => btn.classList.remove('active'));
                        tabContents.forEach(tab => tab.classList.remove('active'));
                        
                        this.classList.add('active');
                        targetElement.classList.add('active');
                    }
                }
            });
        });
    }



    document.querySelectorAll('.hapus-btn, .hapus-perpanjangan').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = this.dataset.id;
            const type = this.dataset.type || 'perpanjangan'; // fallback ke 'perpanjangan' jika type tidak ada
            let url = `../logic/user/batal_${type}.php?id=${id}`;
    
            let title = 'Yakin ingin membatalkan?';
            let text = '';
            let confirmText = 'Ya, batalkan';
    
            switch (type) {
                case 'booking':
                    text = "Booking ini akan dibatalkan dan tidak bisa dikembalikan. Lanjutkan?";
                    break;
                case 'sewa':
                    text = "Sewa ini akan dibatalkan dan data akan dinonaktifkan. Apakah Anda yakin?";
                    break;
                case 'perpanjangan':
                    text = "Perpanjangan sewa ini akan dibatalkan. Pastikan Anda yakin dengan keputusan ini.";
                    break;
                default:
                    text = "Aksi ini akan membatalkan data terkait.";
            }
    
            Swal.fire({
                title: title,
                text: text,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: confirmText,
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url;
                }
            });
        });
    });
});

// Toggle password visibility
function togglePassword(fieldId) {
    const passwordField = document.getElementById(fieldId);
    const eyeIcon = document.getElementById(fieldId + '-eye-icon');
    
    if (passwordField && eyeIcon) {
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            eyeIcon.classList.remove('fa-eye');
            eyeIcon.classList.add('fa-eye-slash');
        } else {
            passwordField.type = 'password';
            eyeIcon.classList.remove('fa-eye-slash');
            eyeIcon.classList.add('fa-eye');
        }
    }
}

// Initialize perpanjang penyewaan section
function initPerpanjangPenyewaan() {
    const perpanjangSection = document.getElementById('perpanjang-penyewaan');
    
    if (perpanjangSection) {
        // Here you would normally fetch active rentals that can be extended
        // For now, we'll just set up the UI structure
        
        // You could add an AJAX call here to load active rentals
        
        // For development, you can uncomment this to test the interface
        /*
        const cardBody = perpanjangSection.querySelector('.card-body');
        if (cardBody) {
            // We could add a form or list of rentals to extend here
            // This would be populated from the server
        }
        */
    }
}



// Function to open the modal and set values
function openModal(modalId, idPenyewaan, idKontrakan, hargaSewa) {
    // Set the values in the form
    document.getElementById('id_penyewaan').value = idPenyewaan;
    document.getElementById('id_kontrakan').value = idKontrakan;
    
    // Set default dates (current date as start date)
    const today = new Date();
    
    const startDateInput = document.getElementById('tanggal_mulai');
    startDateInput.value = formatDate(today);
    startDateInput.min = formatDate(today);
    
    // Set default duration to 1 month
    const durasiInput = document.getElementById('durasi');
    durasiInput.value = 1;
    
    // Calculate and set end date based on 1 month duration
    const endDate = new Date(today);
    endDate.setMonth(endDate.getMonth() + 1);
    document.getElementById('tanggal_selesai').value = formatDate(endDate);
    
    // Set base price and calculate total
    const hargaSewaNum = parseInt(hargaSewa);
    document.getElementById('total_harga').value = hargaSewa;
    document.getElementById('total_bayar').value = hargaSewaNum;
    document.getElementById('total_bayar_display').value = formatCurrency(hargaSewaNum);
    
    // Show the modal
    document.getElementById(modalId).style.display = 'block';
    
    // Setup event listeners for dynamic form changes
    setupFormListeners(hargaSewaNum);
}

// Function to close the modal
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    // Reset form
    document.getElementById('form-perpanjangan').reset();
}

// Set up event listeners for form elements
function setupFormListeners(baseHarga) {
    const durasiInput = document.getElementById('durasi');
    const startDateInput = document.getElementById('tanggal_mulai');
    const endDateInput = document.getElementById('tanggal_selesai');
    const metodePembayaran = document.getElementById('metode_pembayaran');
    
    // Handle metode pembayaran change
    metodePembayaran.addEventListener('change', function() {
        const method = this.value;
        document.getElementById('info_pembayaran_tunai').style.display = method === 'tunai' ? 'block' : 'none';
        document.getElementById('info_pembayaran_transfer').style.display = method === 'transfer' ? 'block' : 'none';
    });
    
    // Initial display of payment info based on default value
    const initialMethod = metodePembayaran.value;
    document.getElementById('info_pembayaran_tunai').style.display = initialMethod === 'tunai' ? 'block' : 'none';
    document.getElementById('info_pembayaran_transfer').style.display = initialMethod === 'transfer' ? 'block' : 'none';
    
    // Update end date and total when start date changes
    startDateInput.addEventListener('change', function() {
        updateEndDate();
        updateTotalPrice();
    });
    
    // Update duration when end date changes (this is optional and can be removed if you prefer)
    endDateInput.addEventListener('change', function() {
        // This is commented out because you probably want duration to control the end date,
        // not the other way around
        // const startDate = new Date(startDateInput.value);
        // const endDate = new Date(this.value);
        // const monthDiff = calculateMonthDifference(startDate, endDate);
        // if (monthDiff > 0) {
        //     durasiInput.value = monthDiff;
        //     updateTotalPrice();
        // }
    });
    
    // Update end date and total when duration changes
    durasiInput.addEventListener('change', function() {
        updateEndDate();
        updateTotalPrice();
    });
    
    // Function to update end date based on start date and duration
    function updateEndDate() {
        const startDate = new Date(startDateInput.value);
        const durasiValue = parseInt(durasiInput.value) || 1;
        
        // Calculate end date by adding months
        const endDate = new Date(startDate);
        endDate.setMonth(endDate.getMonth() + durasiValue);
        
        // Set the end date value
        endDateInput.value = formatDate(endDate);
    }
    
    // Function to update total price based on duration
    function updateTotalPrice() {
        const durasiValue = parseInt(durasiInput.value) || 1;
        const totalHarga = baseHarga * durasiValue;
        
        document.getElementById('total_bayar').value = totalHarga;
        document.getElementById('total_bayar_display').value = formatCurrency(totalHarga);
    }
}

// Calculate difference in months between two dates
function calculateMonthDifference(startDate, endDate) {
    const yearDiff = endDate.getFullYear() - startDate.getFullYear();
    const monthDiff = endDate.getMonth() - startDate.getMonth();
    return yearDiff * 12 + monthDiff;
}

// Format date to YYYY-MM-DD
function formatDate(date) {
    const d = new Date(date);
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    return `${d.getFullYear()}-${month}-${day}`;
}

// Format currency
function formatCurrency(amount) {
    return 'Rp ' + new Intl.NumberFormat('id-ID').format(amount);
}

// Handle form submission
document.getElementById('form-perpanjangan').addEventListener('submit', function (e) {
    e.preventDefault();

    console.log('Form submission triggered');

    const formData = new FormData(this);
    const metode = document.getElementById('metode_pembayaran').value;

    console.log('Metode pembayaran:', metode);

    // Validasi file jika metode transfer
    if(metode === 'transfer') {
        const fileInput = document.getElementById('bukti_pembayaran');
        console.log('File input for bukti_pembayaran:', fileInput.files);

        if(fileInput.files.length === 0) {
            Swal.fire({
                title: 'Error!',
                text: 'Silakan upload bukti pembayaran',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            return;
        }
    }

    Swal.fire({
        title: 'Loading',
        text: 'Sedang memproses...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch('../logic/user/perpanjangan_sewa.php', {
        method: 'POST',
        body: formData
    })
    .then(async res => {
        console.log('Fetch response status:', res.status);
        const text = await res.text(); // ambil plain text dulu
        console.log('Raw response:', text); // debug tampilkan isi response
        try {
            const data = JSON.parse(text); // coba parse JSON
            if (data.success) {
                closeModal('perpanjanganModal');
                Swal.fire({
                    title: 'Berhasil!',
                    text: 'Pengajuan perpanjangan berhasil dikirim.',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = '../user/dashboard.php';
                });
            } else {
                Swal.fire({
                    title: 'Error!',
                    text: data.message || 'Terjadi kesalahan.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                closeModal('perpanjanganModal');
            }
        } catch (e) {
            console.error('Gagal parsing JSON:', e);
            console.error('Isi response yang error:', text);
            Swal.fire({
                title: 'Error!',
                text: 'Response tidak valid dari server.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            closeModal('perpanjanganModal');
        }
    })
    .catch(err => {
        console.error('Fetch error:', err);
        Swal.fire({
            title: 'Error!',
            text: 'Terjadi kesalahan sistem.',
            icon: 'error',
            confirmButtonText: 'OK'
        });
        closeModal('perpanjanganModal');
    });
    
});


// Event listener untuk tombol perpanjang
document.querySelectorAll('.perpanjang-btn').forEach(button => {
    button.addEventListener('click', function () {
        const idPenyewaan = this.getAttribute('data-id');
        const idKontrakan = this.getAttribute('data-kontrakan');
        const hargaSewa = this.getAttribute('data-harga');
        
        Swal.fire({
            title: 'Perpanjang Sewa?',
            text: "Apakah Anda yakin ingin memperpanjang sewa?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Ya, lanjutkan!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                openModal('perpanjanganModal', idPenyewaan, idKontrakan, hargaSewa);
            }
        });
    });
});

// Event listener untuk tombol close modal
document.getElementById('closeModalBtn').addEventListener('click', function() {
    closeModal('perpanjanganModal');
});

// Ketika user klik di luar modal, tutup modal
window.onclick = function(event) {
    const modal = document.getElementById('perpanjanganModal');
    if (event.target == modal) {
        closeModal('perpanjanganModal');
    }
};

    // Event listener untuk tombol Bayar
    document.querySelectorAll('.bayar-btn').forEach(button => {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            const type = this.getAttribute('data-type');

            Swal.fire({
                title: 'Lanjut ke Pembayaran?',
                text: "Silakan pilih metode pembayaran.",
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'Lanjut',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    openModal('modalPembayaran');
                    document.getElementById('idTransaksi').value = id;
                    document.getElementById('jenisPembayaran').value = type;
                }
            });
        });
    });

    // Tampilkan atau sembunyikan info bukti berdasarkan metode pembayaran
    function toggleBukti() {
        const metode = document.getElementById('metode_pembayaran').value;
        document.getElementById('infoPembayaran').style.display = 'block';

        document.getElementById('tunaiInfo').style.display = metode === 'tunai' ? 'block' : 'none';
        document.getElementById('transferInfo').style.display = metode === 'transfer' ? 'block' : 'none';
        document.getElementById('buktiInput').style.display = metode === 'transfer' ? 'block' : 'none';
    }






    // ======= KONFIRMASI BAYAR ========
    document.addEventListener('DOMContentLoaded', function() {
        // Tangani klik tombol bayar/lunasi untuk pembayaran tunai
        const bayarButtons = document.querySelectorAll('.bayar-btn');
        
        bayarButtons.forEach(button => {
            button.addEventListener('click', function() {
                const bookingId = this.getAttribute('data-id');
                const harga = this.getAttribute('data-harga');
                
                // Konfirmasi pembayaran dengan SweetAlert2
                Swal.fire({
                    title: 'Konfirmasi Pembayaran',
                    html: `Anda akan mengkonfirmasi pembayaran tunai sejumlah <strong>Rp ${harga}</strong>`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, Konfirmasi',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Kirim request konfirmasi pembayaran via AJAX
                        fetch('../logic/user/proses_pembayaran.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: `booking_id=${bookingId}&aksi=konfirmasi_tunai`
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    title: 'Berhasil!',
                                    text: 'Pembayaran tunai berhasil dikonfirmasi.',
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                }).then(() => {
                                    // Refresh halaman atau update tampilan
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    title: 'Gagal',
                                    text: 'Gagal mengkonfirmasi pembayaran: ' + data.message,
                                    icon: 'error',
                                    confirmButtonText: 'Tutup'
                                });
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            Swal.fire({
                                title: 'Kesalahan',
                                text: 'Terjadi kesalahan saat mengkonfirmasi pembayaran.',
                                icon: 'error',
                                confirmButtonText: 'Tutup'
                            });
                        });
                    }
                });
            });
        });   
});

document.addEventListener('DOMContentLoaded', function () {
    // === KONFIRMASI TUNAI - SEWA ===
    const konfirmasiSewaButtons = document.querySelectorAll('.konfirmasi-tunai-sewa-btn');

    konfirmasiSewaButtons.forEach(button => {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            const harga = this.getAttribute('data-harga');

            Swal.fire({
                title: 'Konfirmasi Pembayaran Sewa',
                html: `Anda akan mengkonfirmasi pembayaran tunai sejumlah <strong>Rp ${harga}</strong>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Konfirmasi',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('../logic/user/konfirmasi_tunai_sewa.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `id=${id}`
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            showToast('success', data.message || 'Pembayaran berhasil dikonfirmasi');
                            setTimeout(() => location.reload(), 1500);
                        } else {
                            showToast('error', data.message || 'Gagal mengkonfirmasi pembayaran');
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        showToast('error', 'Terjadi kesalahan server.');
                    });
                }
            });
        });
    });


    
});

// Add this code to the user's dashboard JavaScript file
$(document).ready(function() {
    // Check for unread messages
    checkForMessages();
    
    function checkForMessages() {
        $.ajax({
            url: '../logic/user/check_messages.php', // Update with your actual endpoint
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success' && response.hasMessages) {
                    // Display messages to user
                    response.messages.forEach(function(message) {
                        Swal.fire({
                            title: 'Pesan Penting!',
                            html: message.message,
                            icon: 'warning',
                            confirmButtonColor: '#3085d6',
                            confirmButtonText: 'Saya Mengerti',
                            footer: 'Pesan dikirim pada: ' + message.created_at
                        }).then((result) => {
                            // Mark message as read
                            if (result.isConfirmed) {
                                markMessageAsRead(message.id);
                            }
                        });
                    });
                }
            },
            error: function() {
                console.error('Failed to check for messages');
            }
        });
    }
    
    function markMessageAsRead(messageId) {
        $.ajax({
            url: '../logic/user/mark_message_read.php', // Update with your actual endpoint
            type: 'POST',
            data: { message_id: messageId },
            dataType: 'json',
            success: function(response) {
                // Message marked as read
                if (response.status === 'success') {
                    // Optionally redirect to payment upload page
                    window.location.href = 'dashboard.php';
                }
            }
        });
    }


    $(document).on('click', '.lihat-kode-pembayaran-btn', function() {
        const kodePembayaran = $(this).data('kode');
        
        Swal.fire({
            title: 'Kode Pembayaran',
            html: `
                <div class="kode-pembayaran-container">
                    <h2 class="kode-display">${kodePembayaran}</h2>
                    <p>Silakan tunjukkan kode ini kepada admin saat melakukan pembayaran tunai.</p>
                    <p>Kode ini bersifat rahasia dan hanya untuk digunakan oleh Anda.</p>
                </div>
            `,
            icon: 'info',
            confirmButtonText: 'Tutup',
            customClass: {
                popup: 'kode-pembayaran-popup'
            }
        });
    });


});


