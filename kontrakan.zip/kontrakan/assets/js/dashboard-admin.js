// ===== DASHBOARD-ADMIN FUNCTIONALITY =====

// Fungsi untuk menampilkan SweetAlert sederhana
function showAlert(title, text, icon) {
    Swal.fire({
        title: title,
        text: text,
        icon: icon,
        customClass: {
            confirmButton: 'swal-btn-primary'
        },
        buttonsStyling: false
    });
}

// Fungsi konfirmasi aksi dengan SweetAlert
function confirmAction(title, text, confirmText, cancelText, confirmCallback) {
    Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: confirmText,
        cancelButtonText: cancelText,
        customClass: {
            confirmButton: 'swal-btn-danger',
            cancelButton: 'swal-btn-cancel'
        },
        buttonsStyling: false
    }).then((result) => {
        if (result.isConfirmed) {
            confirmCallback();
        }
    });
}
