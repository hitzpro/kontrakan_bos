// Toggle between login and register forms
document.addEventListener('DOMContentLoaded', function() {
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const showRegister = document.getElementById('show-register');
  const showLogin = document.getElementById('show-login');

  // Show register form
  showRegister.addEventListener('click', function(e) {
      e.preventDefault();
      loginForm.style.display = 'none';
      registerForm.style.display = 'block';
  });

  // Show login form
  showLogin.addEventListener('click', function(e) {
      e.preventDefault();
      registerForm.style.display = 'none';
      loginForm.style.display = 'block';
  });

  // Form validation for register
  if (registerForm) {
      registerForm.addEventListener('submit', function(e) {
          const password = document.getElementById('register-password').value;
          const confirmPassword = document.getElementById('register-confirm-password').value;
          const email = document.getElementById('register-email').value;
          const phone = document.getElementById('register-phone').value;

          // Validate email format
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(email)) {
              e.preventDefault();
              Swal.fire({
                  icon: 'error',
                  title: 'Format Email Salah',
                  text: 'Mohon masukkan alamat email yang valid',
              });
              return;
          }

          // Validate phone number (numeric only)
          const phonePattern = /^[0-9]+$/;
          if (!phonePattern.test(phone)) {
              e.preventDefault();
              Swal.fire({
                  icon: 'error',
                  title: 'Format Nomor Telepon Salah',
                  text: 'Nomor telepon hanya boleh berisi angka',
              });
              return;
          }

          // Check password match
          if (password !== confirmPassword) {
              e.preventDefault();
              Swal.fire({
                  icon: 'error',
                  title: 'Kata Sandi Tidak Cocok',
                  text: 'Konfirmasi kata sandi harus sama dengan kata sandi',
              });
              return;
          }

          // Password minimal 6 characters
          if (password.length < 6) {
              e.preventDefault();
              Swal.fire({
                  icon: 'error',
                  title: 'Kata Sandi Terlalu Pendek',
                  text: 'Kata sandi minimal harus 6 karakter',
              });
              return;
          }
      });
  }
});

// Toggle password visibility
function togglePassword(inputId) {
  const passwordInput = document.getElementById(inputId);
  const eyeIcon = document.getElementById(inputId + '-eye-icon');
  
  if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      eyeIcon.classList.remove('fa-eye');
      eyeIcon.classList.add('fa-eye-slash');
  } else {
      passwordInput.type = 'password';
      eyeIcon.classList.remove('fa-eye-slash');
      eyeIcon.classList.add('fa-eye');
  }
}