/**
 * Perpanjangan Sewa Management System
 * Main JavaScript file for handling the client-side functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize perpanjangan sewa data
    loadPerpanjanganData();
    
    // Setup event listeners
    document.getElementById('searchInput').addEventListener('input', function() {
        currentPage = 1; // Reset to first page on search
        loadPerpanjanganData();
    });
});

// Global variables for pagination
let currentPage = 1;
const perPage = 10;

/**
 * Load perpanjangan data from server with pagination and search
 */
function loadPerpanjanganData() {
    const searchTerm = document.getElementById('searchInput').value;
    const url = `perpanjangan.php?action=get_perpanjangan&page=${currentPage}&limit=${perPage}&search=${encodeURIComponent(searchTerm)}`;
    
    // Show loading indicator
    document.getElementById('perpanjanganTableBody').innerHTML = '<tr><td colspan="13" class="loading-data">Memuat data...</td></tr>';
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                displayPerpanjanganData(data.data);
                updatePagination(data.pagination);
            } else {
                showToast('error', 'Gagal memuat data: ' + (data.message || 'Unknown error'));
                document.getElementById('perpanjanganTableBody').innerHTML = '<tr><td colspan="13">Gagal memuat data</td></tr>';
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            showToast('error', 'Terjadi kesalahan saat memuat data');
            document.getElementById('perpanjanganTableBody').innerHTML = '<tr><td colspan="13">Terjadi kesalahan saat memuat data</td></tr>';
        });
}

/**
 * Display perpanjangan data in the table
 */
function displayPerpanjanganData(data) {
    const tableBody = document.getElementById('perpanjanganTableBody');
    tableBody.innerHTML = '';
    
    if (data.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="13" class="no-data">Tidak ada data perpanjangan</td></tr>';
        return;
    }

    let no = 1;
    
    data.forEach(item => {
        const row = document.createElement('tr');
        
        // Format date strings
        const tglPengajuan = new Date(item.tanggal_pengajuan).toLocaleDateString('id-ID');
        const tglMulai = new Date(item.tanggal_mulai).toLocaleDateString('id-ID');
        const tglSelesai = new Date(item.tanggal_selesai).toLocaleDateString('id-ID');
        
        // Status class for styling
        const statusClass = getStatusClass(item.status);
        // Create table row with data
        row.innerHTML = `
            <td>${no++}</td>
            <td>${item.nama_kontrakan}</td>
            <td>${item.nama_penyewa}</td>
            <td>${tglPengajuan}</td>
            <td>${tglMulai}</td>
            <td>${tglSelesai}</td>
            <td>${item.durasi} bulan</td>
            <td>Rp ${formatNumber(item.total_bayar)}</td>
            <td><span class="status-badge ${statusClass}">${item.status}</span></td>
            <td>${item.metode_pembayaran || '-'}</td>
            <td>${item.bukti_pembayaran ? '<a href="../user/bukti_pembayaran/' + item.bukti_pembayaran + '" target="_blank">Lihat</a>' : '-'}</td>
            <td>${item.keterangan || '-'}</td>
            <td class="action-buttons">
                ${generateActionButtons(item)}
            </td>
        `;
        
        tableBody.appendChild(row);
    });
    
    // Add event listeners to action buttons
    addActionButtonListeners();
}

/**
 * Generate action buttons based on perpanjangan status
 */
function generateActionButtons(item) {
    if (item.status === 'menunggu') {
        return `
            <button class="btn-approve btn" data-id="${item.id}" title="Setujui">
                <i class="fas fa-check"></i>
            </button>
            <button class="btn-reject btn" data-id="${item.id}" title="Tolak">
                <i class="fas fa-times"></i>
            </button>
        `;
    } else {
        return `<span class="status-processed">${capitalizeFirstLetter(item.status)}</span>`;
    }
}

/**
 * Add event listeners to action buttons
 */
function addActionButtonListeners() {
    // Approve buttons
    document.querySelectorAll('.btn-approve').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            confirmStatusUpdate(id, 'disetujui');
        });
    });
    
    // Reject buttons
    document.querySelectorAll('.btn-reject').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            confirmStatusUpdate(id, 'ditolak');
        });
    });
}

/**
 * Confirm status update with SweetAlert
 */
function confirmStatusUpdate(id, status) {
    const action = status === 'disetujui' ? 'menyetujui' : 'menolak';
    const actionText = status === 'disetujui' ? 'Setujui' : 'Tolak';
    
    Swal.fire({
        title: `${actionText} Perpanjangan?`,
        text: `Anda yakin ingin ${action} perpanjangan sewa ini?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: status === 'disetujui' ? '#3085d6' : '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: actionText,
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            updatePerpanjanganStatus(id, status);
        }
    });
}

/**
 * Update perpanjangan status via AJAX
 */
function updatePerpanjanganStatus(id, status) {
    const formData = new FormData();
    formData.append('id', id);
    formData.append('status', status);
    
    fetch('perpanjangan.php?action=update_status', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showToast('success', data.message || 'Status berhasil diperbarui');
            // Reload data to reflect changes
            loadPerpanjanganData();
        } else {
            showToast('error', data.message || 'Gagal memperbarui status');
        }
    })
    .catch(error => {
        console.error('Error updating status:', error);
        showToast('error', 'Terjadi kesalahan saat memperbarui status');
    });
}

/**
 * Update pagination controls
 */
function updatePagination(pagination) {
    const paginationDiv = document.getElementById('pagination');
    paginationDiv.innerHTML = '';
    
    // Previous button
    const prevBtn = document.createElement('button');
    prevBtn.className = 'page-btn prev-btn' + (pagination.page <= 1 ? ' disabled' : '');
    prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
    if (pagination.page > 1) {
        prevBtn.addEventListener('click', function() {
            currentPage--;
            loadPerpanjanganData();
        });
    }
    paginationDiv.appendChild(prevBtn);
    
    // Page buttons - show max 5 pages
    const startPage = Math.max(1, pagination.page - 2);
    const endPage = Math.min(pagination.total_pages, startPage + 4);
    
    for (let i = startPage; i <= endPage; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = 'page-btn page-number' + (i === pagination.page ? ' active' : '');
        pageBtn.textContent = i;
        pageBtn.addEventListener('click', function() {
            currentPage = i;
            loadPerpanjanganData();
        });
        paginationDiv.appendChild(pageBtn);
    }
    
    // Next button
    const nextBtn = document.createElement('button');
    nextBtn.className = 'page-btn next-btn' + (pagination.page >= pagination.total_pages ? ' disabled' : '');
    nextBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
    if (pagination.page < pagination.total_pages) {
        nextBtn.addEventListener('click', function() {
            currentPage++;
            loadPerpanjanganData();
        });
    }
    paginationDiv.appendChild(nextBtn);
    
    // Update displayed info
    document.getElementById('currentDisplayed').textContent = Math.min(pagination.total_rows, pagination.page * pagination.limit);
    document.getElementById('totalRecords').textContent = pagination.total_rows;
}

/**
 * Toast notification system using SweetAlert2
 */
function showToast(type, message) {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
        }
    });
    
    Toast.fire({
        icon: type,
        title: message
    });
}

/**
 * Helper function to get status class for styling
 */
function getStatusClass(status) {
    switch(status) {
        case 'disetujui':
            return 'status-approved';
        case 'ditolak':
            return 'status-rejected';
        case 'dibatalkan':
            return 'status-rejected';
        case 'menunggu':
            return 'status-pending';
        default:
            return '';
    }
}

/**
 * Helper function to format number with thousand separator
 */
function formatNumber(number) {
    return parseFloat(number).toLocaleString('id-ID');
}

/**
 * Helper function to capitalize first letter
 */
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}