document.addEventListener('DOMContentLoaded', function() {
    // Tab functionality
    const tabHeaders = document.querySelectorAll('.tab-header');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const tabId = header.getAttribute('data-tab');
            
            // Remove active class from all headers and contents
            tabHeaders.forEach(h => h.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked header and corresponding content
            header.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Set initial date for booking and sewa forms
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowFormatted = tomorrow.toISOString().split('T')[0];
    
    const tanggalMulaiInputs = document.querySelectorAll('input[type="date"]');
    tanggalMulaiInputs.forEach(input => {
        input.min = tomorrowFormatted;
        input.value = tomorrowFormatted;
    });
    
    // Set up form submission events
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitForm(this, 'booking');
        });
    }
    
});

// Function to change main image when thumbnail is clicked
function changeMainImage(src) {
    document.getElementById('mainImage').src = src;
}

// Function to redirect to login page
function redirectToLogin(kontrakanId) {
    console.log("🔍 REDIRECT: redirectToLogin called with ID:", kontrakanId);
    
    Swal.fire({
        title: 'Login Diperlukan',
        text: 'Anda harus login untuk melakukan booking atau sewa.',
        icon: 'info',
        confirmButtonText: 'Login Sekarang',
        showCancelButton: true,
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            // Fix: Pastikan path benar dan parameter terkirim
            const redirectUrl = 'login.php?redirect_id=' + kontrakanId;
            console.log("🔍 REDIRECT: Redirecting to:", redirectUrl);
            window.location.href = redirectUrl;
        }
    });
}




// Functions to show modal
function showBookingModal() {
    document.getElementById('bookingModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function showSewaModal() {
    document.getElementById('sewaModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Function to close modal
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Function to format currency
function formatRupiah(angka) {
    let reverse = angka.toString().split('').reverse().join('');
    let ribuan = reverse.match(/\d{1,3}/g);
    ribuan = ribuan.join('.').split('').reverse().join('');
    return 'Rp ' + ribuan;
}

// Function to calculate total price for booking form
function hitungTotalHarga() {
    const hargaSatuan = parseFloat(document.getElementById('harga_satuan').value) || 0;
    const durasi      = parseInt(document.getElementById('durasi_sewa').value) || 1;
    const total       = hargaSatuan * durasi;
  
    // Tampilkan hasil
    document.getElementById('total_harga').value = formatRupiah(total);
    document.getElementById('total_bayar').value = total.toFixed(2); // untuk input hidden
  }


document.addEventListener("DOMContentLoaded", function () {
    hitungTotalHargaSewa(); // Panggil saat halaman atau modal pertama kali load
});

function hitungTotalHargaSewa() {
    const hargaSatuan = parseInt(document.querySelector('input[name="harga_satuan"]').value);
    const durasi = parseInt(document.getElementById("durasi_sewa_langsung").value);
    const tipe = document.querySelector('input[name="tipe_kontrakan"]').value;
    const totalHarga = hargaSatuan * durasi;

    // Tampilkan ke user
    document.getElementById("total_harga_sewa").value = "Rp " + totalHarga.toLocaleString("id-ID");
    document.getElementById("total_harga_sewa_value").value = totalHarga;

    // Hitung tanggal selesai
    const tanggalMulaiInput = document.getElementById("tanggal_mulai_sewa").value;
    if (tanggalMulaiInput) {
        const tanggalMulai = new Date(tanggalMulaiInput);
        if (!isNaN(tanggalMulai)) {
            if (tipe === "bulanan") {
                tanggalMulai.setMonth(tanggalMulai.getMonth() + durasi);
            } else {
                tanggalMulai.setFullYear(tanggalMulai.getFullYear() + durasi);
            }
            const tglSelesai = tanggalMulai.toISOString().split('T')[0];
            document.getElementById("tanggal_selesai").value = tglSelesai;
        }
    }
}

// Form validation and submission function
function validateForm(form) {
    const tanggalMulai = form.querySelector('#tanggal_mulai');
    const durasiSewa = form.querySelector('#durasi_sewa');
    const metodePembayaran = form.querySelector('#metode_pembayaran');
    const buktiPembayaran = form.querySelector('#bukti_transaksi');

    // Validate start date
    if (!tanggalMulai.value) {
        Swal.fire({
            title: 'Error!',
            text: 'Harap pilih tanggal mulai sewa',
            icon: 'error',
            confirmButtonColor: '#F44336'
        });
        return false;
    }

    // Validate rental duration
    if (!durasiSewa.value || parseInt(durasiSewa.value) < 1) {
        Swal.fire({
            title: 'Error!',
            text: 'Durasi sewa minimal 1 bulan/tahun',
            icon: 'error',
            confirmButtonColor: '#F44336'
        });
        return false;
    }

    // Validate payment method
    if (!metodePembayaran.value) {
        Swal.fire({
            title: 'Error!',
            text: 'Harap pilih metode pembayaran',
            icon: 'error',
            confirmButtonColor: '#F44336'
        });
        return false;
    }

    // Validate payment proof for transfer method
    if (metodePembayaran.value === 'transfer' && !buktiPembayaran.files.length) {
        Swal.fire({
            title: 'Error!',
            text: 'Harap upload bukti pembayaran',
            icon: 'error',
            confirmButtonColor: '#F44336'
        });
        return false;
    }

    return true;
}

// Calculate total price
function hitungTotalHarga() {
    const hargaSatuan = parseFloat(document.getElementById('total_harga_value').value);
    const durasiSewa = parseInt(document.getElementById('durasi_sewa').value);
    const totalHarga = hargaSatuan * durasiSewa;
    
    document.getElementById('total_harga').value = `Rp ${totalHarga.toLocaleString('id-ID')}`;
    document.getElementById('total_harga_value').value = totalHarga;
    document.getElementById('total_bayar').value = totalHarga;
}

// Toggle payment info and proof upload
function toggleBukti() {
    const metodePembayaran = document.getElementById('metode_pembayaran');
    const infoPembayaran = document.getElementById('infoPembayaran');
    const tunaiInfo = document.getElementById('tunaiInfo');
    const transferInfo = document.getElementById('transferInfo');
    const buktiInput = document.getElementById('buktiInput');

    // Hide all info sections first
    infoPembayaran.style.display = 'none';
    tunaiInfo.style.display = 'none';
    transferInfo.style.display = 'none';
    buktiInput.style.display = 'none';

    // Show relevant info based on payment method
    if (metodePembayaran.value) {
        infoPembayaran.style.display = 'block';
        
        if (metodePembayaran.value === 'tunai') {
            tunaiInfo.style.display = 'block';
        } else if (metodePembayaran.value === 'transfer') {
            transferInfo.style.display = 'block';
            buktiInput.style.display = 'block';
        }
    }
}

function submitForm(form, type) {
    // Prevent multiple submissions
    const submitButton = form.querySelector('button[type="submit"]');
    if (submitButton.disabled) return;
    
    if (!validateForm(form)) return;
    
    const url = form.action;
    const data = new FormData(form);
    
    // Disable submit button to prevent multiple clicks
    submitButton.disabled = true;
    
    Swal.fire({
      title: 'Memproses...',
      html: type === 'booking' ? 'Sedang memproses booking' : '',
      allowOutsideClick: false, 
      didOpen: () => Swal.showLoading()
    });
    
    fetch(url, { 
      method: 'POST', 
      body: data 
    })
    .then(res => {
      // Check if the response is valid JSON
      const contentType = res.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('Received non-JSON response');
      }
      return res.json();
    })
    .then(json => {
      Swal.close();
      if (json.success) {
        // Build the success message with payment code and deadline if available
        let message = json.message;
        
        // Add additional HTML for payment details if they exist
        if (json.payment_code || json.deadline) {
          message += '<div style="margin-top: 15px;">';
          
          if (json.payment_code) {
            message += `<p><strong>Kode Pembayaran:</strong> ${json.payment_code}</p>`;
          }
          
          if (json.deadline) {
            message += `<p><strong>Batas Waktu:</strong> ${json.deadline}</p>`;
          }
          
          message += '</div>';
        }
        
        Swal.fire({
          title: 'Berhasil!',
          html: message,
          icon: 'success'
        }).then(() => {
          if (json.redirect) {
            window.location = json.redirect;
          } else {
            location.reload();
          }
        });
      } else {
        Swal.fire('Gagal!', json.message, 'error');
      }
    })
    .catch(err => {
      console.error(err);
      Swal.fire('Gagal!', 'Terjadi kesalahan server', 'error');
    })
    .finally(() => {
      // Re-enable submit button
      submitButton.disabled = false;
    });
}

// Event listener for form submission
document.addEventListener('DOMContentLoaded', () => {
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault(); // Prevent default form submission
            submitForm(this, 'booking');
        });

        // Add event listeners for dynamic calculations and display
        const durasiSewa = document.getElementById('durasi_sewa');
        if (durasiSewa) {
            durasiSewa.addEventListener('change', hitungTotalHarga);
        }

        const metodePembayaran = document.getElementById('metode_pembayaran');
        if (metodePembayaran) {
            metodePembayaran.addEventListener('change', toggleBukti);
        }
    }
});

// Close modal when clicking outside of it
window.onclick = function(event) {
    const bookingModal = document.getElementById('bookingModal');
    const sewaModal = document.getElementById('sewaModal');
    
    if (event.target === bookingModal) {
        bookingModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
    
    if (event.target === sewaModal) {
        sewaModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Fungsi untuk menampilkan informasi pembayaran sesuai dengan pilihan metode pembayaran
function showPaymentDetails() {
    var metodePembayaran = document.getElementById('metode_pembayaran').value;
        
    // Menyembunyikan semua info pembayaran terlebih dahulu
    document.getElementById('tunaiInfo').style.display = 'none';
    document.getElementById('transferInfo').style.display = 'none';
    document.getElementById('infoPembayaran').style.display = 'none';
        
    if (metodePembayaran === 'tunai') {
        document.getElementById('infoPembayaran').style.display = 'block';
        document.getElementById('tunaiInfo').style.display = 'block';
    } else if (metodePembayaran === 'transfer') {
        document.getElementById('infoPembayaran').style.display = 'block';
        document.getElementById('transferInfo').style.display = 'block';
    }
}

    // Tampilkan atau sembunyikan info bukti berdasarkan metode pembayaran
    function toggleBukti() {
        const metode = document.getElementById('metode_pembayaran').value;
        document.getElementById('infoPembayaran').style.display = 'block';

        document.getElementById('tunaiInfo').style.display = metode === 'tunai' ? 'block' : 'none';
        document.getElementById('transferInfo').style.display = metode === 'transfer' ? 'block' : 'none';
        document.getElementById('buktiInput').style.display = metode === 'transfer' ? 'block' : 'none';
    }

        // Tampilkan atau sembunyikan info bukti berdasarkan metode pembayaran
        function toggleBukti2() {
            const metode = document.getElementById('metode_pembayaran2').value;
            document.getElementById('infoPembayaran2').style.display = 'block';
    
            document.getElementById('tunaiInfo2').style.display = metode === 'tunai' ? 'block' : 'none';
            document.getElementById('transferInfo2').style.display = metode === 'transfer' ? 'block' : 'none';
            document.getElementById('buktiInput2').style.display = metode === 'transfer' ? 'block' : 'none';
        }



        document.getElementById("sewaForm").addEventListener("submit", function(e) {
            e.preventDefault();
        
            const formData = new FormData(this);
        
            fetch(this.action, {
                method: "POST",
                body: formData,
            })
            .then(async response => {
                const text = await response.text(); // Ambil raw response dulu
                try {
                    const result = JSON.parse(text); // Coba parse JSON
                    if (result.success) {
                        Swal.fire("Berhasil", result.message, "success").then(() => location.reload());
                    } else {
                        Swal.fire("Gagal", result.message, "error");
                    }
                } catch (e) {
                    console.error("Response bukan JSON:", text); // ⛔ Tampilkan isi HTML error
                    Swal.fire("Error", "Respon server tidak valid (bukan JSON). Cek console!", "error");
                }
            })
            .catch(error => {
                Swal.fire("Error", "Terjadi kesalahan saat mengirim ke server", "error");
                console.error("Fetch Error:", error);
            });
            
        });
        