// ===== SIDEBAR FUNCTIONALITY =====
document.addEventListener('DOMContentLoaded', function () {
    // Make sure all required elements exist before using them
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');
    const toggleBtn = document.getElementById('toggle-sidebar');
    const logoText = document.querySelector('.logo');
    const mobileToggleBtn = document.getElementById('mobile-toggle-sidebar');

    // Debug check - log if elements are missing
    if (!sidebar) {
        console.error('Sidebar element not found!');
        return; // Exit if sidebar is missing
    }
    
    if (!mainContent) {
        console.error('Main content element not found!');
        // Continue but with limited functionality
    }

    // Periksa status sidebar dari localStorage
    const isSidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';

    // Terapkan status sidebar saat halaman dimuat
    if (isSidebarCollapsed) {
        sidebar.classList.add('collapsed');
        if (mainContent) mainContent.classList.add('expanded');
        if (logoText) logoText.style.display = 'none';
    }

    // Fungsi untuk toggle sidebar (desktop)
    function toggleSidebar() {
        sidebar.classList.toggle('collapsed');
        if (mainContent) mainContent.classList.toggle('expanded');
        
        // Toggle logo visibility
        if (logoText) {
            if (sidebar.classList.contains('collapsed')) {
                logoText.style.display = 'none';
            } else {
                logoText.style.display = 'block';
            }
        }

        // Simpan status sidebar ke localStorage
        const isCollapsed = sidebar.classList.contains('collapsed');
        localStorage.setItem('sidebarCollapsed', isCollapsed);
    }

    // Event listener untuk tombol toggle (desktop)
    if (toggleBtn) {
        toggleBtn.addEventListener('click', toggleSidebar);
    }

    // Fungsi toggle sidebar pada mode mobile
    function toggleMobileSidebar() {
        sidebar.classList.toggle('visible');
    }

    // Fungsi untuk menangani hover pada sidebar collapsed
    function handleSidebarHover() {
        if (sidebar.classList.contains('collapsed') && window.innerWidth > 768) {
            // Tampilkan tooltip untuk menu item saat sidebar collapsed
            const menuItems = document.querySelectorAll('.nav-link');
            
            menuItems.forEach(item => {
                const text = item.querySelector('span')?.textContent || '';
                
                item.addEventListener('mouseenter', function() {
                    // Buat tooltip elemen
                    const tooltip = document.createElement('div');
                    tooltip.className = 'sidebar-tooltip';
                    tooltip.textContent = text;
                    tooltip.style.position = 'fixed';
                    tooltip.style.left = (sidebar.offsetWidth + 10) + 'px';
                    tooltip.style.backgroundColor = 'var(--secondary-color)';
                    tooltip.style.color = 'var(--white-color)';
                    tooltip.style.padding = '5px 10px';
                    tooltip.style.borderRadius = '4px';
                    tooltip.style.fontSize = 'var(--font-size-small)';
                    tooltip.style.zIndex = '1200';
                    tooltip.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
                    
                    // Posisikan tooltip sejajar dengan item
                    const rect = item.getBoundingClientRect();
                    tooltip.style.top = rect.top + (rect.height / 2 - 12) + 'px';
                    
                    // Tambahkan ke body
                    document.body.appendChild(tooltip);
                    
                    this.dataset.tooltip = true;
                });
                
                item.addEventListener('mouseleave', function() {
                    // Hapus tooltip
                    const tooltips = document.querySelectorAll('.sidebar-tooltip');
                    tooltips.forEach(el => el.remove());
                    delete this.dataset.tooltip;
                });
            });
        }
    }

    // Fungsi utama responsif sidebar
    function handleResponsiveSidebar() {
        // Di bagian paling atas fungsi (setelah deklarasi)
        const tableContainer = document.querySelector('.booking-table-container');

        if (window.innerWidth <= 768) {
            sidebar.classList.remove('collapsed');
            sidebar.classList.add('mobile');
            if (mainContent) mainContent.classList.remove('expanded');

            // Hapus event handler tooltip
            const menuItems = document.querySelectorAll('.nav-link');
            menuItems.forEach(item => {
                item.removeEventListener('mouseenter', () => {});
                item.removeEventListener('mouseleave', () => {});
            });

            // Tampilkan tombol mobile toggle, sembunyikan toggle desktop
            if (toggleBtn) toggleBtn.style.display = 'none';
            if (mobileToggleBtn) {
                mobileToggleBtn.style.display = 'block';
                mobileToggleBtn.removeEventListener('click', toggleMobileSidebar); // Pastikan tidak double
                mobileToggleBtn.addEventListener('click', toggleMobileSidebar);
            }
        } else {
            sidebar.classList.remove('mobile', 'visible');

            // Tampilkan toggle desktop, sembunyikan toggle mobile
            if (toggleBtn) {
                toggleBtn.style.display = 'block';
                toggleBtn.removeEventListener('click', toggleMobileSidebar);
                toggleBtn.addEventListener('click', toggleSidebar);
            }
            if (mobileToggleBtn) {
                mobileToggleBtn.style.display = 'none';
                mobileToggleBtn.removeEventListener('click', toggleMobileSidebar);
            }

            // Terapkan ulang status dari localStorage
            const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
            if (isCollapsed) {
                if (tableContainer) {
                    tableContainer.style.maxWidth = '1400px';
                }
                
                sidebar.classList.add('collapsed');
                if (mainContent) mainContent.classList.add('expanded');
                if (logoText) logoText.style.display = 'none';
                handleSidebarHover();
            } else {
                sidebar.classList.remove('collapsed');
                if (mainContent) mainContent.classList.remove('expanded');
                if (logoText) logoText.style.display = 'block';
            }

            
        }
    }

    // Event untuk toggle mobile
    if (mobileToggleBtn) {
        mobileToggleBtn.addEventListener('click', toggleMobileSidebar);
    }
    
    // Jalankan saat load dan saat resize
    window.addEventListener('load', handleResponsiveSidebar);
    window.addEventListener('resize', handleResponsiveSidebar);

    // Tambahkan overlay untuk mode mobile
    function createOverlay() {
        const existingOverlay = document.querySelector('.sidebar-overlay');
        if (existingOverlay) existingOverlay.remove();

        const overlay = document.createElement('div');
        overlay.className = 'sidebar-overlay';
        document.body.appendChild(overlay);

        overlay.addEventListener('click', function () {
            sidebar.classList.remove('visible');
            overlay.style.display = 'none';
        });

        return overlay;
    }

    const overlay = createOverlay();

    // Observer untuk toggle overlay saat sidebar mobile terlihat
    function observeSidebar() {
        const observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                if (mutation.target.classList.contains('visible')) {
                    overlay.style.display = 'block';
                    setTimeout(() => {
                        overlay.style.opacity = '1';
                    }, 10);
                } else {
                    overlay.style.opacity = '0';
                    setTimeout(() => {
                        overlay.style.display = 'none';
                    }, 300);
                }
            });
        });

        observer.observe(sidebar, { attributes: true, attributeFilter: ['class'] });
    }

    observeSidebar();

    // Handle active menu based on current page
    function setActiveMenu() {
        const currentPath = window.location.pathname;
        const currentPage = currentPath.substring(currentPath.lastIndexOf('/') + 1);
        
        const menuLinks = document.querySelectorAll('.nav-link');
        menuLinks.forEach(link => {
            if (link.getAttribute('href') === currentPage) {
                link.classList.add('active');
            }
        });
    }

    // Jalankan saat load dan resize
    handleResponsiveSidebar();
    setActiveMenu();
    handleSidebarHover();
    
    window.addEventListener('resize', function() {
        handleResponsiveSidebar();
        handleSidebarHover();
    });

    // Menu aktif
    const menuLinks = document.querySelectorAll('.nav-link');
    menuLinks.forEach(link => {
        link.addEventListener('click', function () {
            menuLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');

            if (window.innerWidth <= 768) {
                sidebar.classList.remove('visible');
                overlay.style.display = 'none';
            }
        });
    });
    
    // Double click pada sidebar header untuk toggle
    const sidebarHeader = document.querySelector('.sidebar-header');
    if (sidebarHeader) {
        sidebarHeader.addEventListener('dblclick', function() {
            if (window.innerWidth > 768) {
                toggleSidebar();
            }
        });
    }
    
    // Log to console that sidebar initialization is complete
    console.log('Sidebar initialization complete');
});