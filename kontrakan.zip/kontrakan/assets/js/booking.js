/**
 * booking.js - JavaScript for Booking Management
 * Contains all frontend functionality for the booking management system
 */

document.addEventListener('DOMContentLoaded', function() {
    // Global variables
    const itemsPerPage = 10;
    let currentPage = 1;
    let bookingsData = [];
    let filteredBookings = [];
    let currentFilter = 'all';
    
    // Initialize the page
    initBookingPage();
    
    /**
     * Initialize the booking page with event listeners and initial data
     */
    function initBookingPage() {
        console.log('Initializing booking page...');
        
        // Load bookings data
        loadBookings();
        
        // Set up event listeners
        setupEventListeners();
        
        // Initialize search functionality
        initSearch();
        
        // Display toast messages if any
        displayToastFromSession();
    }
    
    /**
     * Setup all event listeners for the page
     */
    function setupEventListeners() {
        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(button => {
            button.addEventListener('click', function() {
                const filterValue = this.getAttribute('data-filter');
                applyFilter(filterValue);
                
                // Update active class
                document.querySelectorAll('.filter-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
        
        // Modal close button
        document.querySelector('.close-modal').addEventListener('click', function() {
            document.getElementById('bookingDetailModal').style.display = 'none';
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('bookingDetailModal');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    }
    
    /**
     * Initialize search functionality
     */
    function initSearch() {
        const searchInput = document.getElementById('searchInput');
        
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            
            if (searchTerm.length === 0) {
                // Reset to current filter if search is cleared
                applyFilter(currentFilter);
            } else {
                // Search within current filtered data
                const baseData = currentFilter === 'all' ? bookingsData : 
                    bookingsData.filter(booking => booking.status_booking === currentFilter);
                
                filteredBookings = baseData.filter(booking => 
                    booking.nama_penyewa.toLowerCase().includes(searchTerm) || 
                    booking.nama_kontrakan.toLowerCase().includes(searchTerm) ||
                    booking.id.toString().includes(searchTerm)
                );
                
                renderBookings();
            }
        });
    }
    
    /**
     * Load bookings data from server
     */
    function loadBookings() {
        console.log('Loading booking data...');
        
        // Show loading state
        showLoading();
        
        // Fetch bookings from backend
        fetch('../logic/admin/get_bookings.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Bookings data loaded:', data);
                
                if (data.status === 'success') {
                    bookingsData = data.bookings;
                    filteredBookings = [...bookingsData];
                    
                    // Render bookings and update stats
                    renderBookings();
                    updateBookingStats();
                } else {
                    console.error('Error loading bookings:', data.message);
                    showToast('error', 'Gagal memuat data booking: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching bookings:', error);
                showToast('error', 'Gagal memuat data booking: ' + error.message);
            })
            .finally(() => {
                hideLoading();
            });
    }
    
    /**
     * Apply filter to bookings data
     * @param {string} filter - Filter value ('all', 'menunggu', 'terkonfirmasi', 'belum bayar', 'dibatalkan')
     */
    function applyFilter(filter) {
        console.log('Applying filter:', filter);
        currentFilter = filter;
        
        if (filter === 'all') {
            filteredBookings = [...bookingsData];
        } else {
            filteredBookings = bookingsData.filter(booking => booking.status_booking === filter);
        }
        
        currentPage = 1;
        renderBookings();
    }
    
    /**
     * Update booking stats display
     */
    function updateBookingStats() {
        console.log('Updating booking stats...');
        
        const pendingCount = bookingsData.filter(booking => booking.status_booking === 'menunggu').length;
        const confirmedCount = bookingsData.filter(booking => booking.status_booking === 'terkonfirmasi').length;
        const cancelledCount = bookingsData.filter(booking => booking.status_booking === 'dibatalkan').length;
        const unpaidCount = bookingsData.filter(booking => booking.status_booking === 'belum bayar').length;
        
        document.getElementById('pendingCount').textContent = pendingCount;
        document.getElementById('confirmedCount').textContent = confirmedCount;
        document.getElementById('cancelledCount').textContent = cancelledCount;
        document.getElementById('unpaidCount').textContent = unpaidCount;
    }
    
    /**
     * Render bookings table with pagination
     */
    function renderBookings() {
        console.log('Rendering bookings table...');
        const tableBody = document.getElementById('bookingTableBody');
        tableBody.innerHTML = '';
    
        const totalItems = filteredBookings.length;
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = Math.min(startIndex + itemsPerPage, totalItems);
    
        if (totalItems === 0) {
            const noDataRow = document.createElement('tr');
            noDataRow.innerHTML = `<td colspan="10" class="no-data">Tidak ada data booking yang ditemukan</td>`;
            tableBody.appendChild(noDataRow);
        } else {
            for (let i = startIndex; i < endIndex; i++) {
                const booking = filteredBookings[i];
                const row = document.createElement('tr');
    
                const bookingDate = new Date(booking.tanggal_booking);
                const formattedBookingDate = formatDate(bookingDate);
                const rentalPeriod = formatRentalPeriod(booking.tanggal_mulai, booking.tanggal_selesai);
                const formattedTotal = formatCurrency(booking.total_bayar);
                const statusClass = getStatusClass(booking.status_booking);
    
                row.innerHTML = `
                    <td>${booking.id}</td>
                    <td>${booking.nama_penyewa}</td>
                    <td>${booking.nama_kontrakan}</td>
                    <td>${formattedBookingDate}</td>
                    <td>${rentalPeriod}</td>
                    <td>${formattedTotal}</td>
                    <td>${formatPaymentMethod(booking.metode_pembayaran)}</td>
                    <td><span class="status-badge ${statusClass}">${formatStatus(booking.status_booking)}</span></td>
                    <td>
                        ${booking.metode_pembayaran === 'transfer' ? `
                            <button class="action-btn request-payment-btn" 
                                    data-id="${booking.id}" 
                                    data-user="${booking.id_penyewa}" 
                                    title="Minta Bukti Pembayaran">
                                <i class="fas fa-upload"></i>
                            </button>` : ''}
                    </td>
                    <td class="actions">
                        <button class="action-btn view-btn" data-id="${booking.id}" title="Lihat Detail">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${booking.status_booking === 'menunggu' ? `
                            <button class="action-btn confirm-btn" data-id="${booking.id}" title="Konfirmasi">
                                <i class="fas fa-check"></i>
                            </button>` : ''}
                        ${(booking.status_booking === 'menunggu' || booking.status_booking === 'belum bayar') ? `
                            <button class="action-btn cancel-btn" data-id="${booking.id}" title="Batalkan">
                                <i class="fas fa-times"></i>
                            </button>` : ''}
                    </td>
                `;
    
                tableBody.appendChild(row);
            }
    
            addActionButtonListeners(); // Pastikan fungsi ini terdefinisi
        }
    
        renderPagination(totalPages);
        document.getElementById('currentShowing').textContent = totalItems > 0 ? `${startIndex + 1}-${endIndex}` : '0';
        document.getElementById('totalItems').textContent = totalItems;
    }
    


    $(document).on('click', '.request-payment-btn', function() {
        const bookingId = $(this).data('id');
        const userId = $(this).data('user');
        const adminUserId = $('#adminUserId').val(); // Ambil dari hidden input
        
        // Ambil nama kontrakan dari baris yang sama
        const row = $(this).closest('tr');
        const namaKontrakan = row.find('td:nth-child(3)').text(); // Mengambil konten dari kolom ketiga (nama kontrakan)
        
        Swal.fire({
            title: 'Kirim Pesan ke User?',
            text: `Anda akan mengirim pesan untuk meminta upload ulang bukti pembayaran untuk kontrakan "${namaKontrakan}"`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Kirim',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Buat pesan dengan menyertakan nama kontrakan
                const message = `Silahkan upload ulang bukti pembayaran yang jelas untuk kontrakan "${namaKontrakan}". Jika tidak dilakukan selama batas waktu 1 jam, maka booking otomatis akan dibatalkan.`;
                
                $.ajax({
                    url: '../logic/admin/send_message_endpoint.php',
                    type: 'POST',
                    data: {
                        booking_id: bookingId,
                        user_id: userId,
                        admin_user_id: adminUserId,
                        message: message
                    },
                    success: function(response) {
                        Swal.fire('Berhasil!', 'Pesan telah dikirim ke user.', 'success');
                    },
                    error: function(xhr, status, error) {
                        console.error('Ajax error:', error, xhr.responseText);
                        Swal.fire('Gagal!', 'Terjadi kesalahan saat mengirim pesan.', 'error');
                    }
                });
            }
        });
    });
    
    
    /**
     * Add event listeners to action buttons in the table
     */
    function addActionButtonListeners() {
        // View buttons
        document.querySelectorAll('.view-btn').forEach(button => {
            button.addEventListener('click', function() {
                const bookingId = this.getAttribute('data-id');
                viewBookingDetails(bookingId);
            });
        });
        
        // Confirm buttons
        document.querySelectorAll('.confirm-btn').forEach(button => {
            button.addEventListener('click', function() {
                const bookingId = this.getAttribute('data-id');
                confirmBooking(bookingId);
            });
        });
        
        // Cancel buttons
        document.querySelectorAll('.cancel-btn').forEach(button => {
            button.addEventListener('click', function() {
                const bookingId = this.getAttribute('data-id');
                cancelBooking(bookingId);
            });
        });
    }
    
    /**
     * Render pagination controls
     * @param {number} totalPages - Total number of pages
     */
    function renderPagination(totalPages) {
        const pagination = document.getElementById('pagination');
        pagination.innerHTML = '';
        
        if (totalPages <= 1) {
            return;
        }
        
        // Previous button
        const prevBtn = document.createElement('button');
        prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
        prevBtn.className = 'pagination-btn';
        prevBtn.disabled = currentPage === 1;
        prevBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                renderBookings();
            }
        });
        pagination.appendChild(prevBtn);
        
        // Page buttons
        const maxVisiblePages = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
        
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        
        // First page button if not visible
        if (startPage > 1) {
            const firstPageBtn = document.createElement('button');
            firstPageBtn.textContent = '1';
            firstPageBtn.className = 'pagination-btn';
            firstPageBtn.addEventListener('click', () => {
                currentPage = 1;
                renderBookings();
            });
            pagination.appendChild(firstPageBtn);
            
            if (startPage > 2) {
                const ellipsis = document.createElement('span');
                ellipsis.textContent = '...';
                ellipsis.className = 'pagination-ellipsis';
                pagination.appendChild(ellipsis);
            }
        }
        
        // Page buttons
        for (let i = startPage; i <= endPage; i++) {
            const pageBtn = document.createElement('button');
            pageBtn.textContent = i;
            pageBtn.className = 'pagination-btn';
            if (i === currentPage) {
                pageBtn.classList.add('active');
            }
            pageBtn.addEventListener('click', () => {
                currentPage = i;
                renderBookings();
            });
            pagination.appendChild(pageBtn);
        }
        
        // Last page button if not visible
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                const ellipsis = document.createElement('span');
                ellipsis.textContent = '...';
                ellipsis.className = 'pagination-ellipsis';
                pagination.appendChild(ellipsis);
            }
            
            const lastPageBtn = document.createElement('button');
            lastPageBtn.textContent = totalPages;
            lastPageBtn.className = 'pagination-btn';
            lastPageBtn.addEventListener('click', () => {
                currentPage = totalPages;
                renderBookings();
            });
            pagination.appendChild(lastPageBtn);
        }
        
        // Next button
        const nextBtn = document.createElement('button');
        nextBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
        nextBtn.className = 'pagination-btn';
        nextBtn.disabled = currentPage === totalPages;
        nextBtn.addEventListener('click', () => {
            if (currentPage < totalPages) {
                currentPage++;
                renderBookings();
            }
        });
        pagination.appendChild(nextBtn);
    }
    
    /**
     * View booking details in modal
     * @param {string} bookingId - Booking ID
     */
    function viewBookingDetails(bookingId) {
        console.log('Viewing booking details for ID:', bookingId);
        
        // Show loading state
        showLoading();
        
        // Fetch booking details from backend
        fetch(`../logic/admin/get_booking_detail.php?id=${bookingId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Booking detail data loaded:', data);
                
                if (data.status === 'success') {
                    const booking = data.booking;
                    
                    // Format dates
                    const bookingDate = new Date(booking.tanggal_booking);
                    const formattedBookingDate = formatDate(bookingDate);
                    const startDate = new Date(booking.tanggal_mulai);
                    const endDate = new Date(booking.tanggal_selesai);
                    const formattedStartDate = formatDate(startDate);
                    const formattedEndDate = formatDate(endDate);
                    
                    // Format currency
                    const formattedTotal = formatCurrency(booking.total_bayar);
                    
                    // Generate modal content
                    const detailContent = document.getElementById('bookingDetailContent');
                    detailContent.innerHTML = `
                        <div class="detail-row">
                            <div class="detail-group">
                                <h3>Informasi Booking</h3>
                                <div class="detail-item">
                                    <span class="detail-label">ID Booking:</span>
                                    <span class="detail-value">${booking.id}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Tanggal Booking:</span>
                                    <span class="detail-value">${formattedBookingDate}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Status:</span>
                                    <span class="detail-value status-badge ${getStatusClass(booking.status_booking)}">${formatStatus(booking.status_booking)}</span>
                                </div>
                            </div>
                            
                            <div class="detail-group">
                                <h3>Informasi Penyewa</h3>
                                <div class="detail-item">
                                    <span class="detail-label">Nama:</span>
                                    <span class="detail-value">${booking.nama_penyewa}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Email:</span>
                                    <span class="detail-value">${booking.email_penyewa}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">No. Telepon:</span>
                                    <span class="detail-value">${booking.no_telepon_penyewa}</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="detail-row">
                            <div class="detail-group">
                                <h3>Informasi Kontrakan</h3>
                                <div class="detail-item">
                                    <span class="detail-label">Nama:</span>
                                    <span class="detail-value">${booking.nama_kontrakan}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Lokasi:</span>
                                    <span class="detail-value">${booking.lokasi}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Alamat:</span>
                                    <span class="detail-value">${booking.alamat_lengkap}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Pemilik:</span>
                                    <span class="detail-value">${booking.kontak_pemilik}</span>
                                </div>
                            </div>
                            
                            <div class="detail-group">
                                <h3>Informasi Sewa</h3>
                                <div class="detail-item">
                                    <span class="detail-label">Periode Sewa:</span>
                                    <span class="detail-value">${formattedStartDate} - ${formattedEndDate}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Total Bayar:</span>
                                    <span class="detail-value">${formattedTotal}</span>
                                </div>
                                <div class="detail-item">
                                    <span class="detail-label">Metode Pembayaran:</span>
                                    <span class="detail-value">${formatPaymentMethod(booking.metode_pembayaran)}</span>
                                </div>
                            </div>
                        </div>
                        
                        ${booking.keterangan ? `
                        <div class="detail-row">
                            <div class="detail-group full-width">
                                <h3>Keterangan</h3>
                                <div class="detail-note">
                                    ${booking.keterangan}
                                </div>
                            </div>
                        </div>` : ''}
                        
                        ${booking.bukti_pembayaran ? `
                        <div class="detail-row">
                            <div class="detail-group full-width">
                                <h3>Bukti Pembayaran</h3>
                                <div class="payment-proof">
                                    <img src="../user/bukti_pembayaran/${booking.bukti_pembayaran}" alt="Bukti Pembayaran">
                                </div>
                            </div>
                        </div>` : ''}
                    `;
                    
                    // Set modal action buttons
                    const modalActions = document.getElementById('modalActions');
                    modalActions.innerHTML = '';
                    
                    // Add appropriate action buttons based on booking status
                    if (booking.status_booking === 'menunggu') {
                        const confirmBtn = document.createElement('button');
                        confirmBtn.className = 'modal-btn confirm-btn';
                        confirmBtn.innerHTML = '<i class="fas fa-check"></i> Konfirmasi Booking';
                        confirmBtn.addEventListener('click', () => confirmBooking(booking.id, true));
                        modalActions.appendChild(confirmBtn);
                        
                        const cancelBtn = document.createElement('button');
                        cancelBtn.className = 'modal-btn cancel-btn';
                        cancelBtn.innerHTML = '<i class="fas fa-times"></i> Batalkan Booking';
                        cancelBtn.addEventListener('click', () => cancelBooking(booking.id, true));
                        modalActions.appendChild(cancelBtn);
                    } else if (booking.status_booking === 'belum bayar') {
                        const cancelBtn = document.createElement('button');
                        cancelBtn.className = 'modal-btn cancel-btn';
                        cancelBtn.innerHTML = '<i class="fas fa-times"></i> Batalkan Booking';
                        cancelBtn.addEventListener('click', () => cancelBooking(booking.id, true));
                        modalActions.appendChild(cancelBtn);
                    }
                    
                    const closeBtn = document.createElement('button');
                    closeBtn.className = 'modal-btn close-btn';
                    closeBtn.innerHTML = '<i class="fas fa-times-circle"></i> Tutup';
                    closeBtn.addEventListener('click', () => {
                        document.getElementById('bookingDetailModal').style.display = 'none';
                    });
                    modalActions.appendChild(closeBtn);
                    
                    // Show modal
                    document.getElementById('bookingDetailModal').style.display = 'block';
                } else {
                    console.error('Error loading booking details:', data.message);
                    showToast('error', 'Gagal memuat detail booking: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching booking details:', error);
                showToast('error', 'Gagal memuat detail booking: ' + error.message);
            })
            .finally(() => {
                hideLoading();
            });
    }
    
    /**
     * Confirm a booking
     * @param {string} bookingId - Booking ID
     * @param {boolean} fromModal - Whether the action is triggered from modal
     */
    function confirmBooking(bookingId, fromModal = false) {
        console.log('Confirming booking ID:', bookingId);
        
        Swal.fire({
            title: 'Konfirmasi Booking',
            text: 'Apakah Anda yakin ingin mengkonfirmasi booking ini?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Konfirmasi',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading state
                showLoading();
                
                // Send confirmation request to backend
                fetch('../logic/admin/update_booking_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `id=${bookingId}&status=terkonfirmasi`
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Booking confirmation response:', data);
                    
                    if (data.status === 'success') {
                        // Show success message
                        showToast('success', 'Booking berhasil dikonfirmasi');
                        
                        // Reload bookings data
                        loadBookings();
                        
                        // Close modal if action was from modal
                        if (fromModal) {
                            document.getElementById('bookingDetailModal').style.display = 'none';
                        }
                    } else {
                        console.error('Error confirming booking:', data.message);
                        showToast('error', 'Gagal mengkonfirmasi booking: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error confirming booking:', error);
                    showToast('error', 'Gagal mengkonfirmasi booking: ' + error.message);
                })
                .finally(() => {
                    hideLoading();
                });
            }
        });
    }
    
    /**
     * Cancel a booking
     * @param {string} bookingId - Booking ID
     * @param {boolean} fromModal - Whether the action is triggered from modal
     */
    function cancelBooking(bookingId, fromModal = false) {
        console.log('Cancelling booking ID:', bookingId);
        
        Swal.fire({
            title: 'Batalkan Booking',
            text: 'Apakah Anda yakin ingin membatalkan booking ini?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Batalkan',
            cancelButtonText: 'Tidak'
        }).then((result) => {
            if (result.isConfirmed) {
                // Prompt for cancellation reason
                Swal.fire({
                    title: 'Alasan Pembatalan',
                    input: 'textarea',
                    inputPlaceholder: 'Masukkan alasan pembatalan booking',
                    showCancelButton: true,
                    confirmButtonText: 'Batalkan Booking',
                    cancelButtonText: 'Batal',
                    showLoaderOnConfirm: true,
                    preConfirm: (keterangan) => {
                        return new Promise((resolve) => {
                            // Send cancellation request to backend
                            fetch('../logic/admin/update_booking_status.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded',
                                },
                                body: `id=${bookingId}&status=dibatalkan&keterangan=${encodeURIComponent(keterangan || '')}`
                            })
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Network response was not ok');
                                }
                                return response.json();
                            })
                            .then(data => {
                                if (data.status === 'success') {
                                    resolve(data);
                                } else {
                                    Swal.showValidationMessage(`Gagal: ${data.message}`);
                                }
                            })
                            .catch(error => {
                                Swal.showValidationMessage(`Error: ${error.message}`);
                            });
                        });
                    },
                    allowOutsideClick: () => !Swal.isLoading()
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Show success message
                        showToast('success', 'Booking berhasil dibatalkan');
                        
                        // Reload bookings data
                        loadBookings();
                        
                        // Close modal if action was from modal
                        if (fromModal) {
                            document.getElementById('bookingDetailModal').style.display = 'none';
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Format date to Indonesian format (DD/MM/YYYY)
     * @param {Date} date - Date object
     * @returns {string} - Formatted date string
     */
    function formatDate(date) {
        if (!date || isNaN(date.getTime())) {
            return '-';
        }
        return date.toLocaleDateString('id-ID', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
    }
    
    /**
     * Format rental period
     * @param {string} startDate - Start date
     * @param {string} endDate - End date
     * @returns {string} - Formatted rental period
     */
    function formatRentalPeriod(startDate, endDate) {
        if (!startDate || !endDate) {
            return '-';
        }
        
        const start = new Date(startDate);
        const end = new Date(endDate);
        
        if (isNaN(start.getTime()) || isNaN(end.getTime())) {
            return '-';
        }
        
        return `${formatDate(start)} - ${formatDate(end)}`;
    }
    
    /**
     * Format currency to Indonesian Rupiah
     * @param {number} amount - Amount to format
     * @returns {string} - Formatted currency string
     */
    function formatCurrency(amount) {
        if (amount === null || amount === undefined) {
            return 'Rp 0';
        }
        
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(amount);
    }
    
    /**
     * Format payment method for display
     * @param {string} method - Payment method ('tunai' or 'transfer')
     * @returns {string} - Formatted payment method
     */
    function formatPaymentMethod(method) {
        if (!method) return '-';
        
        const methods = {
            'tunai': 'Tunai',
            'transfer': 'Transfer Bank'
        };
        
        return methods[method] || method;
    }
    
    /**
     * Format status for display
     * @param {string} status - Booking status
     * @returns {string} - Formatted status
     */
    function formatStatus(status) {
        if (!status) return '-';
        
        const statuses = {
            'belum bayar': 'Belum Bayar',
            'menunggu': 'Menunggu Konfirmasi',
            'terkonfirmasi': 'Terkonfirmasi',
            'dibatalkan': 'Dibatalkan'
        };
        
        return statuses[status] || status;
    }
    
    /**
     * Get status class for styling
     * @param {string} status - Booking status
     * @returns {string} - CSS class for the status
     */
    function getStatusClass(status) {
        if (!status) return '';
        
        const statusClasses = {
            'belum bayar': 'status-unpaid',
            'menunggu': 'status-pending',
            'terkonfirmasi': 'status-confirmed',
            'dibatalkan': 'status-cancelled'
        };
        
        return statusClasses[status] || '';
    }
    
    /**
     * Show loading state
     */
    function showLoading() {
        // Implementation depends on your design
        // This could be a spinner overlay or similar
        console.log('Showing loading state...');
        
        // You can implement this according to your UI design
    }
    
    /**
     * Hide loading state
     */
    function hideLoading() {
        // Implementation depends on your design
        console.log('Hiding loading state...');
        
        // You can implement this according to your UI design
    }
    
    /**
     * Display toast notification
     * @param {string} type - Toast type ('success', 'error', 'info', 'warning')
     * @param {string} message - Toast message
     */
    function showToast(type, message) {
        console.log(`Showing ${type} toast:`, message);
        
        const icons = {
            'success': 'check-circle',
            'error': 'times-circle',
            'warning': 'exclamation-triangle',
            'info': 'info-circle'
        };
        
        const icon = icons[type] || 'info-circle';
        
        Swal.fire({
            title: '',
            text: message,
            icon: type,
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true
        });
    }
    
    /**
     * Check for and display toast messages from PHP session
     */
    function displayToastFromSession() {
        // Using a hidden input field that PHP would populate with session messages
        const sessionMessage = document.getElementById('session-message');
        const sessionMessageType = document.getElementById('session-message-type');
        
        if (sessionMessage && sessionMessage.value) {
            showToast(sessionMessageType.value || 'info', sessionMessage.value);
            
            // Clear the message after displaying
            sessionMessage.value = '';
            sessionMessageType.value = '';
        }
    }
});

