document.addEventListener('DOMContentLoaded', function() {
    // Header scroll effect
    const header = document.querySelector('header');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const menu = document.querySelector('.menu');
    
    menuToggle.addEventListener('click', function() {
        menu.classList.toggle('active');
    });

    // Close menu when clicking on a link
    const menuLinks = document.querySelectorAll('.menu ul li a');
    menuLinks.forEach(link => {
        link.addEventListener('click', function() {
            menu.classList.remove('active');
        });
    });

    // FAQ accordion
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        question.addEventListener('click', function() {
            // Close all other open FAQ items
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });
            // Toggle current item
            item.classList.toggle('active');
        });
    });

    // Contact form submission
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const nama = document.getElementById('nama').value;
            const email = document.getElementById('email').value;
            const telepon = document.getElementById('telepon').value;
            const pesan = document.getElementById('pesan').value;
            
            // Validate form data
            if (!nama || !email || !telepon || !pesan) {
                Swal.fire({
                    title: 'Error!',
                    text: 'Semua field harus diisi!',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#4361ee',
                });
                return;
            }
            
            // Here you would typically send the data to a server
            // For demo purposes, we'll just show a success message
            
            Swal.fire({
                title: 'Berhasil!',
                text: 'Pesan Anda telah terkirim. Kami akan menghubungi Anda segera.',
                icon: 'success',
                confirmButtonText: 'OK',
                confirmButtonColor: '#4361ee',
            });
            
            // Reset form
            contactForm.reset();
        });
    }

    // Newsletter form submission
    const newsletterForm = document.getElementById('newsletterForm');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = this.querySelector('input[type="email"]').value;
            
            if (!email) {
                Swal.fire({
                    title: 'Error!',
                    text: 'Email tidak boleh kosong!',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#4361ee',
                });
                return;
            }
            
            // Here you would typically send the email to a server
            // For demo purposes, we'll just show a success message
            
            Swal.fire({
                title: 'Berhasil!',
                text: 'Anda telah berlangganan newsletter kami!',
                icon: 'success',
                confirmButtonText: 'OK',
                confirmButtonColor: '#4361ee',
            });
            
            // Reset form
            newsletterForm.reset();
        });
    }

    // Filter kontrakan
    const filterButton = document.getElementById('apply-filter');
    const kontrakanCards = document.querySelectorAll('.kontrakan-card');
    
    if (filterButton) {
        filterButton.addEventListener('click', function() {
            const tipeTerpilih = document.getElementById('filter-tipe').value;
            const lokasiTerpilih = document.getElementById('filter-lokasi').value;
            const hargaMin = parseFloat(document.getElementById('filter-harga-min').value) || 0;
            const hargaMax = parseFloat(document.getElementById('filter-harga-max').value) || Infinity;
            
            let adaHasilFilter = false;
            
            kontrakanCards.forEach(card => {
                const tipe = card.getAttribute('data-tipe');
                const lokasi = card.getAttribute('data-lokasi');
                const harga = parseFloat(card.getAttribute('data-harga'));
                
                const tipeCocok = tipeTerpilih === 'semua' || tipe === tipeTerpilih;
                const lokasiCocok = lokasiTerpilih === 'semua' || lokasi === lokasiTerpilih;
                const hargaCocok = harga >= hargaMin && harga <= hargaMax;
                
                if (tipeCocok && lokasiCocok && hargaCocok) {
                    card.style.display = 'block';
                    adaHasilFilter = true;
                } else {
                    card.style.display = 'none';
                }
            });
            
            // Show message if no results
            const noDataElement = document.querySelector('.no-data');
            if (noDataElement) {
                noDataElement.remove();
            }
            
            if (!adaHasilFilter) {
                const noDataDiv = document.createElement('div');
                noDataDiv.className = 'no-data';
                noDataDiv.textContent = 'Tidak ada kontrakan yang sesuai dengan filter Anda.';
                document.querySelector('.kontrakan-container').appendChild(noDataDiv);
            }
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('header').offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Active menu item based on scroll position
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('.menu ul li a');
    
    window.addEventListener('scroll', function() {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (scrollY >= (sectionTop - 100)) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });

    // Animation on scroll (simple implementation)
    const animateElements = document.querySelectorAll('.section-header, .kontrakan-card, .tentang-content, .keunggulan-item, .faq-item, .kontak-container');
    
    function checkVisibility() {
        animateElements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight;
            
            if (elementPosition < screenPosition - 100) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    }
    
    // Initial styles for animation
    animateElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    });
    
    // Check on load and scroll
    window.addEventListener('load', checkVisibility);
    window.addEventListener('scroll', checkVisibility);
});

function confirmLogout(e) {
    e.preventDefault();

    Swal.fire({
        title: 'Anda yakin ingin logout?',
        text: "Sesi Anda akan diakhiri.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, logout',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../logic/user/logout.php';
        }
    });
}