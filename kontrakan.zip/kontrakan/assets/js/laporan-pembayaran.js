/**
 * Laporan Pembayaran - JavaScript
 * Script untuk mengelola fungsi laporan pembayaran dan export PDF
 */

// Menunggu DOM selesai dimuat
document.addEventListener('DOMContentLoaded', () => {
    // Inisialisasi variabel global
    const app = {
        currentPage: 1,
        totalPages: 1,
        limit: 10,
        filters: {
            tanggal_mulai: '',
            tanggal_selesai: '',
            metode: 'all'
        },
        pembayaranData: [],
        statistik: {}
    };

    // Inisialisasi event listeners
    initEventListeners();
    
    // Load data awal
    loadPembayaranData();

    /**
     * Inisialisasi semua event listener
     */
    function initEventListeners() {
        // Event listener untuk filter periode
        document.getElementById('periode').addEventListener('change', handlePeriodeChange);
        
        // Event listener untuk tombol filter
        document.getElementById('btnFilter').addEventListener('click', handleFilter);
        
        // Event listener untuk pagination
        document.getElementById('btnPrev').addEventListener('click', () => navigatePage(app.currentPage - 1));
        document.getElementById('btnNext').addEventListener('click', () => navigatePage(app.currentPage + 1));
        
        // Event listener untuk download PDF
        document.getElementById('downloadPdf').addEventListener('click', handleDownloadPDF);
        
        // Event listener untuk close modal
        document.querySelector('.close-modal').addEventListener('click', () => {
            document.getElementById('detailModal').style.display = 'none';
        });
        
        // Close modal saat klik di luar modal
        window.addEventListener('click', (event) => {
            const modal = document.getElementById('detailModal');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    }
    
    /**
     * Menampilkan toast notification
     * @param {string} message - Pesan yang akan ditampilkan
     * @param {string} type - Tipe toast ('success' atau 'error')
     */
    function showToast(message, type = 'success') {
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: type,
            title: message,
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });
    }
    
    /**
     * Menangani perubahan pada filter periode
     */
    function handlePeriodeChange() {
        const periodeSelect = document.getElementById('periode');
        const dateFilterContainer = document.getElementById('dateFilterContainer');
        const tanggalMulai = document.getElementById('tanggalMulai');
        const tanggalSelesai = document.getElementById('tanggalSelesai');
        
        // Reset tanggal
        tanggalMulai.value = '';
        tanggalSelesai.value = '';
        
        const today = new Date();
        const formatDate = (date) => {
            return date.toISOString().split('T')[0]; // Format YYYY-MM-DD
        };
        
        switch (periodeSelect.value) {
            case 'daily':
                // Hari ini
                tanggalMulai.value = formatDate(today);
                tanggalSelesai.value = formatDate(today);
                break;
                
            case 'monthly':
                // Bulan ini
                const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
                tanggalMulai.value = formatDate(firstDayOfMonth);
                tanggalSelesai.value = formatDate(today);
                break;
                
            case 'yearly':
                // Tahun ini
                const firstDayOfYear = new Date(today.getFullYear(), 0, 1);
                tanggalMulai.value = formatDate(firstDayOfYear);
                tanggalSelesai.value = formatDate(today);
                break;
                
            default:
                // Kosongkan filter tanggal
                break;
        }
    }
    
    /**
     * Menangani klik tombol filter
     */
    function handleFilter() {
        // Reset halaman ke awal saat filter berubah
        app.currentPage = 1;
        
        // Simpan filter ke state
        app.filters.tanggal_mulai = document.getElementById('tanggalMulai').value;
        app.filters.tanggal_selesai = document.getElementById('tanggalSelesai').value;
        app.filters.metode = document.getElementById('metode').value;
        
        // Load data dengan filter
        loadPembayaranData();
    }
    
    /**
     * Memuat data pembayaran dari server
     */
    function loadPembayaranData() {
        // Membangun query string untuk filter
        const queryParams = new URLSearchParams();
        queryParams.append('action', 'get_data'); // Pastikan parameter action dikirimkan dengan benar
        queryParams.append('page', app.currentPage);
        queryParams.append('limit', app.limit);
        
        if (app.filters.tanggal_mulai) {
            queryParams.append('tanggal_mulai', app.filters.tanggal_mulai);
        }
        
        if (app.filters.tanggal_selesai) {
            queryParams.append('tanggal_selesai', app.filters.tanggal_selesai);
        }
        
        if (app.filters.metode && app.filters.metode !== 'all') {
            queryParams.append('metode', app.filters.metode);
        }
        
        // Tentukan URL endpoint dengan tepat
        const apiUrl = 'laporan_pembayaran.php';  // Sesuaikan path ini sesuai struktur proyek Anda
        
        // Tampilkan loading state
        document.getElementById('pembayaranData').innerHTML = '<tr><td colspan="8" class="text-center">Memuat data...</td></tr>';
        
        // Debug: Log URL yang dikirimkan
        console.log(`Fetching: ${apiUrl}?${queryParams.toString()}`);
        
        // Fetch data dari server
        fetch(`${apiUrl}?${queryParams.toString()}`)
            .then(response => {
                console.log('Response status:', response.status);
                return response.json();
            })
            .then(result => {
                console.log('API response:', result);
                if (result.status === 'success') {
                    // Simpan data ke variabel global
                    app.pembayaranData = result.data.pembayaran.data;
                    app.totalPages = result.data.pembayaran.pages;
                    app.statistik = result.data.statistik;
                    
                    // Render data ke UI
                    renderPembayaranData();
                    renderStatistik();
                    renderPagination();
                } else {
                    showToast(result.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                showToast('Terjadi kesalahan saat memuat data', 'error');
                document.getElementById('pembayaranData').innerHTML = '<tr><td colspan="8" class="text-center">Gagal memuat data</td></tr>';
            });
    }
    
    /**
     * Render data pembayaran ke tabel
     */
    function renderPembayaranData() {
        const tableBody = document.getElementById('pembayaranData');
        
        // Bersihkan tabel
        tableBody.innerHTML = '';
        
        if (app.pembayaranData.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="8" class="text-center">Tidak ada data</td></tr>';
            return;
        }
        
        // Render baris tabel
        app.pembayaranData.forEach(item => {
            const row = document.createElement('tr');
            
            // Format mata uang
            const formatCurrency = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            }).format(item.jumlah);
            
            // Styling untuk status
            const statusClass = item.status_pembayaran === 'lunas' ? 'status-lunas' : 'status-belum-lunas';
            
            row.innerHTML = `
                <td>${item.id}</td>
                <td>${item.nama_penyewa}</td>
                <td>${item.nama_kontrakan}</td>
                <td>${formatCurrency}</td>
                <td>${item.tanggal_pembayaran}</td>
                <td>${capitalizeFirst(item.metode)}</td>
                <td><span class="status ${statusClass}">${capitalizeFirst(item.status_pembayaran)}</span></td>
                <td>
                    <button class="btn btn-detail" data-id="${item.id}">
                        <i class="fas fa-eye"></i> Detail
                    </button>
                </td>
            `;
            
            tableBody.appendChild(row);
        });
        
        // Tambahkan event listener untuk tombol detail
        document.querySelectorAll('.btn-detail').forEach(button => {
            button.addEventListener('click', () => {
                const id = button.getAttribute('data-id');
                loadDetailPembayaran(id);
            });
        });
        
        // Update info pagination
        const from = (app.currentPage - 1) * app.limit + 1;
        const to = Math.min(from + app.pembayaranData.length - 1, app.statistik.jumlah_transaksi);
        
        document.getElementById('showingFrom').textContent = from;
        document.getElementById('showingTo').textContent = to;
        document.getElementById('totalData').textContent = app.statistik.jumlah_transaksi;
    }
    
    /**
     * Render data statistik ke dalam cards
     */
    function renderStatistik() {
        // Format mata uang
        const formatCurrency = (value) => {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            }).format(value);
        };
        
        // Update statistik cards
        document.getElementById('totalPendapatan').textContent = formatCurrency(app.statistik.total_pendapatan);
        document.getElementById('jumlahTransaksi').textContent = app.statistik.jumlah_transaksi;
        document.getElementById('pendapatanTunai').textContent = formatCurrency(app.statistik.pendapatan_tunai);
        document.getElementById('pendapatanTransfer').textContent = formatCurrency(app.statistik.pendapatan_transfer);
    }
    
    /**
     * Render pagination controls
     */
    function renderPagination() {
        const pageNumbers = document.getElementById('pageNumbers');
        pageNumbers.innerHTML = '';
        
        // Aktifkan/nonaktifkan tombol prev/next
        document.getElementById('btnPrev').disabled = app.currentPage <= 1;
        document.getElementById('btnNext').disabled = app.currentPage >= app.totalPages;
        
        // Jika hanya ada sedikit halaman, tampilkan semua
        if (app.totalPages <= 5) {
            for (let i = 1; i <= app.totalPages; i++) {
                createPageButton(i);
            }
        } else {
            // Tampilkan halaman pertama
            createPageButton(1);
            
            // Tampilkan ellipsis jika perlu
            if (app.currentPage > 3) {
                const ellipsis = document.createElement('span');
                ellipsis.className = 'page-ellipsis';
                ellipsis.textContent = '...';
                pageNumbers.appendChild(ellipsis);
            }
            
            // Tampilkan halaman di sekitar halaman aktif
            const start = Math.max(2, app.currentPage - 1);
            const end = Math.min(app.totalPages - 1, app.currentPage + 1);
            
            for (let i = start; i <= end; i++) {
                createPageButton(i);
            }
            
            // Tampilkan ellipsis jika perlu
            if (app.currentPage < app.totalPages - 2) {
                const ellipsis = document.createElement('span');
                ellipsis.className = 'page-ellipsis';
                ellipsis.textContent = '...';
                pageNumbers.appendChild(ellipsis);
            }
            
            // Tampilkan halaman terakhir
            if (app.totalPages > 1) {
                createPageButton(app.totalPages);
            }
        }
    }
    
    /**
     * Membuat tombol pagination
     * @param {number} pageNum - Nomor halaman
     */
    function createPageButton(pageNum) {
        const button = document.createElement('button');
        button.className = `btn page-number ${pageNum === app.currentPage ? 'active' : ''}`;
        button.textContent = pageNum;
        button.addEventListener('click', () => navigatePage(pageNum));
        document.getElementById('pageNumbers').appendChild(button);
    }
    
    /**
     * Navigasi ke halaman tertentu
     * @param {number} pageNum - Nomor halaman yang dituju
     */
    function navigatePage(pageNum) {
        if (pageNum < 1 || pageNum > app.totalPages || pageNum === app.currentPage) {
            return;
        }
        
        app.currentPage = pageNum;
        loadPembayaranData();
    }
    
    /**
     * Memuat detail pembayaran
     * @param {number} id - ID pembayaran
     */
    function loadDetailPembayaran(id) {
        const queryParams = new URLSearchParams();
        queryParams.append('action', 'get_detail'); // Pastikan parameter action dikirimkan dengan benar
        queryParams.append('id', id);
        
        // Tentukan URL endpoint dengan tepat
        const apiUrl = 'laporan_pembayaran.php';  // Sesuaikan path ini sesuai struktur proyek Anda
        
        // Debug: Log URL yang dikirimkan
        console.log(`Loading detail: ${apiUrl}?${queryParams.toString()}`);
        
        // Tampilkan loading di modal
        document.getElementById('detailContent').innerHTML = '<div class="loading-spinner">Memuat data...</div>';
        document.getElementById('detailModal').style.display = 'flex';
        
        // Fetch data detail pembayaran
        fetch(`${apiUrl}?${queryParams.toString()}`)
            .then(response => {
                console.log('Detail response status:', response.status);
                return response.json();
            })
            .then(result => {
                console.log('Detail API response:', result);
                if (result.status === 'success') {
                    renderDetailPembayaran(result.data);
                } else {
                    document.getElementById('detailContent').innerHTML = `<div class="error-message">${result.message}</div>`;
                }
            })
            .catch(error => {
                console.error('Error fetching detail:', error);
                document.getElementById('detailContent').innerHTML = '<div class="error-message">Terjadi kesalahan saat memuat data</div>';
            });
    }
    
    /**
     * Render detail pembayaran ke dalam modal
     * @param {Object} detail - Data detail pembayaran
     */
    function renderDetailPembayaran(detail) {
        // Format mata uang
        const formatCurrency = (value) => {
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            }).format(value);
        };
        
        // Styling untuk status
        const statusClass = detail.status_pembayaran === 'lunas' ? 'status-lunas' : 'status-belum-lunas';
        
        // Generate HTML untuk detail pembayaran
        const html = `
            <div class="detail-pembayaran">
                <div class="detail-section">
                    <h3>Informasi Pembayaran</h3>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">ID Pembayaran:</span>
                            <span class="detail-value">${detail.id}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Tanggal Pembayaran:</span>
                            <span class="detail-value">${detail.tanggal_pembayaran}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Jumlah:</span>
                            <span class="detail-value">${formatCurrency(detail.jumlah)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Metode Pembayaran:</span>
                            <span class="detail-value">${capitalizeFirst(detail.metode)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Status Pembayaran:</span>
                            <span class="status detail-value ${statusClass}">${capitalizeFirst(detail.status_pembayaran)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Keterangan:</span>
                            <span class="detail-value">${detail.keterangan || '-'}</span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Informasi Penyewa</h3>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Nama Penyewa:</span>
                            <span class="detail-value">${detail.nama_penyewa}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">No. Telepon:</span>
                            <span class="detail-value">${detail.no_telepon}</span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Informasi Kontrakan</h3>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Nama Kontrakan:</span>
                            <span class="detail-value">${detail.nama_kontrakan}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Lokasi:</span>
                            <span class="detail-value">${detail.lokasi}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Alamat:</span>
                            <span class="detail-value">${detail.alamat_lengkap}</span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Informasi Penyewaan</h3>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Tanggal Mulai:</span>
                            <span class="detail-value">${detail.tanggal_mulai}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Tanggal Selesai:</span>
                            <span class="detail-value">${detail.tanggal_selesai}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Durasi Sewa:</span>
                            <span class="detail-value">${detail.durasi_sewa} bulan</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Harga Sewa:</span>
                            <span class="detail-value">${formatCurrency(detail.harga_sewa)}/bulan</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Total Bayar:</span>
                            <span class="detail-value">${formatCurrency(detail.total_bayar)}</span>
                        </div>
                    </div>
                </div>
                
                ${detail.bukti_pembayaran ? `
                <div class="detail-section">
                    <h3>Bukti Pembayaran</h3>
                    <div class="bukti-pembayaran">
                        <img src="../user/bukti_pembayaran/${detail.bukti_pembayaran}" alt="Bukti Pembayaran">
                    </div>
                </div>
                ` : ''}
            </div>
        `;
        
        document.getElementById('detailContent').innerHTML = html;
    }
    
/**
 * Menangani klik tombol download PDF
 */
function handleDownloadPDF() {
    // Tampilkan indikator loading
    Swal.fire({
        title: 'Generating PDF',
        html: 'Mohon tunggu...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    // Ambil filter yang aktif
    const filters = {
        tanggal_mulai: document.getElementById('tanggalMulai')?.value || '',
        tanggal_selesai: document.getElementById('tanggalSelesai')?.value || '',
        metode: document.getElementById('metode')?.value || 'all'
    };
    
    // Buat URL untuk mengambil data
    let url = 'laporan_pembayaran.php?action=get_data';
    
    // Tambahkan parameter filter jika ada
    if (filters.tanggal_mulai) {
        url += `&tanggal_mulai=${filters.tanggal_mulai}`;
    }
    if (filters.tanggal_selesai) {
        url += `&tanggal_selesai=${filters.tanggal_selesai}`;
    }
    if (filters.metode && filters.metode !== 'all') {
        url += `&metode=${filters.metode}`;
    }
    
    // Tambahkan parameter limit untuk mendapatkan semua data
    url += '&limit=1000'; // Ambil banyak data untuk PDF
    
    // Fetch data untuk PDF
    fetch(url)
        .then(response => response.json())
        .then(result => {
            if (result.status === 'success') {
                // Persiapkan template invoice dengan data dari server
                prepareInvoiceTemplate(result.data.pembayaran.data, result.data.statistik, filters);
                
                // Generate PDF
                generatePDF();
            } else {
                Swal.close();
                showToast('Gagal memuat data untuk PDF: ' + result.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error fetching data for PDF:', error);
            Swal.close();
            showToast('Terjadi kesalahan saat memuat data: ' + error.message, 'error');
        });
}

/**
 * Menyiapkan template invoice untuk PDF
 * @param {Array} pembayaranData - Data pembayaran
 * @param {Object} statistik - Data statistik pembayaran
 * @param {Object} filters - Filter yang digunakan
 */
function prepareInvoiceTemplate(pembayaranData, statistik, filters) {
    // Format mata uang
    const formatCurrency = (value) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(value);
    };
    
    // Format tanggal untuk invoice
    const today = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('invoiceDate').textContent = today.toLocaleDateString('id-ID', options);
    document.getElementById('invoiceGeneratedDate').textContent = today.toLocaleDateString('id-ID', options) + 
                                                                ' ' + today.toLocaleTimeString('id-ID');
    
    // Set periode
    let periodeText = 'Semua Transaksi';
    if (filters.tanggal_mulai && filters.tanggal_selesai) {
        const tglMulai = new Date(filters.tanggal_mulai).toLocaleDateString('id-ID');
        const tglSelesai = new Date(filters.tanggal_selesai).toLocaleDateString('id-ID');
        periodeText = `${tglMulai} sampai ${tglSelesai}`;
    } else if (filters.metode && filters.metode !== 'all') {
        periodeText = `Metode Pembayaran: ${capitalizeFirst(filters.metode)}`;
    }
    document.getElementById('invoicePeriode').textContent = periodeText;
    
    // Set statistik
    document.getElementById('invoiceTotalPendapatan').textContent = formatCurrency(statistik.total_pendapatan);
    document.getElementById('invoiceJumlahTransaksi').textContent = statistik.jumlah_transaksi;
    document.getElementById('invoicePendapatanTunai').textContent = formatCurrency(statistik.pendapatan_tunai);
    document.getElementById('invoicePendapatanTransfer').textContent = formatCurrency(statistik.pendapatan_transfer);
    
    // Bersihkan tabel invoice
    const invoiceData = document.getElementById('invoiceData');
    invoiceData.innerHTML = '';
    
    // Isi data tabel invoice dengan semua pembayaran
    pembayaranData.forEach(item => {
        const row = document.createElement('tr');
        
        // Format mata uang
        const formattedJumlah = formatCurrency(item.jumlah);
        
        row.innerHTML = `
            <td>${item.id}</td>
            <td>${item.nama_penyewa}</td>
            <td>${item.nama_kontrakan}</td>
            <td>${formattedJumlah}</td>
            <td>${item.tanggal_pembayaran}</td>
            <td>${capitalizeFirst(item.metode)}</td>
            <td>${capitalizeFirst(item.status_pembayaran)}</td>
        `;
        
        invoiceData.appendChild(row);
    });
}

/**
 * Generate dan download PDF
 */
function generatePDF() {
    try {
        // Ambil template invoice
        const invoiceTemplate = document.getElementById('invoiceTemplate');
        invoiceTemplate.style.display = 'block';
        
        const filename = 'laporan-pembayaran-' + formatDateForFilename(new Date());
        
        // Definisikan opsi untuk html2pdf
        const opt = {
            margin: [10, 10, 10, 10],
            filename: `${filename}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { 
                scale: 2, 
                useCORS: true, 
                letterRendering: true
            },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
            pagebreak: { mode: 'css', before: '.page-break', avoid: ['tr', '.avoid-break'] }
        };
        
        // Generate PDF
        html2pdf().set(opt).from(invoiceTemplate).save()
            .then(() => {
                // Sembunyikan template lagi setelah selesai
                invoiceTemplate.style.display = 'none';
                Swal.close();
                showToast('PDF berhasil dibuat', 'success');
            })
            .catch(error => {
                console.error('Error generating PDF:', error);
                Swal.close();
                showToast('Gagal membuat PDF: ' + error.message, 'error');
                // Sembunyikan template jika terjadi kesalahan
                invoiceTemplate.style.display = 'none';
            });
    } catch (error) {
        console.error('Error preparing PDF:', error);
        Swal.close();
        showToast('Terjadi kesalahan saat generate PDF: ' + error.message, 'error');
        // Pastikan template tersembunyi jika terjadi kesalahan
        document.getElementById('invoiceTemplate').style.display = 'none';
    }
}

/**
 * Format tanggal untuk nama file
 * @param {Date} date - Tanggal yang akan diformat
 * @returns {string} - String tanggal dengan format YYYYMMDD
 */
function formatDateForFilename(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}${month}${day}`;
}

/**
 * Mengubah huruf pertama menjadi kapital
 * @param {string} str - String yang akan diformat
 * @returns {string} - String dengan huruf pertama kapital
 */
function capitalizeFirst(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}


});