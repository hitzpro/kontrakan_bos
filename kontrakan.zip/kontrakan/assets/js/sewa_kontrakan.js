// Global variables
let sewaData = []; // Will store all data
let filteredData = []; // Will store filtered data
let currentPage = 1;
const rowsPerPage = 10;

// DOM elements
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');
const sewaTableBody = document.getElementById('sewaTableBody');
const paginationContainer = document.getElementById('pagination');

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Initialize with PHP data
    if (typeof initialSewaData !== 'undefined') {
        sewaData = initialSewaData;
        filteredData = [...sewaData];
        renderTable();
        renderPagination();
    } else {
        console.error("No data available");
        showNoData();
    }

    // Search functionality
    searchButton.addEventListener('click', performSearch);
    searchInput.addEventListener('keyup', function(event) {
        if (event.key === 'Enter') {
            performSearch();
        }
    });
});

// Function to perform search
function performSearch() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    
    if (searchTerm === '') {
        filteredData = [...sewaData];
    } else {
        filteredData = sewaData.filter(item => {
            return (
                (item.nama_kontrakan && item.nama_kontrakan.toLowerCase().includes(searchTerm)) ||
                (item.nama_penyewa && item.nama_penyewa.toLowerCase().includes(searchTerm)) ||
                (item.tanggal_mulai && item.tanggal_mulai.includes(searchTerm)) ||
                (item.status_pembayaran && item.status_pembayaran.toLowerCase().includes(searchTerm)) ||
                (item.status_sewa && item.status_sewa.toLowerCase().includes(searchTerm))
            );
        });
    }
    
    currentPage = 1; // Reset to first page
    renderTable();
    renderPagination();
}

// Function to render table data
function renderTable() {
    sewaTableBody.innerHTML = '';
    
    if (filteredData.length === 0) {
        showNoData();
        return;
    }
    
    // Calculate start and end index for pagination
    const startIndex = (currentPage - 1) * rowsPerPage;
    const endIndex = Math.min(startIndex + rowsPerPage, filteredData.length);
    
    // Create table rows
    for (let i = startIndex; i < endIndex; i++) {
        const item = filteredData[i];
        const row = document.createElement('tr');
        
        // Calculate row number
        const rowNum = startIndex + (i - startIndex) + 1;
        
        // Format duration based on tipe_kontrakan
        let durasi = "";
        if (item.durasi_sewa) {
            durasi = item.durasi_sewa + (item.tipe_kontrakan === 'bulanan' ? ' Bulan' : ' Tahun');
        }
        
        // Create status badges
        const paymentStatusClass = item.status_pembayaran === 'lunas' ? 'status-lunas' : 'status-belum-bayar';
        
        let rentalStatusClass = '';
        switch(item.status_sewa) {
            case 'aktif':
                rentalStatusClass = 'status-aktif';
                break;
            case 'selesai':
                rentalStatusClass = 'status-selesai';
                break;
            case 'menunggu konfirmasi':
                rentalStatusClass = 'status-menunggu';
                break;
            case 'dibatalkan':
                rentalStatusClass = 'status-dibatalkan';
                break;
            default:
                rentalStatusClass = '';
        }
        
        // Format date
        const formatDate = (dateStr) => {
            if (!dateStr) return '-';
            
            const date = new Date(dateStr);
            const options = { day: 'numeric', month: 'short', year: 'numeric' };
            return date.toLocaleDateString('id-ID', options);
        };
        
        // Format currency
        const formatCurrency = (amount) => {
            if (!amount) return 'Rp 0';
            return new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            }).format(amount);
        };
        
        row.innerHTML = `
            <td>${rowNum}</td>
            <td>${item.nama_kontrakan || '-'}</td>
            <td>${item.nama_penyewa || '-'}</td>
            <td>${formatDate(item.tanggal_mulai)}</td>
            <td>${formatDate(item.tanggal_selesai)}</td>
            <td>${durasi || '-'}</td>
            <td>${formatCurrency(item.total_bayar)}</td>
            <td><span class="status-badge ${paymentStatusClass}">${item.status_pembayaran || '-'}</span></td>
            <td><span class="status-badge ${rentalStatusClass}">${item.status_sewa || '-'}</span></td>
            <td class='action'>
                <button class="action-btn view-btn" onclick="viewDetail(${item.id})">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        `;
        
        sewaTableBody.appendChild(row);
    }
}

// Function to show no data message
function showNoData() {
    sewaTableBody.innerHTML = `
        <tr>
            <td colspan="10" class="no-data">
                <i class="fas fa-info-circle"></i> Tidak ada data ditemukan
            </td>
        </tr>
    `;
    paginationContainer.innerHTML = '';
}

// Function to render pagination
function renderPagination() {
    paginationContainer.innerHTML = '';
    
    if (filteredData.length === 0) {
        return;
    }
    
    const totalPages = Math.ceil(filteredData.length / rowsPerPage);
    
    // Previous button
    const prevBtn = document.createElement('button');
    prevBtn.classList.add('pagination-btn');
    prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
    
    if (currentPage === 1) {
        prevBtn.classList.add('disabled');
    } else {
        prevBtn.addEventListener('click', () => {
            goToPage(currentPage - 1);
        });
    }
    paginationContainer.appendChild(prevBtn);
    
    // Page buttons
    const maxPageButtons = 5; // Maximum number of page buttons to show
    let startPage = Math.max(1, currentPage - Math.floor(maxPageButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxPageButtons - 1);
    
    // Adjust startPage if we're near the end
    if (endPage - startPage + 1 < maxPageButtons) {
        startPage = Math.max(1, endPage - maxPageButtons + 1);
    }
    
    // First page button (if needed)
    if (startPage > 1) {
        const firstPageBtn = document.createElement('button');
        firstPageBtn.classList.add('pagination-btn');
        firstPageBtn.textContent = '1';
        firstPageBtn.addEventListener('click', () => {
            goToPage(1);
        });
        paginationContainer.appendChild(firstPageBtn);
        
        // Ellipsis (if needed)
        if (startPage > 2) {
            const ellipsis = document.createElement('span');
            ellipsis.classList.add('pagination-btn', 'disabled');
            ellipsis.textContent = '...';
            paginationContainer.appendChild(ellipsis);
        }
    }
    
    // Page number buttons
    for (let i = startPage; i <= endPage; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.classList.add('pagination-btn');
        pageBtn.textContent = i;
        
        if (i === currentPage) {
            pageBtn.classList.add('active');
        } else {
            pageBtn.addEventListener('click', () => {
                goToPage(i);
            });
        }
        
        paginationContainer.appendChild(pageBtn);
    }
    
    // Last page button (if needed)
    if (endPage < totalPages) {
        // Ellipsis (if needed)
        if (endPage < totalPages - 1) {
            const ellipsis = document.createElement('span');
            ellipsis.classList.add('pagination-btn', 'disabled');
            ellipsis.textContent = '...';
            paginationContainer.appendChild(ellipsis);
        }
        
        const lastPageBtn = document.createElement('button');
        lastPageBtn.classList.add('pagination-btn');
        lastPageBtn.textContent = totalPages;
        lastPageBtn.addEventListener('click', () => {
            goToPage(totalPages);
        });
        paginationContainer.appendChild(lastPageBtn);
    }
    
    // Next button
    const nextBtn = document.createElement('button');
    nextBtn.classList.add('pagination-btn');
    nextBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
    
    if (currentPage === totalPages) {
        nextBtn.classList.add('disabled');
    } else {
        nextBtn.addEventListener('click', () => {
            goToPage(currentPage + 1);
        });
    }
    paginationContainer.appendChild(nextBtn);
}

// Function to navigate to specific page
function goToPage(page) {
    currentPage = page;
    renderTable();
    renderPagination();
    // Scroll to top of table
    document.querySelector('.table-container').scrollIntoView({ behavior: 'smooth' });
}

// Function to view detail
function viewDetail(id) {
    // Use AJAX to fetch the latest data
    $.ajax({
        url: '../logic/admin/get_sewa_detail.php',
        type: 'GET',
        data: { id: id },
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                const item = response.data;
                
                Swal.fire({
                    title: 'Detail Penyewaan',
                    html: `
                    <div class="rental-card">
                    <div class="card-header">
                        <h2>Informasi Penyewaan</h2>
                    </div>
                    
                    <div class="grid-container">
                        <!-- Informasi Penyewa -->
                        <div class="section">
                            <div class="section-title">
                                <i class="fas fa-user"></i> Informasi Penyewa
                            </div>
                            <div class="info-row">
                                <div class="info-label">Nama Penyewa</div>
                                <div class="info-value">${item.nama_penyewa || '-'}</div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Alamat Lengkap</div>
                                <div class="info-value">${item.alamat_lengkap || '-'}</div>
                            </div>
                        </div>
                        
                        <!-- Detail Kontrakan -->
                        <div class="section">
                            <div class="section-title">
                                <i class="fas fa-home"></i> Detail Kontrakan
                            </div>
                            <div class="info-row">
                                <div class="info-label">Nama Kontrakan</div>
                                <div class="info-value">${item.nama_kontrakan || '-'}</div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Lokasi</div>
                                <div class="info-value">${item.lokasi || '-'}</div>
                            </div>
                        </div>
                        
                        <!-- Periode & Durasi -->
                        <div class="section">
                            <div class="section-title">
                                <i class="fas fa-calendar-alt"></i> Periode & Durasi
                            </div>
                            <div class="info-row">
                                <div class="info-label">Periode</div>
                                <div class="info-value">${formatDate(item.tanggal_mulai)} - ${formatDate(item.tanggal_selesai)}</div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Durasi</div>
                                <div class="info-value">
                                    ${item.durasi_sewa} ${item.tipe_kontrakan === 'bulanan' ? 'Bulan' : 'Tahun'}
                                </div>
                            </div>
                        </div>
                        
                        <!-- Informasi Pembayaran -->
                        <div class="section">
                            <div class="section-title">
                                <i class="fas fa-money-bill-wave"></i> Informasi Pembayaran
                            </div>
                            <div class="info-row">
                                <div class="info-label">Harga Sewa</div>
                                <div class="info-value">
                                    <span class="highlight-price">${formatCurrency(item.harga_sewa)}</span>
                                </div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Total Bayar</div>
                                <div class="info-value">
                                    <span class="highlight-total">${formatCurrency(item.total_bayar)}</span>
                                </div>
                            </div>
                            <div class="info-row">
                                <div class="info-label">Metode</div>
                                <div class="info-value">
                                    <i class="fas fa-credit-card"></i> ${item.metode_pembayaran || '-'}
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Status Section (Full Width) -->
                    <div class="section" style="grid-column: 1 / -1;">
                        <div class="section-title">
                            <i class="fas fa-info-circle"></i> Status & Keterangan
                        </div>
                        <div class="info-row">
                            <div class="info-label">Status Pembayaran</div>
                            <div class="info-value">
                                <span class="status-badge ${item.status_pembayaran === 'Lunas' ? 'status-paid' : 'status-unpaid'}">
                                    <i class="${item.status_pembayaran === 'Lunas' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle'}"></i>
                                    ${item.status_pembayaran || '-'}
                                </span>
                            </div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Status Sewa</div>
                            <div class="info-value">
                                <span class="status-badge ${item.status_sewa === 'Aktif' ? 'status-active' : 'status-inactive'}">
                                    <i class="${item.status_sewa === 'Aktif' ? 'fas fa-toggle-on' : 'fas fa-toggle-off'}"></i>
                                    ${item.status_sewa || '-'}
                                </span>
                            </div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Keterangan</div>
                            <div class="info-value keterangan">${item.keterangan || '-'}</div>
                        </div>
                    </div>
                </div>
                `,
                
                
                    confirmButtonText: 'Tutup',
                    confirmButtonColor: '#2a9d8f'
                });
            } else {
                showAlert('Error', response.message || 'Data tidak ditemukan', 'error');
            }
        },
        error: function(xhr, status, error) {
            showAlert('Error', 'Terjadi kesalahan saat memuat data', 'error');
            console.error(xhr.responseText);
        }
    });
}

// // Function to edit data
// function editData(id) {
//     // Redirect to edit page with the ID
//     window.location.href = 'edit_sewa.php?id=' + id;
    
//     // Alternative approach: Fetch and show in modal
//     /*
//     $.ajax({
//         url: '../logic/admin/get_sewa_detail.php',
//         type: 'GET',
//         data: { id: id },
//         dataType: 'json',
//         success: function(response) {
//             if (response.status === 'success') {
//                 // Show edit modal with form populated with data
//                 // Implementation depends on your UI requirements
//             } else {
//                 showAlert('Error', response.message || 'Data tidak ditemukan', 'error');
//             }
//         },
//         error: function(xhr, status, error) {
//             showAlert('Error', 'Terjadi kesalahan saat memuat data', 'error');
//             console.error(xhr.responseText);
//         }
//     });
//     */
// }

// Function to confirm delete
function confirmDelete(id) {
    Swal.fire({
        title: 'Konfirmasi',
        text: 'Apakah Anda yakin ingin menghapus data ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#f44336',
        cancelButtonColor: '#a0a0a0',
        confirmButtonText: 'Ya, Hapus',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            deleteData(id);
        }
    });
}

// Function to delete data
function deleteData(id) {
    $.ajax({
        url: '../logic/admin/delete_sewa.php',
        type: 'POST',
        data: { id: id },
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                // Remove item from arrays if you're maintaining local data
                if (typeof sewaData !== 'undefined') {
                    sewaData = sewaData.filter(item => item.id !== id);
                }
                if (typeof filteredData !== 'undefined') {
                    filteredData = filteredData.filter(item => item.id !== id);
                }
                
                // Re-render table
                renderTable();
                renderPagination();
                
                // Show success message
                showAlert('Sukses', response.message || 'Data berhasil dihapus', 'success');
            } else {
                showAlert('Error', response.message || 'Gagal menghapus data', 'error');
            }
        },
        error: function(xhr, status, error) {
            showAlert('Error', 'Terjadi kesalahan saat menghapus data', 'error');
            console.error(xhr.responseText);
        }
    });
}

// Function to load data from server
function loadSewaData() {
    $.ajax({
        url: '../logic/admin/get_all_sewa.php',
        type: 'GET',
        dataType: 'json',
        beforeSend: function() {
            // Show loading indicator if needed
            $('#dataTable tbody').html('<tr><td colspan="8" class="text-center">Loading data...</td></tr>');
        },
        success: function(response) {
            if (response.status === 'success') {
                // Store data in global variables
                sewaData = response.data;
                filteredData = [...sewaData];
                
                // Render table with data
                renderTable();
                renderPagination();
            } else {
                showAlert('Error', response.message || 'Gagal memuat data', 'error');
                $('#dataTable tbody').html('<tr><td colspan="8" class="text-center">Gagal memuat data</td></tr>');
            }
        },
        error: function(xhr, status, error) {
            showAlert('Error', 'Terjadi kesalahan saat memuat data', 'error');
            console.error(xhr.responseText);
            $('#dataTable tbody').html('<tr><td colspan="8" class="text-center">Terjadi kesalahan saat memuat data</td></tr>');
        }
    });
}

// Call this function when the page loads
$(document).ready(function() {
    loadSewaData();
    
    // Add search functionality
    $('#searchInput').on('keyup', function() {
        const searchTerm = $(this).val().toLowerCase();
        
        if (searchTerm === '') {
            filteredData = [...sewaData];
        } else {
            filteredData = sewaData.filter(item => {
                return (
                    (item.nama_kontrakan && item.nama_kontrakan.toLowerCase().includes(searchTerm)) ||
                    (item.nama_penyewa && item.nama_penyewa.toLowerCase().includes(searchTerm)) ||
                    (item.lokasi && item.lokasi.toLowerCase().includes(searchTerm)) ||
                    (item.status_sewa && item.status_sewa.toLowerCase().includes(searchTerm))
                );
            });
        }
        
        currentPage = 1;
        renderTable();
        renderPagination();
    });
    
    // Add filter functionality if needed
    $('#statusFilter').on('change', function() {
        const selectedStatus = $(this).val();
        
        if (selectedStatus === 'semua') {
            filteredData = [...sewaData];
        } else {
            filteredData = sewaData.filter(item => item.status_sewa === selectedStatus);
        }
        
        currentPage = 1;
        renderTable();
        renderPagination();
    });
});

// Helper function to format date
function formatDate(dateStr) {
    if (!dateStr) return '-';
    
    const date = new Date(dateStr);
    const options = { day: 'numeric', month: 'short', year: 'numeric' };
    return date.toLocaleDateString('id-ID', options);
}

// Helper function to format currency
function formatCurrency(amount) {
    if (!amount) return 'Rp 0';
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
}

// Helper function to show alerts
function showAlert(title, message, icon) {
    Swal.fire({
        title: title,
        text: message,
        icon: icon,
        confirmButtonColor: '#2a9d8f'
    });
}