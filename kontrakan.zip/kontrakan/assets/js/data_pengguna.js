document.addEventListener('DOMContentLoaded', function() {
    // Tab Switching
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Update active tab button
            tabButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Update active tab content
            tabContents.forEach(content => content.classList.remove('active'));
            document.getElementById(`${tabId}Tab`).classList.add('active');
            
            // Update URL without reloading
            history.pushState(null, null, `?tab=${tabId}`);
        });
    });
    
    // Check URL for active tab
    const urlParams = new URLSearchParams(window.location.search);
    const activeTab = urlParams.get('tab');
    
    if (activeTab) {
        const tabButton = document.querySelector(`.tab-button[data-tab="${activeTab}"]`);
        if (tabButton) {
            tabButton.click();
        }
    }
    
    // Search Functionality
    const searchInput = document.getElementById('searchInput');
    const bookingTable = document.getElementById('bookingTable');
    const sewaTable = document.getElementById('sewaTable');
    
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        
        // Search in active table
        const activeTable = document.querySelector('.tab-content.active table');
        const rows = activeTable.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            let matches = false;
            
            cells.forEach(cell => {
                if (cell.textContent.toLowerCase().includes(searchTerm)) {
                    matches = true;
                }
            });
            
            row.style.display = matches ? '' : 'none';
        });
    });
    
    // View Button Click
    document.querySelectorAll('.view-btn').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            Swal.fire({
                title: 'Detail Penyewaan',
                text: `Menampilkan detail untuk penyewaan ID: ${id}`,
                icon: 'info',
                confirmButtonText: 'Tutup'
            });
        });
    });
    
    // Edit Button Click
    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            Swal.fire({
                title: 'Edit Penyewaan',
                text: `Mengedit data penyewaan ID: ${id}`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Simpan',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Berhasil!',
                        'Data penyewaan telah diperbarui.',
                        'success'
                    );
                }
            });
        });
    });
    
    // Responsive adjustments
    function handleResponsive() {
        // Additional responsive adjustments if needed
    }
    
    window.addEventListener('resize', handleResponsive);
    handleResponsive();
});