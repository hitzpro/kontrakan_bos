document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi
    checkServerMessage();
    setupEventListeners();
});

function setupEventListeners() {
    // Pencarian dan filter
    document.getElementById('searchButton').addEventListener('click', performSearch);
    document.getElementById('statusFilter').addEventListener('change', performSearch);
    
    // Pagination
    document.querySelectorAll('.pagination a').forEach(link => {
        link.addEventListener('click', handlePagination);
    });
    
    // Action buttons
    setupActionButtons();
}

function setupActionButtons() {
    // Detail button
    document.querySelectorAll('.btn-detail').forEach(btn => {
        btn.addEventListener('click', function() {
            const rentalId = this.getAttribute('data-id');
            showRentalDetail(rentalId);
        });
    });
    
    // Approve button
    document.querySelectorAll('.btn-approve').forEach(btn => {
        btn.addEventListener('click', function() {
            const rentalId = this.getAttribute('data-id');
            confirmAction('Konfirmasi Penyewaan', 'Yakin ingin mengonfirmasi penyewaan ini?', 
                          function() { updateRentalStatus(rentalId, 'aktif'); });
        });
    });
    
    // Reject button
    document.querySelectorAll('.btn-reject').forEach(btn => {
        btn.addEventListener('click', function() {
            const rentalId = this.getAttribute('data-id');
            confirmAction('Tolak Penyewaan', 'Yakin ingin menolak penyewaan ini?', 
                          function() { updateRentalStatus(rentalId, 'dibatalkan'); });
        });
    });
    
    // Complete button
    document.querySelectorAll('.btn-complete').forEach(btn => {
        btn.addEventListener('click', function() {
            const rentalId = this.getAttribute('data-id');
            confirmAction('Selesaikan Penyewaan', 'Yakin ingin menyelesaikan penyewaan ini?', 
                          function() { updateRentalStatus(rentalId, 'selesai'); });
        });
    });
}

function performSearch() {
    const searchTerm = document.getElementById('searchInput').value;
    const statusFilter = document.getElementById('statusFilter').value;
    
    window.location.href = `penyewaan.php?search=${encodeURIComponent(searchTerm)}&status=${encodeURIComponent(statusFilter)}`;
}

function handlePagination(e) {
    e.preventDefault();
    const page = this.getAttribute('data-page');
    const searchTerm = document.getElementById('searchInput').value;
    const statusFilter = document.getElementById('statusFilter').value;
    
    window.location.href = `penyewaan.php?page=${page}&search=${encodeURIComponent(searchTerm)}&status=${encodeURIComponent(statusFilter)}`;
}

function showRentalDetail(rentalId) {
    // Fetch data dan tampilkan detail
    fetch(`../logic/admin/get_rental_detail.php?id=${rentalId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showDetailModal(data.rental);
            } else {
                showToast('Error', data.message, 'error');
            }
        })
        .catch(error => {
            showToast('Error', 'Terjadi kesalahan saat memuat data', 'error');
        });
}

function showDetailModal(rental) {
    Swal.fire({
        title: 'Detail Penyewaan',
        html: `
            <div class="rental-card">
                <div class="card-header">
                    <h2>Detail Penyewaan #${rental.id}</h2>
                </div>
                
                <div class="grid-container">
                    <!-- Section 1: Informasi Penyewa -->
                    <div class="section">
                        <div class="section-title">
                            <i class="fas fa-user"></i> Informasi Penyewa
                        </div>
                        <div class="info-row">
                            <span class="info-label">Nama Penyewa:</span>
                            <span class="info-value">${rental.nama_pengguna}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Kontrakan:</span>
                            <span class="info-value">${rental.nama_kontrakan}</span>
                        </div>
                    </div>
                    
                    <!-- Section 2: Detail Sewa -->
                    <div class="section">
                        <div class="section-title">
                            <i class="fas fa-calendar-alt"></i> Detail Sewa
                        </div>
                        <div class="info-row">
                            <span class="info-label">Durasi:</span>
                            <span class="info-value">${rental.durasi_sewa} bulan</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Tanggal Mulai:</span>
                            <span class="info-value">${rental.tanggal_mulai}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Tanggal Selesai:</span>
                            <span class="info-value">${rental.tanggal_selesai}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Status Sewa:</span>
                            <span class="info-value">
                                <span class="status-badge ${rental.status_sewa === 'Aktif' ? 'status-active' : 'status-inactive'}">
                                    <i class="fas ${rental.status_sewa === 'Aktif' ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                                    ${rental.status_sewa}
                                </span>
                            </span>
                        </div>
                    </div>
                    
                    <!-- Section 3: Pembayaran -->
                    <div class="section">
                        <div class="section-title">
                            <i class="fas fa-money-bill-wave"></i> Informasi Pembayaran
                        </div>
                        <div class="info-row">
                            <span class="info-label">Total Bayar:</span>
                            <span class="info-value highlight-total">Rp ${formatNumber(rental.total_bayar)}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Metode:</span>
                            <span class="info-value">${rental.metode_pembayaran}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Status:</span>
                            <span class="info-value">
                                <span class="status-badge ${rental.status_pembayaran === 'Lunas' ? 'status-paid' : 'status-unpaid'}">
                                    <i class="fas ${rental.status_pembayaran === 'Lunas' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                                    ${rental.status_pembayaran}
                                </span>
                            </span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Kode Pembayaran:</span>
                            <span class="info-value">${rental.kode_pembayaran || '-'}</span>
                        </div>
                    </div>
                    
                    <!-- Section 4: Keterangan -->
                    <div class="section">
                        <div class="section-title">
                            <i class="fas fa-info-circle"></i> Keterangan Tambahan
                        </div>
                        <div class="keterangan">
                            ${rental.keterangan || 'Tidak ada keterangan tambahan.'}
                        </div>
                    </div>
                </div>
                
                <!-- Bukti Pembayaran Section (Conditional) -->
                ${rental.bukti_pembayaran ? `
                <div class="section" style="margin-top: 20px;">
                    <div class="section-title">
                        <i class="fas fa-receipt"></i> Bukti Pembayaran
                    </div>
                    <div style="text-align: center; margin-top: 10px;">
                        <img src="../user/bukti_pembayaran/${rental.bukti_pembayaran}" alt="Bukti Pembayaran" style="max-width: 100%; max-height: 300px; border-radius: 8px;">
                    </div>
                </div>` : ''}
            </div>
        `,
        width: '600px',
        showCloseButton: true,
        confirmButtonText: 'Tutup'
    });
}

function updateRentalStatus(rentalId, status) {
    const formData = new FormData();
    formData.append('id', rentalId);
    formData.append('status', status);
    
    fetch('../logic/admin/update_rental_status.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        // Check if response is ok before attempting to parse as JSON
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`Server returned ${response.status}: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            showToast('Sukses', data.message, 'success');
            // Reload halaman setelah beberapa saat
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            // Show detailed error for debugging
            let errorMsg = data.message || 'Unknown error occurred';
            
            // Add additional debug info if available
            if (data.query) {
                errorMsg += '<br>Query: ' + data.query;
            }
            
            console.error('Error details:', data);
            showToast('Error', errorMsg, 'error');
        }
    })
    .catch(error => {
        console.error('Error in updateRentalStatus:', error);
        showToast('Error', 'Terjadi kesalahan: ' + error.message, 'error');
    });
}


function confirmAction(title, text, onConfirm) {
    Swal.fire({
        title: title,
        text: text,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33'
    }).then((result) => {
        if (result.isConfirmed) {
            onConfirm();
        }
    });
}

function checkServerMessage() {
    const serverMessage = document.getElementById('serverMessage');
    const message = serverMessage.getAttribute('data-message');
    const type = serverMessage.getAttribute('data-type');
    
    if (message && message !== '') {
        showToast('Notifikasi', message, type);
    }
}

function showToast(title, message, type) {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
        }
    });
    
    Toast.fire({
        icon: type,
        title: message
    });
}

function formatNumber(number) {
    return new Intl.NumberFormat('id-ID').format(number);
}