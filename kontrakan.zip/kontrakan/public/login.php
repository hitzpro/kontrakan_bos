<?php
session_start();

// Log untuk debugging
error_log("🔍 LOGIN PAGE DEBUG: GET parameters: " . print_r($_GET, true));
error_log("🔍 LOGIN PAGE DEBUG: Session data: " . print_r($_SESSION, true));

// Simpan redirect_id dari URL ke session
if (isset($_GET['redirect_id']) && is_numeric($_GET['redirect_id'])) {
    $_SESSION['redirect_after_login_id'] = (int) $_GET['redirect_id'];
    error_log("🔍 LOGIN PAGE DEBUG: Setting redirect_after_login_id to: " . $_SESSION['redirect_after_login_id']);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login / Daftar Pengguna</title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts - Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/login-user.css">
</head>
<body>
    <div class="container">
        <div class="login-form-container">
            <!-- Login Form -->
            <form id="login-form" action="../logic/user/login.php" method="post">
                <h2>Masuk</h2>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-envelope"></i></span>
                        <input type="email" name="email" placeholder="Email" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" id="login-password" placeholder="Kata Sandi" required>
                        <span class="toggle-password" onclick="togglePassword('login-password')">
                            <i class="fas fa-eye" id="login-eye-icon"></i>
                        </span>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn-submit">Masuk</button>
                </div>
                <div class="form-footer">
                    <p>Belum punya akun? <a href="#" id="show-register">Daftar Sekarang</a></p>
                    <a href="../index.php" class="btn-back">← Kembali ke Beranda</a>
                </div>
            </form>

            <!-- Register Form -->
            <form id="register-form" action="../logic/user/daftar.php" method="post" style="display: none;">
                <h2>Daftar</h2>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-envelope"></i></span>
                        <input type="email" name="email" placeholder="Email" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-user"></i></span>
                        <input type="text" name="nama_pengguna" placeholder="Nama Pengguna" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-phone"></i></span>
                        <input type="tel" name="no_telepon" placeholder="Nomor Telepon" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" id="register-password" placeholder="Kata Sandi" required>
                        <span class="toggle-password" onclick="togglePassword('register-password')">
                            <i class="fas fa-eye" id="register-eye-icon"></i>
                        </span>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-lock"></i></span>
                        <input type="password" name="confirm_password" id="register-confirm-password" placeholder="Konfirmasi Kata Sandi" required>
                        <span class="toggle-password" onclick="togglePassword('register-confirm-password')">
                            <i class="fas fa-eye" id="register-confirm-eye-icon"></i>
                        </span>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn-submit">Daftar</button>
                </div>
                <div class="form-footer">
                    <p>Sudah punya akun? <a href="#" id="show-login">Masuk Sekarang</a></p>
                    <a href="../index.php" class="btn-back">← Kembali ke Beranda</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Script SweetAlert dengan logs -->
    <?php if (isset($_SESSION['message'])): ?>
    <script>
        console.log("🔍 LOGIN PAGE: Session message detected");
        console.log("🔍 LOGIN PAGE: Status:", '<?php echo $_SESSION['status']; ?>');
        console.log("🔍 LOGIN PAGE: Title:", '<?php echo $_SESSION['title']; ?>');
        console.log("🔍 LOGIN PAGE: Message:", '<?php echo $_SESSION['message']; ?>');
        console.log("🔍 LOGIN PAGE: Redirect flag:", <?php echo $_SESSION['redirect'] ? 'true' : 'false'; ?>);
        console.log("🔍 LOGIN PAGE: Redirect target:", '<?php echo isset($_SESSION['redirect_target']) ? $_SESSION['redirect_target'] : 'NOT SET'; ?>');
        
        document.addEventListener('DOMContentLoaded', function() {
            console.log("🔍 LOGIN PAGE: DOM loaded, showing SweetAlert");
            
            Swal.fire({
                icon: '<?php echo $_SESSION['status']; ?>',
                title: '<?php echo $_SESSION['title']; ?>',
                text: '<?php echo $_SESSION['message']; ?>',
                timer: 3000,
                timerProgressBar: true
            }).then(() => {
                console.log("🔍 LOGIN PAGE: SweetAlert closed");
                
                <?php if ($_SESSION['status'] === 'success' && $_SESSION['redirect']): ?>
                    console.log("🔍 LOGIN PAGE: Success login detected, processing redirect");
                    
                    <?php if (isset($_SESSION['redirect_target'])): ?>
                        const redirectURL = "<?php echo $_SESSION['redirect_target']; ?>";
                        console.log("✅ LOGIN PAGE: Redirecting to:", redirectURL);
                        window.location.href = redirectURL;
                    <?php else: ?>
                        console.log("❌ LOGIN PAGE: No redirect_target set, fallback to index");
                        window.location.href = "../index.php";
                    <?php endif; ?>
                <?php else: ?>
                    console.log("🔍 LOGIN PAGE: Not a success login or no redirect flag");
                <?php endif; ?>
            });
        });
    </script>
    <?php 
    error_log("🔍 LOGIN PAGE DEBUG: Clearing session messages");
    unset($_SESSION['message'], $_SESSION['status'], $_SESSION['title'], $_SESSION['redirect'], $_SESSION['redirect_target']);
    endif;
    ?>

    <!-- Log tambahan untuk debugging URL -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        console.log("🔍 LOGIN PAGE: Page loaded");
        console.log("🔍 LOGIN PAGE: Current URL:", window.location.href);
        console.log("🔍 LOGIN PAGE: URL parameters:", window.location.search);
        
        // Parse URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const redirectId = urlParams.get('redirect_id');
        if (redirectId) {
            console.log("🔍 LOGIN PAGE: Found redirect_id in URL:", redirectId);
        } else {
            console.log("🔍 LOGIN PAGE: No redirect_id in URL");
        }
    });
    </script>

    <!-- JavaScript -->
    <script src="../assets/js/login-user.js"></script>
</body>
</html>