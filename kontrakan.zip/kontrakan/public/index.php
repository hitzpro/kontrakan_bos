<?php
require_once '../config/db.php';

// Ambil semua data kontrakan tersedia
$query = "SELECT id, nama_kontrakan, lokasi, harga, tipe_kontrakan, status, foto, luas FROM data_kontrakan WHERE status = 'tersedia' ORDER BY id DESC";
$result = mysqli_query($conn, $query);

// Ambil lokasi unik untuk filter
$query_lokasi = "SELECT DISTINCT lokasi FROM data_kontrakan WHERE status = 'tersedia'";
$result_lokasi = mysqli_query($conn, $query_lokasi);
?>

<?php
session_start();
$namaPengguna = isset($_SESSION['user_user_id']) ? $_SESSION['user_user_nama_pengguna'] : null;
$idPengguna = isset($_SESSION['user_user_id']) ? $_SESSION['user_user_id'] : null;

// Atau ambil dari parameter URL
$getId = isset($_GET['id']) ? $_GET['id'] : null;
?>




<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>H. Sagio - Temukan Kontrakan Terbaik untuk Anda</title>
    <meta name="description" content="Temukan kontrakan terbaik yang sesuai dengan kebutuhan dan budget Anda">
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">
    
    <!-- Font Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/index.css">
</head>
<body>
    <!-- Header & Navbar -->
    <header>
        <nav>
            <div class="container">
                <div class="navbar">
                    <div class="logo">
                        <a href="index.php">
                            <h1>H. Sagio</h1>
                        </a>
                    </div>
                    <div class="menu">
                        <ul>
                            <li><a href="#beranda" class="active">Beranda</a></li>
                            <li><a href="#kontrakan">Kontrakan</a></li>
                            <li><a href="#tentang">Tentang Kami</a></li>
                            <li><a href="#faq">FAQ</a></li>
                            <li><a href="#kontak">Kontak</a></li>
                            
                            <!-- munculkan icon user dan nama_pengguna disini setelah user login -->
                            <?php if ($namaPengguna): ?>
                                <li class="user-info">
                                    <i class="fas fa-user-circle"></i>
                                    <a href="../user/dashboard.php?id=<?= urlencode($idPengguna) ?>">
                                        <span><?= htmlspecialchars($namaPengguna) ?></span>
                                    </a>
                                </li>
                                <li class="logout-button">
                                    <a href="#" onclick="confirmLogout(event)">
                                        <i class="fas fa-sign-out-alt"></i> Logout
                                    </a>
                                </li>
                            <?php endif; ?>



                        </ul>
                    </div>
                    <div class="menu-toggle">
                        <i class="fas fa-bars"></i>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Hero Section -->
    <section id="beranda" class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Temukan Kontrakan Impian Anda</h1>
                <p>Kami menyediakan kontrakan terbaik di lokasi pilihan, dengan fasilitas memadai dan harga sesuai kantong.</p>
                <a href="#kontrakan" class="btn-primary">Jelajahi Sekarang</a>
            </div>
        </div>
    </section>

    <!-- Kontrakan Section -->
    <section id="kontrakan" class="kontrakan">
        <div class="container">
            <div class="section-header">
                <h2>Kontrakan Tersedia</h2>
                <p>Pilihan kontrakan terbaik untuk kebutuhan Anda</p>
            </div>

            <!-- <div class="filter-kontrakan">
                <div class="filter-item">
                    <select id="filter-tipe">
                        <option value="semua">Semua Tipe</option>
                        <option value="bulanan">Bulanan</option>
                        <option value="tahunan">Tahunan</option>
                    </select>
                </div>
                <div class="filter-item">
                    <select id="filter-lokasi">
                        <option value="semua">Semua Lokasi</option>
                        <?php
                        while ($row = mysqli_fetch_assoc($result_lokasi)) {
                            echo '<option value="' . htmlspecialchars($row['lokasi']) . '">' . htmlspecialchars($row['lokasi']) . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="filter-item">
                    <input type="number" id="filter-harga-min" placeholder="Min (contoh: 1200000)">
                </div>
                <div class="filter-item">
                    <input type="number" id="filter-harga-max" placeholder="Max (contoh: 2000000)">
                </div>
                <button id="apply-filter" class="btn-secondary">Terapkan Filter</button>
            </div> -->

            <div class="kontrakan-container">
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $harga_formatted = number_format((float)$row['harga'], 0, ',', '.');
                        $foto = !empty($row['foto']) ? $row['foto'] : 'default.jpg';

                        // Cek apakah file benar-benar ada di folder
                        if (!file_exists('../images/kontrakan/' . $foto)) {
                            $foto = 'default.jpg';
                        }

                        echo '<div class="kontrakan-card" data-tipe="' . htmlspecialchars($row['tipe_kontrakan']) . '" data-lokasi="' . htmlspecialchars($row['lokasi']) . '" data-harga="' . (int)$row['harga'] . '">';
                        echo '<div class="kontrakan-img">';
                        echo '<img src="../images/kontrakan/' . htmlspecialchars($foto) . '" alt="' . htmlspecialchars($row['nama_kontrakan']) . '">';
                        echo '<span class="kontrakan-tipe">' . ucfirst(htmlspecialchars($row['tipe_kontrakan'])) . '</span>';
                        echo '</div>';
                        echo '<div class="kontrakan-info">';
                        echo '<h3>' . htmlspecialchars($row['nama_kontrakan']) . '</h3>';
                        echo '<div class="kontrakan-location">';
                        echo '<i class="fas fa-map-marker-alt"></i>';
                        echo '<p>' . htmlspecialchars($row['lokasi']) . '</p>';
                        echo '</div>';
                        echo '<div class="kontrakan-detail">';
                        echo '<span><i class="fas fa-ruler-combined"></i> ' . htmlspecialchars($row['luas']) . '</span>';
                        echo '<span><i class="fas fa-tags"></i> Rp ' . $harga_formatted . '/' . ($row['tipe_kontrakan'] == 'bulanan' ? 'bulan' : 'tahun') . '</span>';
                        echo '</div>';
                        echo '<a href="detail-kontrakan.php?id=' . (int)$row['id'] . '" class="btn-detail">Lihat Detail</a>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="no-data">Tidak ada kontrakan tersedia saat ini.</div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Tentang Kami Section -->
    <section id="tentang" class="tentang">
        <div class="container">
            <div class="section-header">
                <h2>Tentang Kami</h2>
                <p>Menyediakan kontrakan terbaik sejak 2015</p>
            </div>
            <div class="tentang-content">
                <div class="tentang-img">
                    <img src="../images/about-us.png" alt="Tentang H. Sagio">
                </div>
                <div class="tentang-text">
                    <h3>H. Sagio - Solusi Tepat untuk Hunian Anda</h3>
                    <p>H. Sagio adalah platform yang didedikasikan untuk membantu Anda menemukan kontrakan yang sesuai dengan kebutuhan dan budget. Kami menghubungkan pemilik kontrakan dengan calon penyewa yang mencari hunian nyaman.</p>
                    <p>Dengan pengalaman lebih dari 7 tahun, kami telah membantu ribuan orang menemukan kontrakan impian mereka. Komitmen kami adalah memberikan informasi yang akurat, transparan, dan pelayanan yang terbaik.</p>
                    <div class="tentang-stats">
                        <div class="stats-item">
                            <i class="fas fa-home"></i>
                            <h4>500+</h4>
                            <p>Kontrakan</p>
                        </div>
                        <div class="stats-item">
                            <i class="fas fa-users"></i>
                            <h4>1000+</h4>
                            <p>Pelanggan Puas</p>
                        </div>
                        <div class="stats-item">
                            <i class="fas fa-map-marked-alt"></i>
                            <h4>25+</h4>
                            <p>Lokasi</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Keunggulan Section -->
    <section class="keunggulan">
        <div class="container">
            <div class="section-header">
                <h2>Keunggulan Kami</h2>
                <p>Mengapa memilih H. Sagio?</p>
            </div>
            <div class="keunggulan-container">
                <div class="keunggulan-item">
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h3>Terpercaya</h3>
                    <p>Semua kontrakan telah diverifikasi secara langsung oleh tim kami</p>
                </div>
                <div class="keunggulan-item">
                    <div class="icon">
                        <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <h3>Harga Transparan</h3>
                    <p>Tidak ada biaya tersembunyi, semua harga sudah tertera dengan jelas</p>
                </div>
                <div class="keunggulan-item">
                    <div class="icon">
                        <i class="fas fa-map-marked-alt"></i>
                    </div>
                    <h3>Lokasi Strategis</h3>
                    <p>Pilihan kontrakan dengan lokasi strategis dan akses mudah</p>
                </div>
                <div class="keunggulan-item">
                    <div class="icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3>Layanan 24/7</h3>
                    <p>Tim support kami siap membantu Anda 24 jam setiap hari</p>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section id="faq" class="faq">
        <div class="container">
            <div class="section-header">
                <h2>Pertanyaan Umum</h2>
                <p>Jawaban untuk pertanyaan yang sering diajukan</p>
            </div>
            <div class="faq-container">
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Bagaimana cara menyewa kontrakan di H. Sagio?</h3>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Untuk menyewa kontrakan, Anda perlu membuat akun terlebih dahulu. Setelah itu, pilih kontrakan yang sesuai dengan kebutuhan Anda, lihat detailnya, dan klik tombol "Sewa Sekarang". Tim kami akan menghubungi Anda untuk proses selanjutnya.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Apakah saya perlu membayar DP untuk menyewa kontrakan?</h3>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Ya, untuk memastikan keseriusan Anda, diperlukan pembayaran DP sebesar 20% dari harga sewa. Sisa pembayaran dapat dilunasi saat serah terima kunci kontrakan.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Apakah harga kontrakan sudah termasuk listrik dan air?</h3>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Setiap kontrakan memiliki kebijakan yang berbeda. Ada kontrakan yang sudah termasuk biaya listrik dan air, ada juga yang tidak. Informasi lengkap dapat dilihat pada halaman detail kontrakan.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Berapa lama proses verifikasi dan serah terima kontrakan?</h3>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Proses verifikasi membutuhkan waktu 1-2 hari kerja. Setelah verifikasi berhasil dan pembayaran DP diterima, serah terima kunci dapat dilakukan dalam 1-3 hari kerja berikutnya tergantung kesepakatan dengan pemilik kontrakan.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-question">
                        <h3>Apakah ada biaya tambahan lain selain harga sewa?</h3>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <p>Biaya tambahan dapat berupa deposit keamanan yang akan dikembalikan saat akhir masa sewa (jika tidak ada kerusakan), dan biaya administrasi sebesar Rp 100.000 untuk proses pembuatan kontrak.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Kontak Section -->
    <section id="kontak" class="kontak">
        <div class="container">
            <div class="section-header">
                <h2>Kontak Kami</h2>
                <p>Hubungi kami untuk informasi lebih lanjut</p>
            </div>
            <div class="kontak-container">
               <div class="kontak-info">
                    <div class="kontak-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h3>Alamat</h3>
                            <p>Jln Annur 1</p>
                        </div>
                    </div>
                    <div class="kontak-item">
                        <i class="fas fa-phone-alt"></i>
                        <div>
                            <h3>Telepon</h3>
                            <p>088294871886</p>
                        </div>
                    </div>
                    <div class="kontak-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h3>Email</h3>
                            <p>info@H. Sagio.com</p>
                        </div>
                    </div>
                    <div class="kontak-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h3>Jam Operasional</h3>
                            <p>Senin - Jumat: 08.00 - 17.00</p>
                            <p>Sabtu: 09.00 - 15.00</p>
                        </div>
                    </div>
                </div>

                <div class="kontak-form">
                    <form id="contactForm">
                        <div class="form-group">
                            <label for="nama">Nama Lengkap</label>
                            <input type="text" id="nama" name="nama" placeholder="Masukkan nama lengkap" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" placeholder="Masukkan email" required>
                        </div>
                        <div class="form-group">
                            <label for="telepon">Nomor Telepon</label>
                            <input type="tel" id="telepon" name="telepon" placeholder="Masukkan nomor telepon" required>
                        </div>
                        <div class="form-group">
                            <label for="pesan">Pesan</label>
                            <textarea id="pesan" name="pesan" placeholder="Tulis pesan Anda" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn-primary">Kirim Pesan</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">
                    <h2>H. Sagio</h2>
                    <p>Solusi tepat untuk hunian Anda</p>
                    <div class="social-media">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-links">
                    <h3>Tautan Cepat</h3>
                    <ul>
                        <li><a href="#beranda">Beranda</a></li>
                        <li><a href="#kontrakan">Kontrakan</a></li>
                        <li><a href="#tentang">Tentang Kami</a></li>
                        <li><a href="#faq">FAQ</a></li>
                        <li><a href="#kontak">Kontak</a></li>
                    </ul>
                </div>
                <div class="footer-links">
                    <h3>Layanan</h3>
                    <ul>
                        <li><a href="#">Cara Menyewa</a></li>
                        <li><a href="#">Daftar Kontrakan</a></li>
                        <li><a href="#">Kerjasama Pemilik</a></li>
                        <li><a href="#">Bantuan</a></li>
                    </ul>
                </div>
                <div class="footer-newsletter">
                    <h3>Hubungi Cepat</h3>
                    <p>Dapatkan info terbaru dan penawaran eksklusif</p>
                    <form id="newsletterForm">
                        <input type="email" placeholder="Masukkan email Anda" required>
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 H. Sagio. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="../assets/js/index.js"></script>
</body>
</html>