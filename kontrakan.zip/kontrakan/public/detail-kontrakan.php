<?php
require_once '../config/db.php';
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: ../index.php');
    exit;
}

$id = (int)$_GET['id'];

// Query untuk mendapatkan detail kontrakan
$query = "SELECT * FROM data_kontrakan WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();

// Jika kontrakan tidak ditemukan
if ($result->num_rows == 0) {
    header('Location: ../index.php');
    exit;
}

$kontrakan = $result->fetch_assoc();

// Cek apakah user sudah login
session_start();
$isLoggedIn = isset($_SESSION['user_user_id']);
$user_id = $_SESSION['user_user_id'];

// Menentukan foto untuk ditampilkan
$foto_array = explode(',', $kontrakan['foto']);
$foto_utama = !empty($foto_array[0]) ? $foto_array[0] : '../assets/images/no-image.jpg';

// Format harga
$harga_formatted = number_format($kontrakan['harga'], 0, ',', '.');

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Kontrakan | <?php echo htmlspecialchars($kontrakan['nama_kontrakan']); ?></title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/detail-kontrakan.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="container">
        <header>
            <h1>Detail Kontrakan</h1>
            <a href="javascript:history.back()" class="back-button"><i class="fas fa-arrow-left"></i> Kembali</a>
        </header>
        
        <main>
            <div class="detail-container">
                <div class="image-gallery">
                    <div class="main-image">
                        <img src="../images/kontrakan/<?php echo htmlspecialchars($foto_utama); ?>" alt="<?php echo htmlspecialchars($kontrakan['nama_kontrakan']); ?>" id="mainImage">
                    </div>
                    <?php if (count($foto_array) > 1): ?>
                    <div class="thumbnail-container">
                        <?php foreach ($foto_array as $index => $foto): ?>
                            <?php if (trim($foto) !== ''): ?>
                            <div class="thumbnail">
                                <img src="<?php echo htmlspecialchars(trim($foto)); ?>" alt="Thumbnail <?php echo $index+1; ?>" onclick="changeMainImage('<?php echo htmlspecialchars(trim($foto)); ?>')">
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="detail-info">
                    <h2><?php echo htmlspecialchars($kontrakan['nama_kontrakan']); ?></h2>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-map-marker-alt"></i> Lokasi:</div>
                        <div class="info-value"><?php echo htmlspecialchars($kontrakan['lokasi']); ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-home"></i> Alamat:</div>
                        <div class="info-value"><?php echo nl2br(htmlspecialchars($kontrakan['alamat_lengkap'])); ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-money-bill-wave"></i> Harga:</div>
                        <div class="info-value">Rp <?php echo $harga_formatted; ?> / <?php echo $kontrakan['tipe_kontrakan'] === 'bulanan' ? 'bulan' : 'tahun'; ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-ruler-combined"></i> Luas:</div>
                        <div class="info-value"><?php echo htmlspecialchars($kontrakan['luas']); ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-calendar-alt"></i> Tipe Sewa:</div>
                        <div class="info-value"><?php echo $kontrakan['tipe_kontrakan'] === 'bulanan' ? 'Bulanan' : 'Tahunan'; ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-check-circle"></i> Status:</div>
                        <div class="info-value <?php echo $kontrakan['status'] === 'tersedia' ? 'available' : 'unavailable'; ?>">
                            <?php echo $kontrakan['status'] === 'tersedia' ? 'Tersedia' : 'Tidak Tersedia'; ?>
                        </div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label"><i class="fas fa-phone"></i> Kontak:</div>
                        <div class="info-value"><?php echo htmlspecialchars($kontrakan['kontak_pemilik']); ?></div>
                    </div>
                    
                    <div class="action-buttons">
                        <button 
                            class="btn-booking" 
                            <?php echo $kontrakan['status'] !== 'tersedia' ? 'disabled' : ''; ?>
                            onclick="<?php echo $isLoggedIn ? 'showBookingModal()' : 'redirectToLogin()'; ?>"
                        >
                            <i class="fas fa-calendar-check"></i> Booking Sekarang
                        </button>
                        <button 
                            class="btn-sewa" 
                            <?php echo $kontrakan['status'] !== 'tersedia' ? 'disabled' : ''; ?>
                            onclick="<?php echo $isLoggedIn ? 'showSewaModal()' : 'redirectToLogin()'; ?>"
                        >
                            <i class="fas fa-home"></i> Sewa Sekarang
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="kontrakan-detail-tabs">
                <div class="tab-headers">
                    <div class="tab-header active" data-tab="deskripsi">Deskripsi</div>
                    <div class="tab-header" data-tab="fasilitas">Fasilitas</div>
                    <div class="tab-header" data-tab="denah_lokasi">Denah Lokasi</div>
                </div>
                <div class="tab-contents">
                    <div class="tab-content active" id="deskripsi">
                        <h3>Deskripsi Kontrakan</h3>
                        <p><?php echo nl2br(htmlspecialchars($kontrakan['deskripsi'])); ?></p>
                    </div>
                    <div class="tab-content" id="fasilitas">
                        <h3>Fasilitas yang Tersedia</h3>
                        <ul class="fasilitas-list">
                            <?php 
                            $fasilitas_array = explode(',', $kontrakan['fasilitas']);
                            foreach ($fasilitas_array as $fasilitas) {
                                if (trim($fasilitas) !== '') {
                                    echo '<li><i class="fas fa-check"></i> ' . htmlspecialchars(trim($fasilitas)) . '</li>';
                                }
                            }
                            ?>
                        </ul>
                    </div>
                    <div class="tab-content" id="denah_lokasi">
                        <svg viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg">
                        <!-- Background -->
                        <rect width="800" height="600" fill="#f8f9fa" />
                        
                        <!-- Roads - More realistic layout based on Bekasi street patterns -->
                        <g stroke="#cccccc" stroke-width="16" fill="none">
                            <!-- Main roads -->
                            <path d="M 120,120 L 450,120" /> <!-- Jalan utama horizontal di atas -->
                            <path d="M 180,120 L 180,220" /> <!-- Jalan vertikal dari BKS Cyber Park -->
                            <path d="M 280,170 L 450,170" /> <!-- Jl. Tawes Raya bagian atas -->
                            <path d="M 280,120 L 280,320" /> <!-- Jl. Tawes Raya bagian vertikal -->
                            <path d="M 180,220 L 280,220" /> <!-- Jl. Tawes Raya penghubung -->
                            <path d="M 280,270 L 400,270" /> <!-- Jl. Lele Raya -->
                            <path d="M 400,270 L 400,380" /> <!-- Jl. Belut Raya -->
                            <path d="M 400,380 L 500,380" /> <!-- Jl. Annur Raya -->
                            <path d="M 500,380 L 500,450" /> <!-- Jl. Annur II -->
                            <path d="M 500,450 L 600,450" /> <!-- Jl. Annur I -->
                            
                            <!-- Jalan-jalan sekitar -->
                            <path d="M 350,120 L 350,220" />
                            <path d="M 230,220 L 230,320" />
                            <path d="M 180,320 L 350,320" />
                            <path d="M 350,220 L 350,320" />
                            <path d="M 350,270 L 450,270" />
                            <path d="M 450,220 L 450,380" />
                            <path d="M 450,330 L 550,330" />
                            <path d="M 550,330 L 550,450" />
                            <path d="M 500,450 L 500,500" />
                            <path d="M 400,380 L 400,500" />
                        </g>
                        
                        <!-- Route path with proper turns -->
                        <path d="M 150,120 L 180,120 L 180,220 L 230,220 L 230,270 L 280,270 L 280,270 L 400,270 L 400,380 L 500,380 L 500,450 L 600,450" 
                                stroke="#4285F4" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round" />
                        
                        <!-- Direction arrows -->
                        <g fill="#4285F4">
                            <circle cx="165" cy="120" r="3" /> <!-- 1. Ke barat -->
                            <circle cx="180" cy="170" r="3" /> <!-- 2. Belok kanan ke Jl. Tawes -->
                            <circle cx="205" cy="220" r="3" /> <!-- 3. Belok kiri -->
                            <circle cx="230" cy="245" r="3" /> <!-- 4. Belok kanan -->
                            <circle cx="255" cy="270" r="3" /> <!-- 5. Belok kiri ke Jl. Lele -->
                            <circle cx="340" cy="270" r="3" /> <!-- 6. Belok kanan ke Jl. Belut -->
                            <circle cx="400" cy="325" r="3" /> <!-- 7. Teruskan ke Jl. Annur Raya -->
                            <circle cx="450" cy="380" r="3" /> <!-- 8. Belok kiri ke Jl. Annur II -->
                            <circle cx="500" cy="415" r="3" /> <!-- 9. Belok kanan ke Jl. Annur I -->
                            <circle cx="550" cy="450" r="3" /> <!-- 10. Tiba di lokasi -->
                        </g>
                        
                        <!-- Start point marker -->
                        <g transform="translate(150,120)">
                            <circle r="12" fill="#34A853" />
                            <text x="20" y="5" font-family="Arial" font-size="14" font-weight="bold">BKS Cyber Park</text>
                        </g>
                        
                        <!-- End point marker -->
                        <g transform="translate(600,450)">
                            <circle r="12" fill="#EA4335" />
                            <text x="20" y="5" font-family="Arial" font-size="14" font-weight="bold">Jl. Annur I</text>
                        </g>
                        
                        <!-- Street names -->
                        <g font-family="Arial" font-size="11" font-weight="500">
                            <text x="180" y="105" text-anchor="middle">Jl. Raya Kayuringin</text>
                            <text x="160" y="170" text-anchor="end">Jl. Tawes Raya</text>
                            <text x="255" y="255" text-anchor="middle">Jl. Tawes Raya</text>
                            <text x="340" y="255" text-anchor="middle">Jl. Lele Raya</text>
                            <text x="420" y="325" text-anchor="middle">Jl. Belut Raya</text>
                            <text x="450" y="370" text-anchor="middle">Jl. Annur Raya</text>
                            <text x="485" y="415" text-anchor="end">Jl. Annur II</text>
                            <text x="550" y="435" text-anchor="middle">Jl. Annur I</text>
                        </g>
                        
                        <!-- Landmarks -->
                        <g>
                            <g transform="translate(240,190)">
                            <rect width="20" height="20" fill="#FBBC05" opacity="0.8" />
                            <text x="25" y="15" font-family="Arial" font-size="11">Indomaret</text>
                            </g>
                            
                            <g transform="translate(320,240)">
                            <rect width="20" height="20" fill="#FBBC05" opacity="0.8" />
                            <text x="25" y="15" font-family="Arial" font-size="11">Masjid</text>
                            </g>
                            
                            <g transform="translate(430,350)">
                            <rect width="20" height="20" fill="#FBBC05" opacity="0.8" />
                            <text x="25" y="15" font-family="Arial" font-size="11">Warung Makan</text>
                            </g>
                            
                            <g transform="translate(530,425)">
                            <rect width="20" height="20" fill="#FBBC05" opacity="0.8" />
                            <text x="25" y="15" font-family="Arial" font-size="11">Laundry</text>
                            </g>
                        </g>
                        
                        <!-- Route steps -->
                        <g font-family="Arial" font-size="11">
                            <foreignObject x="30" y="510" width="740" height="40">
                            <div xmlns="http://www.w3.org/1999/xhtml" style="display: flex; flex-wrap: wrap; gap: 5px;">
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">1. Pergilah ke barat</div>
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">2. Belok kanan menuju Jl. Tawes Raya</div>
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">3. Belok kiri menuju Jl. Tawes Raya</div>
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">4. Belok kanan ke Jl. Tawes Raya</div>
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">5. Belok kiri ke Jl. Lele Raya</div>
                            </div>
                            </foreignObject>
                            
                            <foreignObject x="30" y="545" width="740" height="30">
                            <div xmlns="http://www.w3.org/1999/xhtml" style="display: flex; flex-wrap: wrap; gap: 5px;">
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">6. Belok kanan ke Jl. Belut Raya</div>
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">7. Teruskan ke Jl. Annur Raya</div>
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">8. Belok kiri ke Jl. Annur II</div>
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">9. Belok kanan ke Jl. Annur I</div>
                                <div style="background-color: #E1F5FE; padding: 5px; border-radius: 4px; white-space: nowrap;">10. Tiba di lokasi</div>
                            </div>
                            </foreignObject>
                        </g>
                        
                        <!-- Map info and legend -->
                        <g transform="translate(30,30)">
                            <rect width="190" height="130" fill="white" stroke="#ccc" rx="5" />
                            
                            <text x="10" y="25" font-family="Arial" font-size="14" font-weight="bold">Info Rute:</text>
                            <text x="10" y="45" font-family="Arial" font-size="12">Jarak: 950 meter</text>
                            <text x="10" y="65" font-family="Arial" font-size="12">Waktu: 13 menit (jalan kaki)</text>
                            
                            <line x1="10" y1="75" x2="180" y2="75" stroke="#ccc" stroke-width="1" />
                            
                            <circle cx="20" cy="95" r="10" fill="#34A853" />
                            <text x="40" y="100" font-family="Arial" font-size="12">Titik Awal (BKS Cyber Park)</text>
                            
                            <circle cx="20" cy="120" r="10" fill="#EA4335" />
                            <text x="40" y="125" font-family="Arial" font-size="12">Titik Akhir (Jl. Annur I)</text>
                        </g>
                        
                        <!-- North Arrow -->
                        <g transform="translate(730,70)">
                            <circle r="25" fill="white" stroke="#ccc" />
                            <text x="0" y="-5" font-family="Arial" font-size="14" text-anchor="middle" font-weight="bold">U</text>
                            <line x1="0" y1="5" x2="0" y2="15" stroke="black" stroke-width="2" />
                            <path d="M -5,5 L 0,-5 L 5,5" fill="black" />
                        </g>
                    
                        </svg>
                        
                        <!-- HTML -->
                        <a href="https://maps.app.goo.gl/UEqhRHMWsYzX489u7" target="_blank" class="maps-button">
                        Lihat di Google Maps
                        </a>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Modal Booking -->
    <div id="bookingModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('bookingModal')">&times;</span>
            <h2>Booking Kontrakan</h2>
            
            <div class="modal-kontrakan-info">
                <img src="<?php echo htmlspecialchars($foto_utama); ?>" alt="<?php echo htmlspecialchars($kontrakan['nama_kontrakan']); ?>">
                <div class="modal-kontrakan-details">
                    <h3><?php echo htmlspecialchars($kontrakan['nama_kontrakan']); ?></h3>
                    <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($kontrakan['lokasi']); ?></p>
                    <p><i class="fas fa-money-bill-wave"></i> Rp <?php echo $harga_formatted; ?> / <?php echo $kontrakan['tipe_kontrakan'] === 'bulanan' ? 'bulan' : 'tahun'; ?></p>
                </div>
            </div>
            
            <form id="bookingForm" action="../logic/user/booking_kontrakan.php" method="POST" onsubmit="return false;">
                <input type="hidden" name="kontrakan_id" value="<?php echo $id; ?>">
                <input type="hidden" name="id_penyewa" value="<?php echo $user_id; ?>">
                <input type="hidden" name="harga_satuan" value="<?php echo $kontrakan['harga']; ?>">
                <input type="hidden" name="tipe_kontrakan" value="<?php echo $kontrakan['tipe_kontrakan']; ?>">
                
                <div class="form-group">
                    <label for="tanggal_mulai">Tanggal Mulai Sewa:</label>
                    <input type="date" id="tanggal_mulai" name="tanggal_mulai" required min="<?php echo date('Y-m-d'); ?>">
                </div>
                
                <div class="form-group">
                    <label for="durasi_sewa">Durasi Sewa (<?php echo $kontrakan['tipe_kontrakan'] === 'bulanan' ? 'bulan' : 'tahun'; ?>):</label>
                    <input type="number" id="durasi_sewa" name="durasi_sewa" min="1" value="1" required>
                </div>

                <div class="form-group">
                    <label for="total_bayar">Total Bayar</label>
                    <input type="number" step="0.01" class="form-control" name="total_bayar" id="total_bayar" required>
                </div>

                <div class="form-group">
                    <label for="total_harga">Total Harga:</label>
                    <input type="text" id="total_harga" name="total_harga" readonly value="Rp <?php echo $harga_formatted; ?>">
                    <input type="hidden" id="total_harga_value" name="total_harga_value" value="<?php echo $kontrakan['harga']; ?>">
                </div>

                <div class="form-group">
                    <label for="metode_pembayaran">Metode Pembayaran</label>
                    <select class="form-control" name="metode_pembayaran" id="metode_pembayaran">
                        <option value="">-- Pilih Metode --</option>
                        <option value="tunai">Tunai</option>
                        <option value="transfer">Transfer</option>
                    </select>
                </div>

                <div id="infoPembayaran" style="display: none;">
                    <div id="tunaiInfo" style="display: none;">Silakan bayar langsung ke kantor kami.</div>
                    <div id="transferInfo" style="display: none;">Silakan transfer ke rekening BCA 123456789 a.n. PT Kontrakan</div>
                    
                    <div id="buktiInput" class="form-group" style="display: none;">
                        <label for="bukti_pembayaran">Upload Bukti Pembayaran</label>
                        <input type="file" id="bukti_transaksi" name="bukti_pembayaran" accept="image/*">
                    </div>
                </div>

                <button type="submit" class="btn-submit">Booking Sekarang</button>
            </form>
        </div>
    </div>
    
    <!-- Modal Sewa -->
    <div id="sewaModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('sewaModal')">&times;</span>
            <h2>Sewa Kontrakan</h2>
            
            <div class="modal-kontrakan-info">
                <img src="<?php echo htmlspecialchars($foto_utama); ?>" alt="<?php echo htmlspecialchars($kontrakan['nama_kontrakan']); ?>">
                <div class="modal-kontrakan-details">
                    <h3><?php echo htmlspecialchars($kontrakan['nama_kontrakan']); ?></h3>
                    <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($kontrakan['lokasi']); ?></p>
                    <p><i class="fas fa-money-bill-wave"></i> Rp <?php echo $harga_formatted; ?> / <?php echo $kontrakan['tipe_kontrakan'] === 'bulanan' ? 'bulan' : 'tahun'; ?></p>
                </div>
            </div>
            
            <form id="sewaForm" action="../logic/user/sewa_kontrakan.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id_penyewa" value="<?php echo $_SESSION['user_user_id']; ?>"> 
                <input type="hidden" name="tanggal_selesai" id="tanggal_selesai">

                <input type="hidden" name="kontrakan_id" value="<?php echo $id; ?>">
                <input type="hidden" name="harga_satuan" value="<?php echo $kontrakan['harga']; ?>">
                <input type="hidden" name="tipe_kontrakan" value="<?php echo $kontrakan['tipe_kontrakan']; ?>">
                
                <div class="form-group">
                    <label for="tanggal_mulai_sewa">Tanggal Mulai Berlangsung Sewa: </label>
                    <input type="date" id="tanggal_mulai_sewa" name="tanggal_mulai" required min="<?php echo date('Y-m-d'); ?>" readonly>
                </div>
                
                <div class="form-group">
                    <label for="durasi_sewa_langsung">Durasi Sewa (<?php echo $kontrakan['tipe_kontrakan'] === 'bulanan' ? 'bulan' : 'tahun'; ?>):</label>
                    <input type="number" id="durasi_sewa_langsung" name="durasi_sewa" min="1" value="1" required onchange="hitungTotalHargaSewa()">
                </div>

                <div class="form-group">
                    <label for="total_bayar_perpanjangan">Total Bayar</label>
                    <input type="number" step="0.01" class="form-control" name="total_bayar" id="total_bayar_perpanjangan" required>
                </div>
                
                <div class="form-group">
                    <label for="total_harga_sewa">Total Harga:</label>
                    <input type="text" id="total_harga_sewa" name="total_harga" readonly value="Rp <?php echo $harga_formatted; ?>">
                    <input type="hidden" id="total_harga_sewa_value" name="total_harga_value" value="<?php echo $kontrakan['harga']; ?>">
                </div>

                <!-- Info Pembayaran -->
                <div class="form-group">
                    <label for="metode_pembayaran">Metode Pembayaran</label>
                        <select class="form-control" name="metode_pembayaran" id="metode_pembayaran2" onchange="toggleBukti2()">
                            <option value="">-- Pilih Metode --</option>
                            <option value="tunai">Tunai</option>
                            <option value="transfer">Transfer</option>
                        </select>
                    </div>

                    <div id="infoPembayaran2" style="display: none;">
                    <div id="tunaiInfo2" style="display: none;">Silakan bayar langsung ke kantor kami.</div>
                    <div id="transferInfo2" style="display: none;">Silakan transfer ke rekening BCA 123456789 a.n. PT Kontrakan</div>
                    
                    <div id="buktiInput2" class="form-group" style="display: none;">
                        <label for="bukti_pembayaran">Upload Bukti Pembayaran</label>
                        <input type="file" id="bukti_transaksi" name="bukti_pembayaran" accept="image/*">
                    </div>

                </div>
                

                
                <button type="submit" class="btn-submit">Sewa Sekarang</button>
            </form>
        </div>
    </div>
    
    <script src="../assets/js/detail-kontrakan.js"></script>
    <script>
        // Data untuk digunakan di JS
        const hargaSatuan = <?php echo $kontrakan['harga']; ?>;
        const tipeKontrakan = "<?php echo $kontrakan['tipe_kontrakan']; ?>";
    </script>

    <script>
        // Booking Notification Script
            document.addEventListener('DOMContentLoaded', function() {
                // Check if there's a booking session message
                const bookingStatus = '<?php echo isset($_SESSION["booking_status"]) ? $_SESSION["booking_status"] : ""; ?>';
                const bookingMessage = '<?php echo isset($_SESSION["booking_message"]) ? $_SESSION["booking_message"] : ""; ?>';

                // Display SweetAlert if there's a message
                if (bookingStatus && bookingMessage) {
                    // Determine icon and title based on status
                    const icon = bookingStatus === 'success' ? 'success' : 'error';
                    const title = bookingStatus === 'success' ? 'Berhasil!' : 'Gagal!';

                    // Show SweetAlert
                    Swal.fire({
                        icon: icon,
                        title: title,
                        text: bookingMessage,
                        confirmButtonText: 'OK'
                    });

                    // Clear the session messages to prevent repeated showing
                    <?php 
                    unset($_SESSION['booking_status']);
                    unset($_SESSION['booking_message']);
                    ?>
                }
            });
    </script>
</body>
</html>