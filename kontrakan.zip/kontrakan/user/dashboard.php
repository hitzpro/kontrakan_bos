<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['user_user_id'])) {
    header("Location: ../public/login.php");
    exit();
}

// Ambil data user
$user_id = $_SESSION['user_user_id'];
$userId = $_SESSION['user_user_id'];

$query_notif = "SELECT id, keterangan FROM penyewaan 
          WHERE id_penyewa = '$userId' 
            AND metode_pembayaran = 'transfer' 
            AND status_sewa NOT IN ('selesai', 'dibatalkan') 
            AND keterangan IS NOT NULL AND keterangan != ''
          ORDER BY id DESC LIMIT 1";

$result = mysqli_query($conn, $query_notif);
if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $_SESSION['swal_notification'] = $row['keterangan'];

    // Kosongkan supaya cuma muncul sekali
    mysqli_query($conn, "UPDATE penyewaan SET keterangan = NULL WHERE id = " . $row['id']);
}


$query = "SELECT * FROM pengguna WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

// Handle profile update messages
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $status = $_SESSION['status'];
    $title = $_SESSION['title'];
    
    // Clear session message
    unset($_SESSION['message']);
    unset($_SESSION['status']);
    unset($_SESSION['title']);
}

// Fetch booking and rental data
$records_per_page = 5;

// Booking tab
$page_booking = isset($_GET['page_booking']) ? (int)$_GET['page_booking'] : 1;
if ($page_booking < 1) $page_booking = 1;
$offset_booking = ($page_booking - 1) * $records_per_page;

// Sewa tab
$page_sewa = isset($_GET['page_sewa']) ? (int)$_GET['page_sewa'] : 1;
if ($page_sewa < 1) $page_sewa = 1;
$offset_sewa = ($page_sewa - 1) * $records_per_page;

// Prepared statement for booking data with a join to get 'nama_kontrakan'
$query_booking = "
        SELECT b.id, b.tanggal_booking, b.tanggal_mulai, b.tanggal_selesai, b.metode_pembayaran, 
            b.bukti_pembayaran, b.status_booking, b.payment_upload_deadline, b.keterangan, b.kode_pembayaran, 
            k.nama_kontrakan, k.harga
        FROM booking b
        LEFT JOIN data_kontrakan k ON b.id_kontrakan = k.id
        WHERE b.id_penyewa = ? 
        ORDER BY b.tanggal_booking DESC 
        LIMIT ?, ?
        ";
$stmt_booking = mysqli_prepare($conn, $query_booking);
mysqli_stmt_bind_param($stmt_booking, "iii", $user_id, $offset_booking, $records_per_page);
mysqli_stmt_execute($stmt_booking);
$result_booking = mysqli_stmt_get_result($stmt_booking);




// Count total bookings
$query_count_booking = "SELECT COUNT(*) as total FROM booking WHERE id_penyewa = ?";
$stmt_count_booking = mysqli_prepare($conn, $query_count_booking);
mysqli_stmt_bind_param($stmt_count_booking, "i", $user_id);
mysqli_stmt_execute($stmt_count_booking);
$total_booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_count_booking))['total'];
$total_pages_booking = ceil($total_booking / $records_per_page);

// Prepared statement for rental data with a join to get 'nama_kontrakan'
$query_sewa = "
    SELECT p.id, p.tanggal_mulai, p.tanggal_selesai, p.durasi_sewa, p.harga_sewa, 
           p.total_bayar, p.metode_pembayaran, p.bukti_pembayaran, p.status_pembayaran, 
           p.status_sewa, p.keterangan, p.kode_pembayaran, k.nama_kontrakan 
    FROM penyewaan p
    LEFT JOIN data_kontrakan k ON p.id_kontrakan = k.id
    WHERE p.id_penyewa = ? 
    ORDER BY p.tanggal_mulai DESC 
    LIMIT ?, ?";

$stmt_sewa = mysqli_prepare($conn, $query_sewa);
mysqli_stmt_bind_param($stmt_sewa, "iii", $user_id, $offset_sewa, $records_per_page);
mysqli_stmt_execute($stmt_sewa);
$result_sewa = mysqli_stmt_get_result($stmt_sewa);


// Count total rentals
$query_count_sewa = "SELECT COUNT(*) as total FROM penyewaan WHERE id_penyewa = ?";
$stmt_count_sewa = mysqli_prepare($conn, $query_count_sewa);
mysqli_stmt_bind_param($stmt_count_sewa, "i", $user_id);
mysqli_stmt_execute($stmt_count_sewa);
$total_sewa = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_count_sewa))['total'];
$total_pages_sewa = ceil($total_sewa / $records_per_page);

// Get active rentals for extension section
$query_active_sewa = "SELECT id, tanggal_mulai, tanggal_selesai, durasi_sewa, 
                             total_bayar, harga_sewa 
                      FROM penyewaan 
                      WHERE id_penyewa = ? AND status_sewa = 'aktif' 
                      ORDER BY tanggal_selesai ASC";
$stmt_active_sewa = mysqli_prepare($conn, $query_active_sewa);
mysqli_stmt_bind_param($stmt_active_sewa, "i", $user_id);
mysqli_stmt_execute($stmt_active_sewa);
$result_active_sewa = mysqli_stmt_get_result($stmt_active_sewa);

// Ambil data perpanjangan sewa
// Query untuk mendapatkan data perpanjangan dengan join ke tabel kontrakan untuk mendapatkan harga
$query_perpanjangan = "
    SELECT p.id, p.tanggal_mulai, p.tanggal_selesai, p.status_sewa,
           k.id as kontrakan_id, k.nama_kontrakan, k.harga
    FROM penyewaan p
    LEFT JOIN data_kontrakan k ON p.id_kontrakan = k.id
    WHERE p.id_penyewa = ?
    ORDER BY p.tanggal_selesai DESC
    LIMIT ?, ?
";

$stmt_perpanjangan = mysqli_prepare($conn, $query_perpanjangan);
mysqli_stmt_bind_param($stmt_perpanjangan, "iii", $user_id, $offset, $records_per_page);
mysqli_stmt_execute($stmt_perpanjangan);
$result_perpanjangan = mysqli_stmt_get_result($stmt_perpanjangan);


// Pagination setup
$records_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Query untuk menampilkan riwayat perpanjangan sewa
$query_riwayat_perpanjangan = "
    SELECT 
        ps.id,
        dk.nama_kontrakan,
        ps.tanggal_pengajuan,
        ps.durasi,
        dk.harga,
        (dk.harga * ps.durasi) AS total_bayar,
        ps.status,
        ps.metode_pembayaran
    FROM perpanjangan_sewa ps
    LEFT JOIN penyewaan p ON ps.id_penyewaan = p.id
    LEFT JOIN data_kontrakan dk ON p.id_kontrakan = dk.id
    WHERE p.id_penyewa = ?
    ORDER BY ps.tanggal_pengajuan DESC
    LIMIT ?, ?
";

$stmt = mysqli_prepare($conn, $query_riwayat_perpanjangan);
mysqli_stmt_bind_param($stmt, "iii", $user_id, $offset, $records_per_page);
mysqli_stmt_execute($stmt);
$result_riwayat_perpanjangan = mysqli_stmt_get_result($stmt);


// Waktu sekarang (timestamp)
$currentTimestamp = time();

// Ambil semua booking yang statusnya belum selesai
$query = "
    SELECT id, payment_upload_deadline, status_booking 
    FROM booking 
    WHERE status_booking IN ('belum bayar', 'belum lunas', 'menunggu')
";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bookingId = (int) $row['id'];
        $deadline = (int) $row['payment_upload_deadline'];
        $currentStatus = $row['status_booking'];

        // Jika sekarang sudah lewat dari deadline
        if ($currentTimestamp > $deadline) {
            $update = $conn->prepare("
                UPDATE booking 
                SET status_booking = 'dibatalkan', 
                    keterangan = CONCAT(IFNULL(keterangan, ''), ' | Sistem: Tidak membayar booking tepat waktu.')
                WHERE id = ?
            ");
            $update->bind_param("i", $bookingId);
            $update->execute();
            $update->close();
        }
    }
}

function getStatusClass($status) {
    switch (strtolower($status)) {
        case 'belum bayar':
            return 'status-belum-bayar';
        case 'belum lunas':
            return 'status-belum-lunas';
        case 'menunggu':
            return 'status-menunggu';
        case 'terkonfirmasi':
            return 'status-terkonfirmasi';
        case 'dibatalkan':
            return 'status-dibatalkan';
        default:
            return '';
    }
}


$conn->close();

// $penyewaanData = [];
// while ($row = $result->fetch_assoc()) {
//     $penyewaanData[] = $row;
// }
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo htmlspecialchars($user['nama_pengguna']); ?></title>
    <link rel="shortcut icon" href="../images/logo.png" type="image/x-icon">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts - Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/dashboard-user.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <a href="../public/index.php?id=<?= $user_id ?>" class="sidebar-header" style="text-decoration: none; color: inherit;">
                <h2><i class="fas fa-home"></i> H. Sagio</h2>
            </a>

            <div class="sidebar-user">
                <div class="user-avatar">
                    <?php if (!empty($user['foto'])): ?>
                        <img src="profiles/<?php echo htmlspecialchars($user['foto']); ?>" alt="Foto Profil">
                    <?php else: ?>
                        <div class="avatar-placeholder">
                            <i class="fas fa-user"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="user-info">
                    <h3><?php echo htmlspecialchars($user['nama_pengguna']); ?></h3>
                    <p><?php echo htmlspecialchars($user['email']); ?></p>
                </div>
            </div>
            <nav class="sidebar-menu">
                <ul>
                    <li class="active menu-item" data-target="profile">
                        <a href="#"><i class="fas fa-user-circle"></i> Dashboard</a>
                    </li>
                    <li class="menu-item" data-target="kelola-penyewaan">
                        <a href="#"><i class="fas fa-key"></i> Kelola Penyewaan</a>
                    </li>
                    <li class="menu-item" data-target="perpanjang-penyewaan">
                        <a href="#"><i class="fas fa-calendar-plus"></i> Perpanjang Penyewaan</a>
                    </li>
                    <li>
                        <a href="#" id="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <div class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </div>
                <h1>Dashboard</h1>
                <div class="user-dropdown">
                    <div class="dropdown-trigger">
                        <?php if (!empty($user['foto'])): ?>
                            <img src="profiles/<?php echo htmlspecialchars($user['foto']); ?>" alt="Foto Profil">
                        <?php else: ?>
                            <div class="avatar-placeholder-small">
                                <i class="fas fa-user"></i>
                            </div>
                        <?php endif; ?>
                        <span><?php echo htmlspecialchars($user['nama_pengguna']); ?> <i class="fas fa-chevron-down"></i></span>
                    </div>
                    <div class="dropdown-menu">
                        <a href="#" class="dropdown-item" data-target="profile"><i class="fas fa-user"></i> Profil</a>
                        <a href="#" class="dropdown-item" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>

            <!-- Content Sections -->
            <div class="content-section active" id="profile">
                <div class="card">
                    <div class="card-header">
                        <h2>Profil Pengguna</h2>
                    </div>
                    <div class="card-body">
                        <form action="../logic/user/update-profile.php" method="post" enctype="multipart/form-data" id="profile-form">
                            <div class="profile-photo">
                                <div class="photo-container">
                                    <?php if (!empty($user['foto'])): ?>
                                        <img src="profiles/<?php echo htmlspecialchars($user['foto']); ?>" alt="Foto Profil" id="profile-preview">
                                    <?php else: ?>
                                        <div class="avatar-placeholder-large" id="profile-preview-placeholder">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="photo-upload">
                                    <label for="foto" class="btn-upload">
                                        <i class="fas fa-camera"></i> Ubah Foto
                                    </label>
                                    <input type="file" id="foto" name="foto" accept="image/*" style="display: none;">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email</label>
                                <div class="input-group">
                                    <span class="input-icon"><i class="fas fa-envelope"></i></span>
                                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required aria-describedby="email-help">
                                </div>
                                <small id="email-help" class="form-note">Email yang akan digunakan untuk notifikasi dan login</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="nama_pengguna">Nama Pengguna</label>
                                <div class="input-group">
                                    <span class="input-icon"><i class="fas fa-user"></i></span>
                                    <input type="text" id="nama_pengguna" name="nama_pengguna" value="<?php echo htmlspecialchars($user['nama_pengguna']); ?>" required>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="no_telepon">Nomor Telepon</label>
                                <div class="input-group">
                                    <span class="input-icon"><i class="fas fa-phone"></i></span>
                                    <input type="tel" id="no_telepon" name="no_telepon" value="<?php echo htmlspecialchars($user['no_telepon']); ?>" required>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="kata_sandi_sekarang">Kata Sandi Sekarang</label>
                                <div class="input-group">
                                    <span class="input-icon"><i class="fas fa-lock"></i></span>
                                    <input type="password" id="kata_sandi_sekarang" name="kata_sandi_sekarang">
                                    <span class="toggle-password" onclick="togglePassword('kata_sandi_sekarang')">
                                        <i class="fas fa-eye" id="kata_sandi_sekarang-eye-icon"></i>
                                    </span>
                                </div>
                                <small class="form-note">* Kosongkan jika tidak ingin mengubah kata sandi</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="kata_sandi_baru">Kata Sandi Baru</label>
                                <div class="input-group">
                                    <span class="input-icon"><i class="fas fa-lock"></i></span>
                                    <input type="password" id="kata_sandi_baru" name="kata_sandi_baru">
                                    <span class="toggle-password" onclick="togglePassword('kata_sandi_baru')">
                                        <i class="fas fa-eye" id="kata_sandi_baru-eye-icon"></i>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="konfirmasi_kata_sandi">Konfirmasi Kata Sandi Baru</label>
                                <div class="input-group">
                                    <span class="input-icon"><i class="fas fa-lock"></i></span>
                                    <input type="password" id="konfirmasi_kata_sandi" name="konfirmasi_kata_sandi">
                                    <span class="toggle-password" onclick="togglePassword('konfirmasi_kata_sandi')">
                                        <i class="fas fa-eye" id="konfirmasi_kata_sandi-eye-icon"></i>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="info-section">
                                <div class="info-item">
                                    <span class="info-label">Status Akun</span>
                                    <span class="info-value">
                                        <?php if ($user['status'] === 'aktif'): ?>
                                            <span class="status-badge active">Aktif</span>
                                        <?php else: ?>
                                            <span class="status-badge inactive">Nonaktif</span>
                                        <?php endif; ?>
                                    </span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Terakhir Login</span>
                                    <span class="info-value"><?php echo $user['terakhir_masuk'] ? date('d M Y H:i', strtotime($user['terakhir_masuk'])) : 'Belum pernah login'; ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Tanggal Pendaftaran</span>
                                    <span class="info-value"><?php echo date('d M Y', strtotime($user['dibuat_pada'])); ?></span>
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="btn-save">Simpan Perubahan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="content-section" id="kelola-penyewaan">
                <div class="tabs-header">
                    <div class="tab-button active" data-tab="booking-tab">Booking</div>
                    <div class="tab-button" data-tab="sewa-tab">Sewa</div>
                </div>

                <div class="tab-content active" id="booking-tab">
                    <h3>Daftar Booking</h3>
                    <table aria-label="Daftar booking pengguna">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Kontrakan</th>
                                <th scope="col">Tgl Mulai</th>
                                <th scope="col">Durasi</th>
                                <th scope="col">Tgl Selesai</th>
                                <th scope="col">Harga</th>
                                <th scope="col">Status</th>
                                <th scope="col">Tanggal Booking</th>
                                <th scope="col">Batas Bayar</th>
                                <th scope="col">Metode Pembayaran</th>
                                <th scope="col" >Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result_booking) > 0): 
                                $no = $offset_booking + 1;
                                while ($row = mysqli_fetch_assoc($result_booking)): ?>
                                <?php
                                    // Hitung durasi dalam hari
                                    $start = new DateTime($row['tanggal_mulai']);
                                    $end = new DateTime($row['tanggal_selesai']);
                                    $interval = $start->diff($end);
                                    $durasi = $interval->days . ' hari';

                                    // Format harga
                                    $harga = number_format($row['harga'], 0, ',', '.');
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($row['nama_kontrakan']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_mulai'])) ?></td>
                                    <td><?= $durasi ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_selesai'])) ?></td>
                                    <td>Rp <?= $harga ?></td>
                                    <td>
                                        <span class="status-badge <?= getStatusClass($row['status_booking']) ?>">
                                            <?= ucfirst($row['status_booking']) ?>
                                        </span>
                                    </td>

                                    
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_booking'])) ?></td>
                                    <td>
                                        <?= isset($row['payment_upload_deadline']) && is_numeric($row['payment_upload_deadline']) 
                                            ? date('d/m/Y H:i', $row['payment_upload_deadline']) 
                                            : '-' ?>
                                    </td>

                                    <td><?= htmlspecialchars($row['metode_pembayaran']) ?></td>
                                    <!-- Tambahkan di <td> baris booking -->
                                    <td class="actions">
                                        <?php if ($row['metode_pembayaran'] == 'tunai'): ?>
                                            <?php if ($row['status_booking'] == 'belum bayar'): ?>
                                                <button class="action-btn bayar-btn" data-id="<?= $row['id'] ?>" data-harga="<?= $row['harga'] ?>">
                                                    Konfirmasi
                                                </button>
                                                <!-- Tombol baru -->
                                                <button class="action-btn lihat-kode-btn" data-kode="<?= htmlspecialchars($row['kode_pembayaran']) ?>">
                                                    Lihat Kode Pembayaran
                                                </button>
                                            <?php endif; ?>
                                                                            
                                        <?php elseif ($row['metode_pembayaran'] == 'transfer'): ?>
                                            <?php if ($row['status_booking'] != 'dibatalkan'): ?>
                                                <?php if ($row['status_booking'] == 'belum bayar' || $row['status_booking'] == 'belum lunas'): ?>
                                                    <!-- Upload bukti pertama kali -->
                                                    <button class="action-btn upload-bukti-btn" data-id="<?= $row['id'] ?>">
                                                        Upload Bukti Pembayaran
                                                    </button>
                                                <?php elseif ($row['status_booking'] == 'menunggu'): ?>
                                                    <!-- Reupload hanya ketika status menunggu -->
                                                    <button class="action-btn upload-bukti-btn" data-id="<?= $row['id'] ?>">
                                                        Reupload Bukti
                                                    </button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php if ($row['status_booking'] != 'terkonfirmasi' && $row['status_booking'] != 'dibatalkan'): ?>
                                            <button class="action-btn hapus-btn" data-id="<?= $row['id'] ?>" data-type="booking">Batalkan</button>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="9">Belum ada data booking.</td></tr>
                                <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Pagination Booking -->
                    <div class="pagination">
                        <?php for ($i = 1; $i <= $total_pages_booking; $i++): ?>
                            <a href="?page_booking=<?= $i ?>&page_sewa=<?= $page_sewa ?>" class="<?= ($i == $page_booking) ? 'active' : '' ?>"><?= $i ?></a>
                        <?php endfor; ?>
                    </div>
                </div>


                <div class="tab-content" id="sewa-tab">
                    <h3>Daftar Penyewaan</h3>
                    <table aria-label="Daftar penyewaan pengguna">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kontrakan</th>
                                <th>Tgl Mulai</th>
                                <th>Tgl Selesai</th>
                                <th>Durasi (hari)</th>
                                <th>Harga Sewa</th>
                                <th>Total Bayar</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result_sewa) > 0): 
                                $no = $offset_sewa + 1;
                                while ($row = mysqli_fetch_assoc($result_sewa)): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($row['nama_kontrakan']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_mulai'])) ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_selesai'])) ?></td>
                                    <td><?= $row['durasi_sewa'] * 30 ?> hari</td>
                                    <td>Rp <?= number_format($row['harga_sewa'], 0, ',', '.') ?></td>
                                    <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                    <td><?= ucfirst(str_replace('_', ' ', $row['status_sewa'])) ?></td>
                                    <td class="actions">
                                        <?php if ($row['status_sewa'] != 'dibatalkan'): ?>
                                            
                                            <!-- Tombol Konfirmasi untuk Tunai -->
                                            <?php if ($row['metode_pembayaran'] == 'tunai' && $row['status_sewa'] == 'belum bayar'): ?>
                                                <button class="action-btn konfirmasi-tunai-sewa-btn" 
                                                        data-id="<?= $row['id'] ?>" 
                                                        data-harga="<?= $row['harga'] ?>">
                                                    Konfirmasi
                                                </button>
                                            <?php endif; ?>

                                            <!-- Tombol Upload/Reupload Bukti untuk Transfer -->
                                            <?php if ($row['metode_pembayaran'] == 'transfer'): ?>
                                                <button class="action-btn upload-bukti-sewa-btn" 
                                                        data-id="<?= $row['id'] ?>">
                                                    <?= !empty($row['bukti_pembayaran']) ? 'Reupload Bukti' : 'Upload Bukti Pembayaran' ?>
                                                </button>
                                            <?php endif; ?>

                                            <!-- Tombol Batalkan -->
                                            <?php if ($row['status_sewa'] != 'terkonfirmasi'): ?>
                                                <button class="action-btn hapus-btn" 
                                                        data-id="<?= $row['id'] ?>" 
                                                        data-type="sewa">
                                                    Batalkan
                                                </button>
                                            <?php endif; ?>

                                            <!-- Tombol Lihat Kode Pembayaran hanya jika bukan transfer -->
                                            <?php if ($row['metode_pembayaran'] != 'transfer'): ?>
                                                <button class="action-btn lihat-kode-pembayaran-btn" 
                                                        data-kode="<?= $row['kode_pembayaran'] ?>">
                                                    Lihat Kode Pembayaran
                                                </button>
                                            <?php endif; ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>


                                </tr>
                            <?php endwhile; else: ?>
                                <tr><td colspan="9">Belum ada data sewa.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>


                    <!-- Pagination Sewa -->
                    <div class="pagination">
                        <?php for ($i = 1; $i <= $total_pages_sewa; $i++): ?>
                            <a href="?page_booking=<?= $page_booking ?>&page_sewa=<?= $i ?>" class="<?= ($i == $page_sewa) ? 'active' : '' ?>"><?= $i ?></a>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>

            <div class="content-section" id="perpanjang-penyewaan">

                <!-- ======= PERPANJANGAN SEWA KONTRAKAN ====== -->
                <div class="card">
                    <div class="card-header">
                        <h2>Perpanjang Sewa Kontrakan</h2>
                    </div>
                    <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kontrakan</th>
                                <th>Tgl Mulai</th>
                                <th>Tgl Selesai</th>
                                <th>Tenggat Waktu</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result_perpanjangan) > 0): 
                                $no = $offset + 1;
                                while ($row = mysqli_fetch_assoc($result_perpanjangan)): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($row['nama_kontrakan']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_mulai'])) ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tanggal_selesai'])) ?></td>
                                    <?php
                                        $status = '';
                                        $tanggalSelesai = strtotime($row['tanggal_selesai']);
                                        $sekarang = time();
                                        $selisihHari = ($tanggalSelesai - $sekarang) / (60 * 60 * 24);

                                        if ($tanggalSelesai < $sekarang) {
                                            $status = "<span class='badge bg-danger'>Sudah Habis</span>";
                                        } elseif ($selisihHari <= 7) {
                                            $status = "<span class='badge bg-warning'>Segera Habis</span>";
                                        } else {
                                            $status = "<span class='badge bg-success'>Masih Lama</span>";
                                        }
                                    ?>
                                    <td><?= $status ?></td>
                                    <td><?= ucfirst($row['status_sewa']) ?></td>
                                    <td>
                                        <button class='btn btn-warning perpanjang-btn' 
                                                data-id="<?= $row['id'] ?>" 
                                                data-kontrakan="<?= $row['kontrakan_id'] ?>"
                                                data-harga="<?= $row['harga'] ?>">
                                            Perpanjang
                                        </button>
                                    </td>
                                </tr>
                            <?php endwhile; else: ?>
                                <tr><td colspan="7">Belum ada data perpanjangan.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                            <div id="pagination-container">
                                <!-- Paginasi akan muncul di sini -->
                            </div>

                            <!-- Tombol Perpanjangan -->
                            <div id="perpanjang-button-container">
                                <button id="perpanjang-sewa-button" class="btn btn-primary" style="display:none;">Lakukan Perpanjangan</button>
                            </div>
                        
                    </div>
                </div>

                <!-- ======= RIWAYAT PERPANJANGAN ====== -->
                <div class="card">
                    <div class="card-header">
                        <h2>Riwayat Perpanjangan</h2>
                    </div>
                    <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Kontrakan</th>
                                        <th>Tanggal Pengajuan</th>
                                        <th>Durasi (bulan)</th>
                                        <th>Total Bayar</th>
                                        <th>Status</th>
                                        <th>Metode</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (mysqli_num_rows($result_riwayat_perpanjangan) > 0): 
                                        $no = $offset + 1;
                                        while ($row = mysqli_fetch_assoc($result_riwayat_perpanjangan)): ?>
                                            <tr>
                                                <td><?= $no++ ?></td>
                                                <td><?= htmlspecialchars($row['nama_kontrakan']) ?></td>
                                                <td><?= date('d/m/Y', strtotime($row['tanggal_pengajuan'])) ?></td>
                                                <td><?= (int)$row['durasi'] ?> bulan</td>
                                                <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                                <td>
                                                    <?php
                                                        if ($row['status'] == 'menunggu') {
                                                            echo "<span class='badge bg-warning'>Menunggu</span>";
                                                        } elseif ($row['status'] == 'disetujui') {
                                                            echo "<span class='badge bg-success'>Disetujui</span>";
                                                        } elseif ($row['status'] == 'ditolak') {
                                                            echo "<span class='badge bg-danger'>Ditolak</span>";
                                                        }
                                                        elseif ($row['status'] == 'dibatalkan') {
                                                            echo "<span class='badge bg-danger'>Dibatalkan</span>";
                                                        }
                                                    ?>
                                                </td>
                                                <td><?= ucfirst($row['metode_pembayaran']) ?></td>
                                                <td>
                                                    <?php if ($row['status'] != 'dibatalkan'): ?>
                                                        <button class="btn btn-danger btn-sm hapus-perpanjangan" data-id="<?= $row['id'] ?>">Batalkan</button>
                                                    <?php else: ?>
                                                        -
                                                    <?php endif; ?>

                                                </td>
                                            </tr>
                                    <?php endwhile; else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center">Belum ada data perpanjangan.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>

                            <div id="pagination-container">
                                <!-- Paginasi akan muncul di sini -->
                            </div>

                            <!-- Tombol Perpanjangan -->
                            <div id="perpanjang-button-container">
                                <button id="perpanjang-sewa-button" class="btn btn-primary" style="display:none;">Lakukan Perpanjangan</button>
                            </div>
                        
                    </div>
                </div>
            </div>

            <div id="perpanjanganModal" class="modal" style="display: none;">
                <div class="custom-modal-content">
                    <span class="custom-close" id="closeModalBtn">&times;</span>
                    <h3>Form Perpanjangan Sewa</h3>
                    <form id="form-perpanjangan" enctype="multipart/form-data">
                        <!-- Hidden fields -->
                        <input type="hidden" id="id_penyewaan" name="id_penyewaan">
                        <input type="hidden" id="id_kontrakan" name="id_kontrakan">

                        <!-- Date fields -->
                        <div class="form-group">
                            <label for="tanggal_mulai">Tanggal Mulai</label>
                            <input type="date" id="tanggal_mulai" name="tanggal_mulai" required>
                        </div>
                        <div class="form-group">
                            <label for="tanggal_selesai">Tanggal Selesai</label>
                            <input type="date" id="tanggal_selesai" name="tanggal_selesai" required>
                        </div>
                        <div class="form-group">
                            <label for="durasi">Durasi (Bulan)</label>
                            <input type="number" id="durasi" name="durasi" min="1" required>
                        </div>

                        <!-- Payment method -->
                        <div class="form-group">
                            <label for="metode_pembayaran">Metode Pembayaran</label>
                            <select id="metode_pembayaran" name="metode_pembayaran" required>
                                <option value="tunai">Tunai</option>
                                <option value="transfer">Transfer</option>
                            </select>
                        </div>
                        
                        <!-- Payment information (dynamic display) -->
                        <div id="info_pembayaran_tunai" class="payment-info" style="display: none;">
                            <div class="alert alert-info">
                                Segera bayar ke pemilik kontrakan secara tunai
                            </div>
                        </div>
                        
                        <div id="info_pembayaran_transfer" class="payment-info" style="display: none;">
                            <div class="alert alert-info">
                                <p><strong>Rekening Pembayaran:</strong></p>
                                <p>Bank BCA: 1234567890</p>
                                <p>Atas Nama: PT Kontrakan Sejahtera</p>
                            </div>
                            <div class="form-group" id="upload_bukti_div">
                                <label for="bukti_pembayaran">Upload Bukti Pembayaran</label>
                                <input type="file" id="bukti_pembayaran" name="bukti_pembayaran" accept=".jpg,.jpeg,.png,.pdf">
                                <small>Maks 5MB (JPG, JPEG, PNG, PDF)</small>
                            </div>
                        </div>

                        <!-- Payment amount -->
                        <div class="form-group">
                            <label for="total_bayar">Total Bayar</label>
                            <input type="number" id="total_bayar" name="total_bayar" required readonly>
                        </div>
                        
                        <!-- Price display -->
                        <div class="form-group">
                            <label for="total_bayar_display">Total Harga</label>
                            <input type="text" id="total_bayar_display" readonly>
                            <input type="hidden" id="total_harga" name="total_harga">
                        </div>
                        
                        <!-- Optional note -->
                        <div class="form-group">
                            <label for="keterangan">Keterangan (Opsional)</label>
                            <textarea id="keterangan" name="keterangan" rows="3"></textarea>
                        </div>
                        
                        <!-- Submit button -->
                        <button type="submit" class="submit-btn">Perpanjang</button>
                    </form>
                </div>
            </div>

        </div>
    </div>

<?php if (isset($_SESSION['swal_notification'])): ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        icon: 'info',
        title: 'Pemberitahuan',
        text: "<?php echo addslashes($_SESSION['swal_notification']); ?>",
        confirmButtonText: 'OK'
    });
</script>
<?php unset($_SESSION['swal_notification']); ?>
<?php endif; ?>


    <?php if (isset($message)): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: '<?php echo $status; ?>',
                title: '<?php echo $title; ?>',
                text: '<?php echo $message; ?>',
                timer: 3000,
                timerProgressBar: true
            });
        });
    </script>
    <?php endif; ?>

    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="../assets/js/dashboard-user.js"></script>
    <script>
        function showToast(type = 'success', message = '') {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: type,
                title: message,
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true
            });
        }
    </script>

    <?php if (isset($_SESSION['toast'])): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                showToast("<?= $_SESSION['toast']['type'] ?>", "<?= $_SESSION['toast']['message'] ?>");
            });
        </script>
        <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>


    <script>
// Pastikan SweetAlert2 sudah dimuat
// Jika belum, muat secara dinamis
function loadSweetAlert() {
    if (typeof Swal === 'undefined') {
        console.log('Loading SweetAlert2 library');
        return new Promise((resolve, reject) => {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = 'https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.26/sweetalert2.min.css';
            document.head.appendChild(link);
            
            const script = document.createElement('script');
            script.src = 'https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.26/sweetalert2.all.min.js';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }
    return Promise.resolve();
}

// Hanya pasang event listener sekali
function attachUploadListeners() {
    console.log('Mencoba memasang event listener pada tombol upload');
    
    // Menggunakan querySelector untuk menemukan tombol
    const buttons = document.querySelectorAll('.upload-bukti-btn');
    console.log('Jumlah tombol ditemukan:', buttons.length);
    
    if (buttons.length === 0) {
        console.error('TIDAK ADA TOMBOL DITEMUKAN! Periksa kelas CSS upload-bukti-btn');
        return;
    }
    
    // Pasang event listener
    buttons.forEach(button => {
        console.log('Memasang listener pada tombol dengan data-id:', button.getAttribute('data-id'));
        
        // Hapus event listener lama untuk mencegah duplikasi
        button.removeEventListener('click', handleButtonClick);
        
        // Pasang event listener baru
        button.addEventListener('click', handleButtonClick);
    });
}

// Handler untuk tombol
async function handleButtonClick(e) {
    e.preventDefault();
    console.log('TOMBOL DIKLIK!');
    
    const bookingId = this.getAttribute('data-id');
    console.log('Booking ID:', bookingId);
    
    // Load SweetAlert if needed
    await loadSweetAlert();
    
    // Langsung ke dialog upload dengan SweetAlert
    uploadFileDenganSweetAlert(bookingId);
}

// Fungsi upload file dengan SweetAlert
async function uploadFileDenganSweetAlert(bookingId) {
    console.log('Memulai upload dengan SweetAlert untuk booking ID:', bookingId);
    
    // Buat element input file sementara
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.jpg,.jpeg,.png,.pdf';
    fileInput.classList.add('swal2-file');
    
    // Event listener untuk fileInput
    const fileSelectionPromise = new Promise(resolve => {
        fileInput.addEventListener('change', function() {
            if (!fileInput.files.length) {
                resolve(null);
                return;
            }
            resolve(fileInput.files[0]);
        });
    });
    
    // Trigger klik untuk membuka dialog file
    fileInput.click();
    
    // Tunggu file dipilih
    const file = await fileSelectionPromise;
    if (!file) {
        console.log('Tidak ada file yang dipilih');
        return;
    }
    
    console.log('File dipilih:', file.name, file.type, file.size);
    
    // Validasi file
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    
    if (file.size > maxSize) {
        Swal.fire({
            icon: 'error',
            title: 'File terlalu besar',
            text: 'Ukuran file maksimal 5MB',
            confirmButtonColor: '#3085d6'
        });
        return;
    }
    
    if (!allowedTypes.includes(file.type)) {
        Swal.fire({
            icon: 'error',
            title: 'Tipe file tidak diizinkan',
            text: 'Hanya file JPG, JPEG, PNG, atau PDF yang diizinkan',
            confirmButtonColor: '#3085d6'
        });
        return;
    }
    
    // Preview file jika itu gambar
    let previewHtml = '';
    if (file.type.startsWith('image/')) {
        previewHtml = `
            <div class="mt-3" style="max-width: 100%; text-align: center;">
                <img id="file-preview" src="${URL.createObjectURL(file)}" 
                     style="max-width: 100%; max-height: 200px; object-fit: contain;">
            </div>
        `;
    } else {
        previewHtml = `
            <div class="mt-3" style="text-align: center;">
                <i class="fa fa-file-pdf" style="font-size: 48px; color: #dc3545;"></i>
                <p>${file.name}</p>
            </div>
        `;
    }
    
    // Konfirmasi upload dengan SweetAlert
    const result = await Swal.fire({
        title: 'Upload Bukti Pembayaran',
        html: `
            <p>File yang dipilih: <strong>${file.name}</strong></p>
            <p>Ukuran file: <strong>${(file.size / 1024 / 1024).toFixed(2)} MB</strong></p>
            ${previewHtml}
        `,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Upload',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33'
    });
    
    if (result.isConfirmed) {
        uploadFileKeServer(bookingId, file);
    }
}

// Fungsi untuk upload file ke server
function uploadFileKeServer(bookingId, file) {
    console.log('Mengirim file ke server:', file.name);
    
    // Tampilkan loading dengan SweetAlert
    Swal.fire({
        title: 'Mengupload...',
        html: 'Mohon tunggu sementara file diupload',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    // Buat FormData
    const formData = new FormData();
    formData.append('booking_id', bookingId);
    formData.append('upload_bukti_pembayaran', '1');
    formData.append('bukti_pembayaran', file);
    
    // Debug log
    console.log('FormData contents:');
    for (let pair of formData.entries()) {
        console.log(pair[0] + ': ' + (pair[1] instanceof File ? pair[1].name : pair[1]));
    }
    
    // Upload dengan XMLHttpRequest
    const xhr = new XMLHttpRequest();
    
    xhr.open('POST', '../logic/user/upload_bukti_pembayaran.php', true);
    
    xhr.onload = function() {
        console.log('XHR status:', xhr.status);
        console.log('XHR response:', xhr.responseText);
        
        try {
            const response = JSON.parse(xhr.responseText);
            
            if (response.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: 'Bukti pembayaran berhasil diupload.',
                    confirmButtonColor: '#3085d6'
                }).then(() => {
                    location.reload();
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: response.message || 'Gagal mengupload bukti pembayaran',
                    confirmButtonColor: '#3085d6'
                });
            }
        } catch (e) {
            console.error('Error parsing response:', e);
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Terjadi kesalahan saat memproses respons server.',
                confirmButtonColor: '#3085d6'
            });
        }
    };
    
    xhr.onerror = function() {
        console.error('XHR error');
        Swal.fire({
            icon: 'error',
            title: 'Koneksi Error!',
            text: 'Gagal menghubungi server. Silakan coba lagi.',
            confirmButtonColor: '#3085d6'
        });
    };
    
    // Track progress
    xhr.upload.onprogress = function(e) {
        if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100);
            Swal.update({
                title: 'Mengupload...',
                html: `Mengupload file... ${percent}%
                      <div class="progress" style="height: 20px; margin-top: 10px;">
                        <div class="progress-bar" style="width: ${percent}%; height: 20px;">
                          ${percent}%
                        </div>
                      </div>`
            });
            console.log('Upload progress:', percent + '%');
        }
    };
    
    // Kirim request
    console.log('Memulai request XHR');
    xhr.send(formData);
    console.log('Request XHR terkirim');
}

// Pasang event listener saat DOM sudah siap
document.addEventListener('DOMContentLoaded', function() {
    // Hanya pasang event listener sekali
    attachUploadListeners();
});








    // Fungsi untuk menangani klik pada tombol reupload bukti sewa
    function handleReuploadBuktiSewa() {
        console.log('Memasang listener pada tombol bukti sewa');
        
        // Cari semua tombol upload bukti sewa
        const buttons = document.querySelectorAll('.upload-bukti-sewa-btn');
        console.log('Jumlah tombol upload bukti sewa ditemukan:', buttons.length);
        
        // Pasang event listener
        buttons.forEach(button => {
            // Hapus event listener lama untuk mencegah duplikasi
            button.removeEventListener('click', handleReuploadBuktiSewaClick);
            
            // Pasang event listener baru
            button.addEventListener('click', handleReuploadBuktiSewaClick);
        });
    }

    // Handler untuk tombol reupload bukti sewa
    async function handleReuploadBuktiSewaClick(e) {
        e.preventDefault();
        console.log('Tombol reupload bukti sewa diklik!');
        
        const sewaId = this.getAttribute('data-id');
        console.log('Sewa ID:', sewaId);
        
        // Load SweetAlert jika diperlukan (menggunakan fungsi yang sudah ada)
        await loadSweetAlert();
        
        // Buat element input file sementara
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.jpg,.jpeg,.png,.pdf';
        
        // Event listener untuk fileInput
        fileInput.addEventListener('change', function() {
            if (!fileInput.files.length) {
                console.log('Tidak ada file yang dipilih');
                return;
            }
            
            const file = fileInput.files[0];
            console.log('File dipilih:', file.name, file.type, file.size);
            
            // Proses file yang dipilih
            validateAndUploadBuktiSewa(sewaId, file);
        });
        
        // Trigger klik untuk membuka dialog file
        fileInput.click();
    }

    // Validasi dan upload bukti sewa
    async function validateAndUploadBuktiSewa(sewaId, file) {
        // Validasi file
        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
        
        if (file.size > maxSize) {
            Swal.fire({
                icon: 'error',
                title: 'File terlalu besar',
                text: 'Ukuran file maksimal 5MB',
                confirmButtonColor: '#3085d6'
            });
            return;
        }
        
        if (!allowedTypes.includes(file.type)) {
            Swal.fire({
                icon: 'error',
                title: 'Tipe file tidak diizinkan',
                text: 'Hanya file JPG, JPEG, PNG, atau PDF yang diizinkan',
                confirmButtonColor: '#3085d6'
            });
            return;
        }
        
        // Preview file
        let previewHtml = '';
        if (file.type.startsWith('image/')) {
            previewHtml = `
                <div class="mt-3" style="max-width: 100%; text-align: center;">
                    <img id="file-preview" src="${URL.createObjectURL(file)}" 
                        style="max-width: 100%; max-height: 200px; object-fit: contain;">
                </div>
            `;
        } else {
            previewHtml = `
                <div class="mt-3" style="text-align: center;">
                    <i class="fa fa-file-pdf" style="font-size: 48px; color: #dc3545;"></i>
                    <p>${file.name}</p>
                </div>
            `;
        }
        
        // Konfirmasi upload dengan SweetAlert
        const result = await Swal.fire({
            title: 'Upload Bukti Pembayaran Sewa',
            html: `
                <p>File yang dipilih: <strong>${file.name}</strong></p>
                <p>Ukuran file: <strong>${(file.size / 1024 / 1024).toFixed(2)} MB</strong></p>
                ${previewHtml}
            `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Upload',
            cancelButtonText: 'Batal',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33'
        });
        
        if (result.isConfirmed) {
            uploadBuktiSewaKeServer(sewaId, file);
        }
    }

    // Fungsi untuk upload bukti sewa ke server dengan fetch API
    async function uploadBuktiSewaKeServer(sewaId, file) {
        console.log('Mengirim file bukti sewa ke server:', file.name);
        
        // Tampilkan loading dengan SweetAlert
        Swal.fire({
            title: 'Mengupload...',
            html: 'Mohon tunggu sementara file diupload',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
        
        try {
            // Buat FormData
            const formData = new FormData();
            formData.append('id', sewaId);
            formData.append('bukti_pembayaran', file);
            
            // Upload dengan fetch API
            const response = await fetch('../logic/user/upload_bukti_sewa.php', {
                method: 'POST',
                body: formData
            });
            
            // Cek status HTTP
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            // Parse JSON response
            const data = await response.json();
            
            if (data.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: 'Bukti pembayaran sewa berhasil diupload.',
                    confirmButtonColor: '#3085d6'
                }).then(() => {
                    location.reload();
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: data.message || 'Gagal mengupload bukti pembayaran sewa',
                    confirmButtonColor: '#3085d6'
                });
            }
        } catch (error) {
            console.error('Error uploading bukti sewa:', error);
            
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Terjadi kesalahan saat mengupload file. Silakan coba lagi.',
                confirmButtonColor: '#3085d6'
            });
        }
    }

    // Pasang event listener saat DOM sudah siap
    document.addEventListener('DOMContentLoaded', function() {
        handleReuploadBuktiSewa();
    });

</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const kodeButtons = document.querySelectorAll('.lihat-kode-btn');
    kodeButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            const kode = this.getAttribute('data-kode');
            Swal.fire({
                title: 'Kode Pembayaran',
                html: `
                    <div style="background:#f1f1f1; border-left: 5px solid #007bff; padding:15px; border-radius:8px; font-family:sans-serif;">
                        <div style="font-size:14px; color:#555;">Kode Pembayaran:</div>
                        <div style="font-size:20px; font-weight:bold; color:#007bff; margin-top:5px; border:1px dashed #007bff; padding:8px 12px; background:#ffffff; border-radius:6px; display:inline-block;">
                            ${kode}
                        </div>
                        <div style="margin-top:15px; font-size:14px; color:#333;">
                            Silakan tunjukkan kode ini kepada admin saat melakukan pembayaran di tempat.
                        </div>
                    </div>
                `,

                icon: 'info',
                confirmButtonText: 'Oke',
            });
        });
    });
});
</script>

<!-- CSS untuk progress bar (tambahkan ke head jika perlu) -->
<style>
.progress {
    display: flex;
    height: 20px;
    overflow: hidden;
    background-color: #e9ecef;
    border-radius: 0.25rem;
}
.progress-bar {
    display: flex;
    flex-direction: column;
    justify-content: center;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    background-color: #3085d6;
    transition: width 0.6s ease;
}
</style>
</body>
</html>
