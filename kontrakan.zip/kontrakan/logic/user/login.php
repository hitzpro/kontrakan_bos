<?php
session_start();
require_once "../../config/db.php"; // Koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);

    if (empty($email) || empty($password)) {
        $_SESSION['message'] = "Email dan kata sandi harus diisi";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Error";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
    

    // Ambil data pengguna berdasarkan email dan peran
    $query = "SELECT * FROM pengguna WHERE email = '$email' AND peran = 'pengguna'";
    $result = mysqli_query($conn, $query);

    if (!$result || mysqli_num_rows($result) != 1) {
        $_SESSION['message'] = "Email tidak ditemukan atau bukan akun pengguna.";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Login Gagal";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }

    $user = mysqli_fetch_assoc($result);

    // Bandingkan password
    if ($user['kata_sandi'] === $password) {
        // Set session khusus untuk user biasa
        $_SESSION['user_user_id'] = $user['id'];
        $_SESSION['user_user_email'] = $user['email'];
        $_SESSION['user_user_nama_pengguna'] = $user['nama_pengguna'];
        $_SESSION['user_user_peran'] = $user['peran'];

        // Update status dan terakhir masuk
        $update = "UPDATE pengguna SET status = 'aktif', terakhir_masuk = NOW() WHERE id = " . $user['id'];
        mysqli_query($conn, $update);

        $_SESSION['message'] = "Login berhasil, selamat datang " . $user['nama_pengguna'] . "!";
        $_SESSION['status'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['redirect'] = true;

        header("Location: ../../public/login.php");
        exit();
    } else {
        $_SESSION['message'] = "Kata sandi salah.";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Login Gagal";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
} else {
    header("Location: ../../public/login.php");
    exit();
}
