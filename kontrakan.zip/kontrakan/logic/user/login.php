<?php
session_start();
require_once "../../config/db.php";

// Log untuk debugging
error_log("🔍 LOGIN DEBUG: POST data received: " . print_r($_POST, true));
error_log("🔍 LOGIN DEBUG: Current session before login: " . print_r($_SESSION, true));

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    
    error_log("🔍 LOGIN DEBUG: Attempting login for email: " . $email);
    
    // Validasi input kosong
    if (empty($email) || empty($password)) {
        error_log("❌ LOGIN DEBUG: Empty email or password");
        $_SESSION['message'] = "Email dan kata sandi harus diisi.";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Login Gagal";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
    
    // Cek user dengan email dan peran 'pengguna'
    $query = "SELECT * FROM pengguna WHERE email = '$email' AND peran = 'pengguna'";
    error_log("🔍 LOGIN DEBUG: Query: " . $query);
    $result = mysqli_query($conn, $query);
    
    if (!$result || mysqli_num_rows($result) != 1) {
        error_log("❌ LOGIN DEBUG: User not found or not a regular user");
        $_SESSION['message'] = "Email tidak ditemukan atau bukan akun pengguna.";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Login Gagal";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
    
    $user = mysqli_fetch_assoc($result);
    error_log("🔍 LOGIN DEBUG: User found: " . print_r($user, true));
    
    // Cek password (tidak menggunakan hash untuk sistem ini)
    if ($user['kata_sandi'] === $password) {
        error_log("✅ LOGIN DEBUG: Password correct, setting up session");
        
        // Set session login
        $_SESSION['user_user_id'] = $user['id'];
        $_SESSION['user_user_email'] = $user['email'];
        $_SESSION['user_user_nama_pengguna'] = $user['nama_pengguna'];
        $_SESSION['user_user_peran'] = $user['peran'];
        
        error_log("🔍 LOGIN DEBUG: Session after login setup: " . print_r($_SESSION, true));
        
        // Update status aktif
        $update = "UPDATE pengguna SET status = 'aktif', terakhir_masuk = NOW() WHERE id = " . $user['id'];
        mysqli_query($conn, $update);
        
        // Set notifikasi login sukses
        $_SESSION['message'] = "Login berhasil, selamat datang " . $user['nama_pengguna'] . "!";
        $_SESSION['status'] = "success";
        $_SESSION['title'] = "Berhasil";
        $_SESSION['redirect'] = true;
        
        // Cek apakah ada redirect_after_login_id
        if (!empty($_SESSION['redirect_after_login_id'])) {
            $kontrakanId = $_SESSION['redirect_after_login_id'];
            $_SESSION['redirect_target'] = "detail-kontrakan.php?id=" . $kontrakanId;
            error_log("✅ LOGIN DEBUG: Setting redirect_target to: detail-kontrakan.php?id=" . $kontrakanId);
            // Hapus setelah digunakan
            unset($_SESSION['redirect_after_login_id']);
        } else {
            $_SESSION['redirect_target'] = "../index.php";
            error_log("🔍 LOGIN DEBUG: No redirect ID, setting default redirect to: ../index.php");
        }
        
        error_log("🔍 LOGIN DEBUG: Final session before redirect: " . print_r($_SESSION, true));
        header("Location: ../../public/login.php");
        exit();
        
    } else {
        error_log("❌ LOGIN DEBUG: Password incorrect");
        $_SESSION['message'] = "Kata sandi salah.";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Login Gagal";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
} else {
    error_log("🔍 LOGIN DEBUG: Non-POST request, redirecting to login page");
    header("Location: ../../public/login.php");
    exit();
}
?>