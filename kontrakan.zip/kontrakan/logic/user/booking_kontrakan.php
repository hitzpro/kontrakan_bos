<?php
session_start();
header('Content-Type: application/json');
require_once '../../config/db.php';

$response = [
    'success' => false,
    'message' => '',
    'redirect' => null,
    'payment_code' => null,
    'deadline' => null
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->begin_transaction();

    try {
        // Sanitize and validate inputs
        $id_penyewa = filter_input(INPUT_POST, 'id_penyewa', FILTER_VALIDATE_INT);
        $id_kontrakan = filter_input(INPUT_POST, 'kontrakan_id', FILTER_VALIDATE_INT);
        $tanggal_mulai = filter_input(INPUT_POST, 'tanggal_mulai', FILTER_SANITIZE_STRING);
        $durasi_sewa = filter_input(INPUT_POST, 'durasi_sewa', FILTER_VALIDATE_INT);
        $metode_pembayaran = filter_input(INPUT_POST, 'metode_pembayaran', FILTER_SANITIZE_STRING);
        $total_bayar = filter_input(INPUT_POST, 'total_bayar', FILTER_VALIDATE_FLOAT);
        $total_harga = filter_input(INPUT_POST, 'total_harga', FILTER_VALIDATE_FLOAT);
        $tipe_kontrakan = filter_input(INPUT_POST, 'tipe_kontrakan', FILTER_SANITIZE_STRING);

        // Validate required fields
        if (!$id_penyewa || !$id_kontrakan || !$tanggal_mulai || !$durasi_sewa || !$metode_pembayaran || !$total_bayar) {
            throw new Exception('Semua field harus diisi dengan benar.');
        }

        // Check if kontrakan is already booked
        $check_sql = "SELECT status FROM data_kontrakan WHERE id = ? FOR UPDATE";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $id_kontrakan);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $kontrakan = $check_result->fetch_assoc();

        if ($kontrakan['status'] === 'tidak tersedia') {
            throw new Exception('Kontrakan sudah dibooking.');
        }

        // Calculate end date based on rental type
        if ($tipe_kontrakan === 'bulanan') {
            $tanggal_selesai = date('Y-m-d', strtotime("+{$durasi_sewa} months", strtotime($tanggal_mulai)));
        } else { // tahunan
            $tanggal_selesai = date('Y-m-d', strtotime("+{$durasi_sewa} years", strtotime($tanggal_mulai)));
        }

        // Initialize variables
        $kode_pembayaran = null;
        $payment_upload_deadline = null;
        $status_booking = null;
        
        // Set payment deadline (12 hours from now as requested)
        $deadline_timestamp = time() + (12 * 60 * 60); // 12 hours

        if ($metode_pembayaran === 'tunai') {
            $kode_pembayaran = substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 2)), 0, 6);
            $status_booking = 'belum bayar';
            $payment_upload_deadline = $deadline_timestamp;
            
        } else if ($metode_pembayaran === 'transfer') {
            if ($total_bayar < $total_harga) {
                $status_booking = 'belum lunas';
                $payment_upload_deadline = $deadline_timestamp; // 12 jam untuk pelunasan
            } else {
                $status_booking = 'menunggu';
                // PERBAIKAN: 2 jam sebelum tanggal mulai sewa
                $tanggal_mulai_timestamp = strtotime($tanggal_mulai . ' 00:00:00');
                $payment_upload_deadline = $tanggal_mulai_timestamp - (2 * 60 * 60); // 2 jam sebelum mulai
            }
        }

        // Handle file upload for transfer method
        $bukti_pembayaran = null;
        if ($metode_pembayaran === 'transfer' && isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] == 0) {
            $upload_dir = "../../user/bukti_pembayaran/";
            
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            // Get username for the file name
            $username_query = "SELECT nama_pengguna FROM pengguna WHERE id = ?";
            $username_stmt = $conn->prepare($username_query);
            $username_stmt->bind_param("i", $id_penyewa);
            $username_stmt->execute();
            $username_result = $username_stmt->get_result();
            $user_data = $username_result->fetch_assoc();
            $username = $user_data['nama_pengguna'] ?? 'user';
            
            // Validate file upload
            $imageFileType = strtolower(pathinfo($_FILES['bukti_pembayaran']['name'], PATHINFO_EXTENSION));
            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
            $max_file_size = 5 * 1024 * 1024; // 5MB
            
            $file_name = 'bukti_booking_'. $username . '_' . $id_kontrakan . '_' . time() . '.' . $imageFileType;
            $target_file = $upload_dir . $file_name;

            if (!in_array($imageFileType, $allowed_types)) {
                throw new Exception('Hanya file gambar yang diperbolehkan (JPG, JPEG, PNG, GIF).');
            }

            if ($_FILES['bukti_pembayaran']['size'] > $max_file_size) {
                throw new Exception('Ukuran file terlalu besar. Maksimal 5MB.');
            }

            if (!move_uploaded_file($_FILES['bukti_pembayaran']['tmp_name'], $target_file)) {
                throw new Exception('Gagal mengunggah bukti pembayaran.');
            }

            $bukti_pembayaran = $file_name;
        }

        // Check for existing booking to prevent duplicates
        $duplicate_check_sql = "SELECT id FROM booking WHERE id_penyewa = ? AND id_kontrakan = ? AND tanggal_mulai = ?";
        $duplicate_stmt = $conn->prepare($duplicate_check_sql);
        $duplicate_stmt->bind_param("iis", $id_penyewa, $id_kontrakan, $tanggal_mulai);
        $duplicate_stmt->execute();
        $duplicate_result = $duplicate_stmt->get_result();

        if ($duplicate_result->num_rows > 0) {
            throw new Exception('Booking sudah pernah dilakukan untuk kontrakan ini pada tanggal yang sama.');
        }

        // Prepare SQL statement for booking
        $sql = "INSERT INTO booking (
            id_penyewa, 
            id_kontrakan, 
            tanggal_mulai, 
            tanggal_selesai, 
            metode_pembayaran, 
            bukti_pembayaran, 
            total_bayar, 
            status_booking,
            kode_pembayaran,
            payment_upload_deadline
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "iissssdssi", 
            $id_penyewa, 
            $id_kontrakan, 
            $tanggal_mulai, 
            $tanggal_selesai, 
            $metode_pembayaran, 
            $bukti_pembayaran, 
            $total_bayar,
            $status_booking,
            $kode_pembayaran,
            $payment_upload_deadline
        );

        if (!$stmt->execute()) {
            throw new Exception('Gagal melakukan booking. Silakan coba lagi.');
        }

        // Update kontrakan status
        $update_kontrakan_sql = "UPDATE data_kontrakan SET status = 'tidak tersedia' WHERE id = ?";
        $update_stmt = $conn->prepare($update_kontrakan_sql);
        $update_stmt->bind_param("i", $id_kontrakan);
        
        if (!$update_stmt->execute()) {
            throw new Exception('Gagal memperbarui status kontrakan.');
        }

        $conn->commit();

        $response['success'] = true;
        $response['message'] = 'Booking berhasil!';
        
        // Response messages
        if ($metode_pembayaran === 'tunai') {
            $response['payment_code'] = $kode_pembayaran;
            $response['deadline'] = date('Y-m-d H:i:s', $deadline_timestamp);
            $response['message'] = 'Booking berhasil! Silakan lakukan pembayaran dengan kode: ' . $kode_pembayaran . ' dalam 12 jam.';
        } else if ($metode_pembayaran === 'transfer') {
            if ($status_booking === 'belum lunas') {
                $response['deadline'] = date('Y-m-d H:i:s', $deadline_timestamp);
                $response['message'] = 'Booking berhasil! Silakan lunasi pembayaran Anda dalam 12 jam.';
            } else {
                $response['deadline'] = date('Y-m-d H:i:s', $payment_upload_deadline);
                $response['message'] = 'Booking berhasil! Pembayaran sedang diproses, akan dikonfirmasi dalam 7 hari.';
            }
        }
        
        $response['redirect'] = "../public/index.php?id={$id_penyewa}";

    } catch (Exception $e) {
        $conn->rollback();
        $response['message'] = $e->getMessage();
        error_log('Booking Error: ' . $e->getMessage());
    } finally {
        // Close statements
        if (isset($check_stmt)) $check_stmt->close();
        if (isset($duplicate_stmt)) $duplicate_stmt->close();
        if (isset($stmt)) $stmt->close();
        if (isset($update_stmt)) $update_stmt->close();
        if (isset($username_stmt)) $username_stmt->close();
        $conn->close();
    }

    echo json_encode($response);
    exit();
} else {
    $response['message'] = 'Akses tidak sah.';
    echo json_encode($response);
    exit();
}
?>