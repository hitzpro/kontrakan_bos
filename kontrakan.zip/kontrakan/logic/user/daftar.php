<?php
session_start();
require_once "../../config/db.php"; // Connection to database

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form inputs
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $nama_pengguna = mysqli_real_escape_string($conn, $_POST["nama_pengguna"]);
    $no_telepon = mysqli_real_escape_string($conn, $_POST["no_telepon"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    $confirm_password = mysqli_real_escape_string($conn, $_POST["confirm_password"]);
    
    // Validate input
    if (empty($email) || empty($nama_pengguna) || empty($no_telepon) || empty($password)) {
        $_SESSION['message'] = "Semua field harus diisi";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Error";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['message'] = "Format email tidak valid";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Format Salah";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
    
    // Check if password and confirm password match
    if ($password !== $confirm_password) {
        $_SESSION['message'] = "Konfirmasi kata sandi tidak cocok";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Kata Sandi Tidak Cocok";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
    
    // Check if email already exists
    $check_query = "SELECT * FROM pengguna WHERE email = '$email'";
    $check_result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($check_result) > 0) {
        $_SESSION['message'] = "Email sudah terdaftar, silakan gunakan email lain";
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Email Sudah Ada";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
    
    // Insert new user
    $insert_query = "INSERT INTO pengguna (email, nama_pengguna, kata_sandi, no_telepon, peran, status) 
                     VALUES ('$email', '$nama_pengguna', '$password', '$no_telepon', 'pengguna', 'aktif')";
    
    if (mysqli_query($conn, $insert_query)) {
        $_SESSION['message'] = "Pendaftaran berhasil! Silakan login dengan akun baru Anda";
        $_SESSION['status'] = "success";
        $_SESSION['title'] = "Berhasil Mendaftar";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    } else {
        $_SESSION['message'] = "Terjadi kesalahan saat mendaftar: " . mysqli_error($conn);
        $_SESSION['status'] = "error";
        $_SESSION['title'] = "Error Database";
        $_SESSION['redirect'] = false;
        header("Location: ../../public/login.php");
        exit();
    }
} else {
    // If not POST request, redirect to login page
    header("Location: ../../public/login.php");
    exit();
}
?>