<?php
session_start();
require '../../config/db.php'; // sesuaikan path

$id = $_GET['id'];

$query = "UPDATE perpanjangan_sewa SET status = 'dibatalkan' WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['toast'] = [
        'type' => 'success',
        'message' => 'Booking berhasil dibatalkan.'
    ];
} else {
    $_SESSION['toast'] = [
        'type' => 'error',
        'message' => 'Gagal membatalkan booking.'
    ];
}

header("Location: ../../user/dashboard.php"); // sesuaikan redirect
exit;
