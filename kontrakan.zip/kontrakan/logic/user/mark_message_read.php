<?php
session_start();
require_once '../../config/db.php'; // Adjust path as needed

// Check if user is logged in
if (!isset($_SESSION['user_user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit;
}

$user_id = $_SESSION['user_user_id'];
$message_id = $_POST['message_id'] ?? null;

if (!$message_id) {
    echo json_encode(['status' => 'error', 'message' => 'Message ID is required']);
    exit;
}

try {
    // Mark message as read, but only if it belongs to this user
    $sql = "UPDATE user_notifications SET is_read = 1 WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $message_id, $user_id);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Message marked as read']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Message not found or doesn\'t belong to this user']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>