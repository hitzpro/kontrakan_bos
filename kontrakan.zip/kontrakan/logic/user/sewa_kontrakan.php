<?php
session_start();
require '../../config/db.php';

header('Content-Type: application/json');

try {
    $conn->begin_transaction(); // Start transaction for data consistency
    
    $id_penyewa = $_POST['id_penyewa'];
    $id_kontrakan = $_POST['kontrakan_id'];
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_selesai = $_POST['tanggal_selesai'];
    $durasi_sewa = $_POST['durasi_sewa'];
    $harga_sewa = $_POST['total_harga_value'];
    $total_bayar = $_POST['total_bayar'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $status_pembayaran = 'belum bayar';
    $status_sewa = 'menunggu konfirmasi';
    $bukti_pembayaran = null;
    $kode_pembayaran = null;
    
    // Generate kode pembayaran for cash payment (6 digits)
    if ($metode_pembayaran === 'tunai') {
        $kode_pembayaran = sprintf("%06d", mt_rand(1, 999999));
    }

    // Upload file jika metode transfer
    if ($metode_pembayaran === 'transfer' && isset($_FILES['bukti_pembayaran'])) {
        $target_dir = "../../user/bukti_pembayaran/";

        // Ambil informasi user dari session
        $username = $_SESSION['user_user_nama_pengguna'];
        $user_id = $_SESSION['user_user_id'];

        // Ambil ekstensi file
        $file_ext = strtolower(pathinfo($_FILES["bukti_pembayaran"]["name"], PATHINFO_EXTENSION));

        // Buat nama file sesuai format
        $new_file_name = 'bukti_sewa_' . $username . '_' . $id_kontrakan . '.' . $file_ext;
        $target_file = $target_dir . $new_file_name;

        // Jika file sudah ada, hapus dulu
        if (file_exists($target_file)) {
            unlink($target_file);
        }

        // Upload file
        if (move_uploaded_file($_FILES["bukti_pembayaran"]["tmp_name"], $target_file)) {
            $bukti_pembayaran = $new_file_name;
        }
    }


    // 1. Insert data into penyewaan table
    $stmt = $conn->prepare("INSERT INTO penyewaan (id_penyewa, id_kontrakan, tanggal_mulai, tanggal_selesai, durasi_sewa, harga_sewa, total_bayar, metode_pembayaran, bukti_pembayaran, status_pembayaran, status_sewa, kode_pembayaran) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("iissiddsssss", $id_penyewa, $id_kontrakan, $tanggal_mulai, $tanggal_selesai, $durasi_sewa, $harga_sewa, $total_bayar, $metode_pembayaran, $bukti_pembayaran, $status_pembayaran, $status_sewa, $kode_pembayaran);
    $stmt->execute();
    
    // 2. Update data_kontrakan table to set status to "tidak tersedia"
    $update_stmt = $conn->prepare("UPDATE data_kontrakan SET status = 'tidak tersedia' WHERE id = ?");
    $update_stmt->bind_param("i", $id_kontrakan);
    $update_stmt->execute();
    
    // If everything is successful, commit the transaction
    $conn->commit();

    // Customize success message based on payment method
    $successMessage = "Berhasil menyewa kontrakan!";
    if ($metode_pembayaran === 'tunai') {
        $successMessage = "Berhasil menyewa kontrakan! Silahkan tunjukkan kode pembayaran $kode_pembayaran kepada admin saat melakukan pembayaran tunai. Kode pembayaran juga dapat dilihat di dashboard Anda.";
    }

    echo json_encode([
        "success" => true,
        "message" => $successMessage
    ]);
} catch (Exception $e) {
    // If there's an error, roll back the transaction
    $conn->rollback();
    
    echo json_encode([
        "success" => false,
        "message" => "Gagal menyewa kontrakan: " . $e->getMessage()
    ]);
}
?>