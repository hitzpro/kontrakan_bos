<?php
session_start();
include '../../config/db.php';

// Ambil data dari form
$jenis = $_POST['jenis']; // jenis = "booking"
$id_transaksi = $_POST['id_transaksi']; // id_booking
$metode = $_POST['metode_pembayaran'];
$bukti_pembayaran = null;

// Ambil data booking berdasarkan ID
$queryBooking = mysqli_query($conn, "SELECT * FROM booking WHERE id = '$id_transaksi'");
$dataBooking = mysqli_fetch_assoc($queryBooking);

if (!$dataBooking) {
    $_SESSION['toast_error'] = "Data booking tidak ditemukan.";
    header("Location: ../../user/dashboard.php");
    exit();
}

$id_penyewa = $dataBooking['id_user'];
$id_kontrakan = $dataBooking['id_kontrakan'];
$tanggal_mulai = $dataBooking['tanggal_mulai'];
$tanggal_selesai = $dataBooking['tanggal_selesai'];

// Hitung durasi sewa (dalam bulan)
$start = new DateTime($tanggal_mulai);
$end = new DateTime($tanggal_selesai);
$interval = $start->diff($end);
$durasi_sewa = ($interval->y * 12) + $interval->m + ($interval->d > 0 ? 1 : 0);

// Ambil harga dari data_kontrakan
$queryHarga = mysqli_query($conn, "SELECT harga FROM data_kontrakan WHERE id = '$id_kontrakan'");
$dataKontrakan = mysqli_fetch_assoc($queryHarga);

if (!$dataKontrakan) {
    $_SESSION['toast_error'] = "Data kontrakan tidak ditemukan.";
    header("Location: ../../user/dashboard.php");
    exit();
}

$harga_sewa = $dataKontrakan['harga'];
$total_bayar = $harga_sewa * $durasi_sewa;

// Handle upload jika transfer
if ($metode == 'transfer') {
    if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] == 0) {
        $username = $_SESSION['username']; // pastikan session username tersedia
        $target_dir = "../../user/bukti_Pembayaran_$username/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $original_filename = basename($_FILES["bukti_pembayaran"]["name"]);
        $unique_filename = time() . "_" . $original_filename;
        $target_file = $target_dir . $unique_filename;
        

        if (move_uploaded_file($_FILES["bukti_pembayaran"]["tmp_name"], $target_file)) {
            $bukti_pembayaran = $unique_filename;
        } else {
            $_SESSION['toast_error'] = "Upload bukti pembayaran gagal.";
            header("Location: ../../user/dashboard.php");
            exit();
        }
    } else {
        $_SESSION['toast_error'] = "Bukti pembayaran wajib diunggah untuk metode transfer.";
        header("Location: ../../user/dashboard.php");
        exit();
    }
}

// Insert ke tabel penyewaan
$insert = mysqli_query($conn, "INSERT INTO penyewaan (
    id_booking,
    id_penyewa,
    id_kontrakan,
    tanggal_mulai,
    tanggal_selesai,
    durasi_sewa,
    harga_sewa,
    total_bayar,
    metode_pembayaran,
    bukti_pembayaran,
    status_pembayaran,
    status_sewa
) VALUES (
    '$id_transaksi',
    '$id_penyewa',
    '$id_kontrakan',
    '$tanggal_mulai',
    '$tanggal_selesai',
    '$durasi_sewa',
    '$harga_sewa',
    '$total_bayar',
    '$metode',
    " . ($bukti_pembayaran ? "'$unique_filename'" : "NULL") . ",
    'belum',
    'menunggu_konfirmasi'
)");

if ($insert) {
    $_SESSION['toast_success'] = "Pembayaran berhasil dikirim!";
} else {
    $_SESSION['toast_error'] = "Gagal menyimpan pembayaran: " . mysqli_error($conn);
}

header("Location: ../../user/dashboard.php");
exit();
?>
