<?php
session_start();
require '../../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];

    $query = mysqli_query($conn, "UPDATE penyewaan SET status_pembayaran = 'lunas' WHERE id = '$id'");

    if ($query) {
        $_SESSION['toast'] = [
            'type' => 'success',
            'message' => 'Pembayaran tunai berhasil dikonfirmasi.'
        ];
        echo json_encode(['success' => true, 'message' => 'Konfirmasi berhasil']);
    } else {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Gagal mengkonfirmasi pembayaran.'
        ];
        echo json_encode(['success' => false, 'message' => 'Gagal update data']);
    }
} else {
    $_SESSION['toast'] = [
        'type' => 'error',
        'message' => 'Permintaan tidak valid.'
    ];
    echo json_encode(['success' => false, 'message' => 'Request tidak valid']);
}
?>
