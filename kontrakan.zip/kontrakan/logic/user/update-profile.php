<?php
session_start();
require_once "../../config/db.php";

// Check if user is logged in
if (!isset($_SESSION['user_user_id'])) {
    $_SESSION['toast'] = [
        'type' => 'error',
        'message' => 'Silakan login terlebih dahulu.'
    ];
    header("Location: ../../public/login.php");
    exit();
}

// Get user data
$user_id = $_SESSION['user_user_id'];
$query = "SELECT * FROM pengguna WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if (!$user) {
    $_SESSION['toast'] = [
        'type' => 'error',
        'message' => 'Data pengguna tidak ditemukan.'
    ];
    header("Location: ../../user/dashboard.php");
    exit();
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data with improved sanitization
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $nama_pengguna = trim($_POST['nama_pengguna'] ?? '');
    $no_telepon = trim($_POST['no_telepon'] ?? '');
    $kata_sandi_sekarang = $_POST['kata_sandi_sekarang'] ?? '';
    $kata_sandi_baru = $_POST['kata_sandi_baru'] ?? '';
    $konfirmasi_kata_sandi = $_POST['konfirmasi_kata_sandi'] ?? '';
    
    // Basic validation
    if (empty($nama_pengguna)) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Nama pengguna tidak boleh kosong.'
        ];
        header("Location: ../../user/dashboard.php");
        exit();
    }
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Format email tidak valid.'
        ];
        header("Location: ../../user/dashboard.php");
        exit();
    }
    
    // Check if email already exists (except for current user)
    $check_email_query = "SELECT id FROM pengguna WHERE email = ? AND id != ?";
    $stmt = mysqli_prepare($conn, $check_email_query);
    mysqli_stmt_bind_param($stmt, "si", $email, $user_id);
    mysqli_stmt_execute($stmt);
    $email_result = mysqli_stmt_get_result($stmt);
    
    if (mysqli_num_rows($email_result) > 0) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Email sudah digunakan oleh pengguna lain.'
        ];
        header("Location: ../../user/dashboard.php");
        exit();
    }
    
    // Handle profile photo upload
    $foto_path = $user['foto']; // Default to current photo path
    
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = $_FILES['foto']['type'];
        
        if (!in_array($file_type, $allowed_types)) {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Format file tidak didukung. Silakan unggah file JPG, PNG, GIF, atau WEBP.'
            ];
            header("Location: ../../user/dashboard.php");
            exit();
        }
        
        // Check file size (max 2MB)
        if ($_FILES['foto']['size'] > 2097152) {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Ukuran file terlalu besar. Maksimal 2MB.'
            ];
            header("Location: ../../user/dashboard.php");
            exit();
        }
        
        // Create upload directory if it doesn't exist
        $upload_dir = '../../user/profiles/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Generate unique filename
        $file_ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $new_filename = 'profile_' . $user_id . '_' . time() . '.' . $file_ext;
        $upload_path = $upload_dir . $new_filename;
        
        // Move uploaded file
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $upload_path)) {
            // Delete old file if exists and not the default
            $old_file_path = $upload_dir . $user['foto']; // FIXED: Define the variable
            if (!empty($user['foto']) && file_exists($old_file_path) && basename($user['foto']) !== 'default.png') {
                unlink($old_file_path);
            }
            
            $foto_path = $new_filename; // only filename for database
        } else {
            $_SESSION['toast'] = [
                'type' => 'error',
                'message' => 'Gagal mengunggah file. Silakan coba lagi.'
            ];
            header("Location: ../../user/dashboard.php");
            exit();
        }
    }
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Password change handling
        $password_updated = false;
        $new_password = $user['kata_sandi']; // Default to current password
        
        if (!empty($kata_sandi_sekarang) && !empty($kata_sandi_baru) && !empty($konfirmasi_kata_sandi)) {
            // Verify current password (direct comparison without hash)
            if ($kata_sandi_sekarang !== $user['kata_sandi']) {
                throw new Exception('Kata sandi sekarang tidak sesuai.');
            }
            
            // Validate new password
            if (strlen($kata_sandi_baru) < 8) {
                throw new Exception('Kata sandi baru minimal 8 karakter.');
            }
            
            // Check if new password and confirmation match
            if ($kata_sandi_baru !== $konfirmasi_kata_sandi) {
                throw new Exception('Kata sandi baru dan konfirmasi tidak cocok.');
            }
            
            // Store password without hashing (as requested)
            $new_password = $kata_sandi_baru;
            $password_updated = true;
        }
        
        // Update user data
        if ($password_updated) {
            $update_query = "UPDATE pengguna SET 
                            email = ?, 
                            nama_pengguna = ?, 
                            no_telepon = ?, 
                            foto = ?, 
                            kata_sandi = ? 
                            WHERE id = ?";
            $stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($stmt, "sssssi", $email, $nama_pengguna, $no_telepon, $foto_path, $new_password, $user_id);
        } else {
            $update_query = "UPDATE pengguna SET 
                            email = ?, 
                            nama_pengguna = ?, 
                            no_telepon = ?, 
                            foto = ? 
                            WHERE id = ?";
            $stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($stmt, "ssssi", $email, $nama_pengguna, $no_telepon, $foto_path, $user_id);
        }
        
        $update_result = mysqli_stmt_execute($stmt);
        
        if (!$update_result) {
            throw new Exception('Gagal memperbarui profil: ' . mysqli_error($conn));
        }
        
        // Check if any rows were actually updated
        if (mysqli_affected_rows($conn) === 0) {
            // This could mean no changes were made, which is still "successful"
            $_SESSION['toast'] = [
                'type' => 'info',
                'message' => 'Tidak ada perubahan pada profil.'
            ];
        } else {
            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'Profil berhasil diperbarui!'
            ];
        }
        
        // Commit transaction
        mysqli_commit($conn);
        
        // Update session data if name changed
        $_SESSION['user_user_nama_pengguna'] = $nama_pengguna;
        $_SESSION['user_user_email'] = $email;
        
        header("Location: ../../user/dashboard.php");
        exit();
        
    } catch (Exception $e) {
        // Rollback transaction
        mysqli_rollback($conn);
        
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => $e->getMessage()
        ];
        
        header("Location: ../../user/dashboard.php");
        exit();
    }
}

// If not a POST request, redirect to dashboard
header("Location: ../../user/dashboard.php");
exit();
?>