<?php
session_start();
require '../../config/db.php';

header('Content-Type: application/json');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $id_penyewaan = filter_input(INPUT_POST, 'id_penyewaan', FILTER_VALIDATE_INT);
    $id_kontrakan = filter_input(INPUT_POST, 'id_kontrakan', FILTER_VALIDATE_INT);
    $tanggal_mulai = filter_input(INPUT_POST, 'tanggal_mulai', FILTER_SANITIZE_STRING);
    $tanggal_selesai = filter_input(INPUT_POST, 'tanggal_selesai', FILTER_SANITIZE_STRING);
    $durasi = filter_input(INPUT_POST, 'durasi', FILTER_VALIDATE_INT);
    $total_bayar = filter_input(INPUT_POST, 'total_bayar', FILTER_VALIDATE_FLOAT);
    $metode = filter_input(INPUT_POST, 'metode_pembayaran', FILTER_SANITIZE_STRING);
    $keterangan = filter_input(INPUT_POST, 'keterangan', FILTER_SANITIZE_STRING) ?? '';
    $id_penyewa = $_SESSION['user_user_id'] ?? 0;
    $username = $_SESSION['user_user_nama_pengguna'] ?? 0;

    // Validate required fields
    if (!$id_penyewaan || !$id_kontrakan || !$tanggal_mulai || !$tanggal_selesai || 
        !$durasi || !$total_bayar || !$metode || !$id_penyewa) {
        $_SESSION['toast'] = ['type' => 'error', 'message' => 'Data tidak lengkap!'];
        echo json_encode(['success' => false, 'message' => 'Data tidak lengkap!']);
        exit;
    }

    // Validate payment method
    if (!in_array($metode, ['tunai', 'transfer'])) {
        $_SESSION['toast'] = ['type' => 'error', 'message' => 'Metode pembayaran tidak valid!'];
        echo json_encode(['success' => false, 'message' => 'Metode pembayaran tidak valid!']);
        exit;
    }

    $bukti_pembayaran = null;

    // Handle file upload for 'transfer' payment method
    if ($metode === 'transfer') {
        if (!isset($_FILES['bukti_pembayaran']) || $_FILES['bukti_pembayaran']['error'] == UPLOAD_ERR_NO_FILE) {
            $_SESSION['toast'] = ['type' => 'error', 'message' => 'Bukti pembayaran wajib diupload!'];
            echo json_encode(['success' => false, 'message' => 'Bukti pembayaran wajib diupload!']);
            exit;
        }

        $upload_dir = '../../user/bukti_pembayaran/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $file_name = $_FILES['bukti_pembayaran']['name'];
        $file_tmp = $_FILES['bukti_pembayaran']['tmp_name'];
        $file_size = $_FILES['bukti_pembayaran']['size'];
        $file_error = $_FILES['bukti_pembayaran']['error'];

        // Check file size (max 5MB)
        if ($file_size > 5 * 1024 * 1024) {
            $_SESSION['toast'] = ['type' => 'error', 'message' => 'Ukuran file terlalu besar. Maks 5MB.'];
            echo json_encode(['success' => false, 'message' => 'Ukuran file terlalu besar. Maks 5MB.']);
            exit;
        }

        // Check file extension
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'pdf'];

        if (!in_array($file_ext, $allowed_ext)) {
            $_SESSION['toast'] = ['type' => 'error', 'message' => 'Tipe file tidak diizinkan. Gunakan JPG, JPEG, PNG, atau PDF.'];
            echo json_encode(['success' => false, 'message' => 'Tipe file tidak diizinkan. Gunakan JPG, JPEG, PNG, atau PDF.']);
            exit;
        }

        // Generate unique filename
        $new_file_name = 'bukti perpanjangan_' . $username . '_' . $id_kontrakan . '.' . $file_ext;
        $file_destination = $upload_dir . $new_file_name;

        // Move uploaded file
        if (!move_uploaded_file($file_tmp, $file_destination)) {
            $_SESSION['toast'] = ['type' => 'error', 'message' => 'Gagal mengupload bukti pembayaran.'];
            echo json_encode(['success' => false, 'message' => 'Gagal mengupload bukti pembayaran.']);
            exit;
        }

        $bukti_pembayaran = $new_file_name;
    }

    // Insert data into database
    $stmt = $conn->prepare("INSERT INTO perpanjangan_sewa 
        (id_penyewaan, id_kontrakan, id_penyewa, tanggal_mulai, tanggal_selesai, durasi, 
         total_bayar, metode_pembayaran, bukti_pembayaran, keterangan, status, tanggal_pengajuan) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'menunggu', NOW())");

    $stmt->bind_param("iiissiisss", 
        $id_penyewaan, 
        $id_kontrakan,
        $id_penyewa,
        $tanggal_mulai, 
        $tanggal_selesai, 
        $durasi, 
        $total_bayar, 
        $metode, 
        $bukti_pembayaran, 
        $keterangan
    );

    if ($stmt->execute()) {
        $_SESSION['toast'] = ['type' => 'success', 'message' => 'Pengajuan perpanjangan berhasil dikirim.'];
        echo json_encode([
            'success' => true, 
            'message' => 'Pengajuan perpanjangan berhasil dikirim.',
            'redirect' => '../../user/dashboard.php'
        ]);
    } else {
        // Delete uploaded file if database insertion fails
        if ($metode === 'transfer' && $bukti_pembayaran) {
            @unlink($file_destination);
        }
        $_SESSION['toast'] = ['type' => 'error', 'message' => 'Gagal menyimpan data: ' . $conn->error];
        echo json_encode(['success' => false, 'message' => 'Gagal menyimpan data: ' . $conn->error]);
    }

    $stmt->close();
    $conn->close();
    exit;
}

// Return error for invalid request method
$_SESSION['toast'] = ['type' => 'error', 'message' => 'Metode request tidak valid!'];
echo json_encode(['success' => false, 'message' => 'Metode request tidak valid!']);