<?php

session_start();
header('Content-Type: application/json');

// Include database connection
require_once '../../config/db.php';

// Validasi input
$booking_id = filter_input(INPUT_POST, 'booking_id', FILTER_VALIDATE_INT);
$upload_flag = filter_input(INPUT_POST, 'upload_bukti_pembayaran', FILTER_VALIDATE_INT);

if (!$booking_id || !$upload_flag) {
    echo json_encode([
        'success' => false, 
        'message' => 'Parameter tidak valid.'
    ]);
    exit();
}

// Get user information from session
$user_id = $_SESSION['user_user_id'];
$username = $_SESSION['user_user_nama_pengguna'];

// Retrieve id_kontrakan from the booking entry in database
$get_kontrakan_query = "SELECT id_kontrakan FROM booking WHERE id = ? AND id_penyewa = ?";
$stmt_get_kontrakan = mysqli_prepare($conn, $get_kontrakan_query);

if (!$stmt_get_kontrakan) {
    echo json_encode([
        'success' => false,
        'message' => 'Error preparing statement: ' . mysqli_error($conn)
    ]);
    exit();
}

mysqli_stmt_bind_param($stmt_get_kontrakan, "ii", $booking_id, $user_id);
mysqli_stmt_execute($stmt_get_kontrakan);
mysqli_stmt_bind_result($stmt_get_kontrakan, $id_kontrakan);

if (!mysqli_stmt_fetch($stmt_get_kontrakan)) {
    echo json_encode([
        'success' => false,
        'message' => 'Data booking tidak ditemukan.'
    ]);
    mysqli_stmt_close($stmt_get_kontrakan);
    mysqli_close($conn);
    exit();
}

mysqli_stmt_close($stmt_get_kontrakan);

// Cek apakah file telah diupload
if (!isset($_FILES['bukti_pembayaran']) || $_FILES['bukti_pembayaran']['error'] == UPLOAD_ERR_NO_FILE) {
    echo json_encode([
        'success' => false, 
        'message' => 'Silakan pilih file bukti pembayaran.'
    ]);
    exit();
}

// Konfigurasi upload
$upload_dir = '../../user/bukti_pembayaran/';

// Buat direktori jika belum ada
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Informasi file
$file_name = $_FILES['bukti_pembayaran']['name'];
$file_tmp = $_FILES['bukti_pembayaran']['tmp_name'];
$file_size = $_FILES['bukti_pembayaran']['size'];
$file_type = $_FILES['bukti_pembayaran']['type'];

// Validasi ukuran file (maks 5MB)
if ($file_size > 5 * 1024 * 1024) {
    echo json_encode([
        'success' => false, 
        'message' => 'Ukuran file terlalu besar. Maks 5MB.'
    ]);
    exit();
}

// Daftar tipe file yang diizinkan
$allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];

// Validasi tipe file
if (!in_array($file_type, $allowed_types)) {
    echo json_encode([
        'success' => false, 
        'message' => 'Tipe file tidak diizinkan. Gunakan JPG, JPEG, PNG, atau PDF.'
    ]);
    exit();
}

// Generate nama file dengan id_kontrakan yang sudah didapatkan dari database
$file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
$new_file_name = 'bukti_booking_' . $username . '_' . $id_kontrakan . '.' . $file_ext;
$destination = $upload_dir . $new_file_name;

// Debug - log values
error_log("booking_id: $booking_id, user_id: $user_id, id_kontrakan: $id_kontrakan, filename: $new_file_name");

// Pindahkan file yang diupload, timpa jika sudah ada
if (move_uploaded_file($file_tmp, $destination)) {
    // Timestamp untuk keterangan
    $timestamp = date('Y-m-d H:i:s');
    $keterangan = "Bukti pembayaran diupload pada $timestamp";

    // Persiapkan query update
    $update_bukti_query = "
        UPDATE booking 
        SET bukti_pembayaran = ?,
            status_booking = 'menunggu',
            keterangan = ?
        WHERE id = ? AND id_penyewa = ?
    ";

    $stmt_update_bukti = mysqli_prepare($conn, $update_bukti_query);
    if (!$stmt_update_bukti) {
        error_log("mysqli prepare error: " . mysqli_error($conn));
        echo json_encode([
            'success' => false,
            'message' => 'Error preparing statement: ' . mysqli_error($conn)
        ]);
        unlink($destination); // Hapus file jika gagal
        exit();
    }

    mysqli_stmt_bind_param($stmt_update_bukti, "ssii", 
        $new_file_name,
        $keterangan,
        $booking_id,
        $user_id
    );

    $result = mysqli_stmt_execute($stmt_update_bukti);

    if (!$result) {
        error_log("mysqli execute error: " . mysqli_stmt_error($stmt_update_bukti));
        echo json_encode([
            'success' => false,
            'message' => 'Error executing statement: ' . mysqli_stmt_error($stmt_update_bukti)
        ]);
        unlink($destination); // Hapus file jika gagal
        mysqli_stmt_close($stmt_update_bukti);
        mysqli_close($conn);
        exit();
    }

    $affected_rows = mysqli_stmt_affected_rows($stmt_update_bukti);
    if ($affected_rows > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Bukti pembayaran berhasil diupload.',
            'file_name' => $new_file_name
        ]);
    } else {
        error_log("No rows affected. booking_id: $booking_id, user_id: $user_id");
        echo json_encode([
            'success' => false,
            'message' => 'Tidak ada data booking yang cocok untuk diupdate.'
        ]);
        unlink($destination); // Hapus file jika tidak terpakai
    }

    mysqli_stmt_close($stmt_update_bukti);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Gagal mengupload file.'
    ]);
}

mysqli_close($conn);
exit();
?>