<?php
session_start();
require_once "../../config/db.php"; // koneksi database

// Periksa apakah user sedang login
if (isset($_SESSION['user_user_id'])) {
    $userId = $_SESSION['user_user_id'];

    // Update status ke nonaktif
    $query = "UPDATE pengguna SET status = 'nonaktif' WHERE id = $userId";
    mysqli_query($conn, $query);

    // (Opsional) Jika ingin simpan waktu keluar juga, tambahkan kolom `terakhir_keluar` di tabel
    // $query = "UPDATE pengguna SET status = 'nonaktif', terakhir_keluar = NOW() WHERE id = $userId";
}

// Bersihkan session
session_unset();
session_destroy();

// Arahkan ke halaman login
header("Location: ../../public/index.php");
exit();
