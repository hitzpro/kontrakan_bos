<?php
session_start();
require_once '../../config/db.php'; // Koneksi DB

header('Content-Type: application/json');

$response = [
    'success' => false,
    'message' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'], $_POST['aksi'])) {
    $booking_id = intval($_POST['booking_id']);
    $aksi = $_POST['aksi'];

    try {
        // Ambil data booking
        $sql = "SELECT metode_pembayaran FROM booking WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $booking = $result->fetch_assoc();

        if (!$booking) {
            throw new Exception('Data booking tidak ditemukan.');
        }

        if ($aksi === 'konfirmasi_tunai' && $booking['metode_pembayaran'] === 'tunai') {
            // Update status booking jadi 'menunggu'
            $update = "UPDATE booking SET status_booking = 'menunggu' WHERE id = ?";
            $stmt_update = $conn->prepare($update);
            $stmt_update->bind_param("i", $booking_id);

            if (!$stmt_update->execute()) {
                throw new Exception('Gagal memperbarui status booking.');
            }

            $_SESSION['toast'] = [
                'type' => 'success',
                'message' => 'Pembayaran tunai berhasil dikonfirmasi.'
            ];

            $response['success'] = true;
            $response['message'] = 'Status booking berhasil diperbarui.';
        } else {
            throw new Exception('Aksi tidak valid atau metode pembayaran tidak sesuai.');
        }
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => $e->getMessage()
        ];
    } finally {
        $stmt->close();
        if (isset($stmt_update)) $stmt_update->close();
        $conn->close();
    }

    echo json_encode($response);
    exit();
}
