<?php
session_start();
require '../../config/db.php';

$username = $_SESSION['user_user_nama_pengguna'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_FILES['bukti_pembayaran'])) {
    $id = $_POST['id'];
    $file = $_FILES['bukti_pembayaran'];

    // Ambil id_kontrakan dari penyewaan
    $kontrakanQuery = mysqli_query($conn, "SELECT id_kontrakan FROM penyewaan WHERE id = '$id'");
    if (!$kontrakanQuery || mysqli_num_rows($kontrakanQuery) == 0) {
        $_SESSION['toast'] = ['type' => 'error', 'message' => 'Data penyewaan tidak ditemukan.'];
        echo json_encode(['success' => false, 'message' => 'Data penyewaan tidak ditemukan']);
        exit;
    }
    $kontrakanData = mysqli_fetch_assoc($kontrakanQuery);
    $id_kontrakan = $kontrakanData['id_kontrakan'];

    // Validasi tipe file
    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
    if (!in_array($file['type'], $allowed_types)) {
        $_SESSION['toast'] = ['type' => 'error', 'message' => 'Jenis file tidak valid.'];
        echo json_encode(['success' => false, 'message' => 'Jenis file tidak valid']);
        exit;
    }

    // Validasi ukuran file
    if ($file['size'] > 5 * 1024 * 1024) {
        $_SESSION['toast'] = ['type' => 'error', 'message' => 'Ukuran file melebihi 5MB.'];
        echo json_encode(['success' => false, 'message' => 'Ukuran file terlalu besar']);
        exit;
    }

    // Penamaan file dengan tambahan id_kontrakan
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $new_name = 'bukti_sewa_' . $username . '_' . $id_kontrakan .  '.' . $ext;
    $upload_dir = '../../user/bukti_pembayaran/';
    $upload_path = $upload_dir . $new_name;

    // Cek folder upload
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Upload file dan update DB
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        $query = mysqli_query($conn, "UPDATE penyewaan SET bukti_pembayaran = '$new_name' WHERE id = '$id'");
        if ($query) {
            $_SESSION['toast'] = ['type' => 'success', 'message' => 'Bukti pembayaran berhasil diupload.'];
            echo json_encode(['success' => true]);
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'message' => 'Gagal menyimpan ke database.'];
            echo json_encode(['success' => false]);
        }
    } else {
        $_SESSION['toast'] = ['type' => 'error', 'message' => 'Upload file gagal.'];
        echo json_encode(['success' => false]);
    }
} else {
    $_SESSION['toast'] = ['type' => 'error', 'message' => 'Permintaan tidak valid.'];
    echo json_encode(['success' => false]);
}
?>
