<?php
header('Content-Type: text/plain');
echo "Connection test successful. Received booking_id: " . $_POST['booking_id'];
?>