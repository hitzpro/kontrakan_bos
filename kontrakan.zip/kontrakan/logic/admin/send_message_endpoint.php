<?php
session_start();
require_once '../../config/db.php'; // Adjust path as needed

// Check if admin is logged in
if (!isset($_SESSION['admin_user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Admin not logged in']);
    exit;
}

// Get POST data
$booking_id = $_POST['booking_id'] ?? null;
$user_id = $_POST['user_id'] ?? null;
$admin_user_id = $_POST['admin_user_id'] ?? null;
$message = $_POST['message'] ?? null;

// Validate input
if (!$booking_id || !$user_id || !$admin_user_id || !$message) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required data']);
    exit;
}

try {
    // Insert message into database
    $sql = "INSERT INTO messages (booking_id, user_id, admin_id, message, created_at) 
            VALUES (?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiis", $booking_id, $user_id, $admin_user_id, $message);
    $stmt->execute();
    
    // Set session message for the user
    // Here we're storing this in a database table to be fetched when user logs in
    $sql = "INSERT INTO user_notifications (user_id, message, is_read, created_at) 
            VALUES (?, ?, 0, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $message);
    $stmt->execute();
    
    // Set expiration time for the payment upload (1 hour from now)
    $expiration = date('Y-m-d H:i:s', strtotime('+1 hour'));
    $sql = "UPDATE bookings SET payment_upload_deadline = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $expiration, $booking_id);
    $stmt->execute();
    
    echo json_encode(['status' => 'success', 'message' => 'Message sent successfully']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>