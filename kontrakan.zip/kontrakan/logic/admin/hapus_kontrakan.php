<?php
// Debug awal
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session to be able to use session variables
session_start();

// Include koneksi database
require_once('../../config/db.php');

// Cek request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Metode tidak diizinkan'
    ]);
    exit;
}

// Ambil dan validasi data POST
$action = $_POST['action'] ?? '';
$id = $_POST['id'] ?? '';

if ($action !== 'delete_kontrakan' || empty($id)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Data tidak lengkap atau aksi tidak valid'
    ]);
    exit;
}

// Escape input
$id = mysqli_real_escape_string($conn, $id);

// Cek apakah data kontrakan dengan ID tersebut ada
$check = mysqli_query($conn, "SELECT * FROM data_kontrakan WHERE id = '$id'");
if (mysqli_num_rows($check) === 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Data kontrakan tidak ditemukan'
    ]);
    exit;
}

// Eksekusi DELETE
$delete = mysqli_query($conn, "DELETE FROM data_kontrakan WHERE id = '$id'");

if ($delete) {
    // Set session message
    $_SESSION['message'] = "Data kontrakan berhasil dihapus";
    $_SESSION['message_type'] = "success";

    echo json_encode([
        'status' => 'success',
        'message' => 'Data kontrakan berhasil dihapus'
    ]);
} else {
    // Set session message for error
    $_SESSION['message'] = "Gagal menghapus data kontrakan: " . mysqli_error($conn);
    $_SESSION['message_type'] = "error";
    
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal menghapus data kontrakan: ' . mysqli_error($conn)
    ]);
}
?>