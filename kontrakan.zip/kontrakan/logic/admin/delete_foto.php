<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
header('Content-Type: application/json');
require_once '../../config/db.php';

$target_dir = "../../images/kontrakan/";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_foto') {
    $foto = mysqli_real_escape_string($conn, $_POST['foto']);
    $kontrakan_id = mysqli_real_escape_string($conn, $_POST['kontrakan_id']);
    
    // Hapus dari database
    $sql = "DELETE FROM foto_kontrakan WHERE foto = '$foto' AND id_kontrakan = '$kontrakan_id'";
    
    if (mysqli_query($conn, $sql)) {
        // Jika berhasil hapus dari database, hapus file fisik
        $file_path = $target_dir . $foto;
        if (file_exists($file_path)) {
            unlink($file_path);
        }
        
        echo json_encode([
            'status' => 'success', 
            'message' => 'Foto berhasil dihapus'
        ]);
    } else {
        echo json_encode([
            'status' => 'error', 
            'message' => 'Gagal menghapus foto: ' . mysqli_error($conn)
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error', 
        'message' => 'Invalid request'
    ]);
}
?>