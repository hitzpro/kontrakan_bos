<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
header('Content-Type: application/json');
require_once '../../config/db.php';

$id_pemilik = $_SESSION['id_pengguna'] ?? 1;
$target_dir = "../../images/kontrakan/";
if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

function sanitizeFileName($base, $prefix = 'foto') {
    return $prefix . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', strtolower($base)) . '_' . time() . '_' . uniqid();
}

$allowed_types = ['image/jpeg', 'image/png', 'image/webp'];
$max_size = 5 * 1024 * 1024;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $fields = ['nama_kontrakan', 'deskripsi', 'lokasi', 'alamat_lengkap', 'harga', 'fasilitas', 'luas', 'tipe_kontrakan', 'status', 'kontak_pemilik'];
    $data = [];
    foreach ($fields as $field) {
        $data[$field] = mysqli_real_escape_string($conn, $_POST[$field] ?? '');
    }

    $thumbnail = '';
    if (!empty($_FILES['foto']['name']) && $_FILES['foto']['error'] == 0) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $thumbnail = sanitizeFileName($data['nama_kontrakan'], 'thumbnail') . ".$ext";
        if (in_array($_FILES['foto']['type'], $allowed_types) && $_FILES['foto']['size'] <= $max_size) {
            move_uploaded_file($_FILES['foto']['tmp_name'], $target_dir . $thumbnail);
        }
    }

    $foto_list = [];
    if (!empty($_FILES['foto_lain']['name'])) {
        foreach ($_FILES['foto_lain']['name'] as $i => $name) {
            if ($_FILES['foto_lain']['error'][$i] === 0) {
                $ext = pathinfo($name, PATHINFO_EXTENSION);
                $filename = sanitizeFileName($data['nama_kontrakan'], 'foto') . ".$ext";
                if (in_array($_FILES['foto_lain']['type'][$i], $allowed_types) && $_FILES['foto_lain']['size'][$i] <= $max_size) {
                    move_uploaded_file($_FILES['foto_lain']['tmp_name'][$i], $target_dir . $filename);
                    $foto_list[] = $filename;
                }
            }
        }
    }

    if ($action === 'add') {
        $sql = "INSERT INTO data_kontrakan (id_pemilik, nama_kontrakan, deskripsi, lokasi, alamat_lengkap, harga, fasilitas, luas, tipe_kontrakan, status, foto, kontak_pemilik)
                VALUES ('$id_pemilik', '{$data['nama_kontrakan']}', '{$data['deskripsi']}', '{$data['lokasi']}', '{$data['alamat_lengkap']}', '{$data['harga']}', '{$data['fasilitas']}', '{$data['luas']}', '{$data['tipe_kontrakan']}', '{$data['status']}', '$thumbnail', '{$data['kontak_pemilik']}')";

        if (mysqli_query($conn, $sql)) {
            $id_kontrakan = mysqli_insert_id($conn);
            foreach ($foto_list as $file) {
                $file_clean = mysqli_real_escape_string($conn, $file);
                mysqli_query($conn, "INSERT INTO foto_kontrakan (id_kontrakan, foto) VALUES ('$id_kontrakan', '$file_clean')");
            }
            
            // Set session message for redirect
            $_SESSION['message'] = 'Kontrakan berhasil ditambahkan';
            $_SESSION['message_type'] = 'success';
            
            echo json_encode(['status' => 'success', 'message' => 'Kontrakan ditambahkan']);
        } else {
            echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
        }

    } elseif ($action === 'update') {
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        
        // Get old data
        $result = mysqli_query($conn, "SELECT foto FROM data_kontrakan WHERE id = '$id'");
        $old = mysqli_fetch_assoc($result);
        
        // Handle thumbnail update
        if ($thumbnail && !empty($thumbnail)) {
            // Delete old thumbnail if exists
            if ($old['foto'] && file_exists($target_dir . $old['foto'])) {
                unlink($target_dir . $old['foto']);
            }
        } else {
            // Keep old thumbnail if no new one uploaded
            $thumbnail = $old['foto'];
        }

        // Update main data
        $sql = "UPDATE data_kontrakan SET 
                id_pemilik = '$id_pemilik',
                nama_kontrakan = '{$data['nama_kontrakan']}',
                deskripsi = '{$data['deskripsi']}',
                lokasi = '{$data['lokasi']}',
                alamat_lengkap = '{$data['alamat_lengkap']}',
                harga = '{$data['harga']}',
                fasilitas = '{$data['fasilitas']}',
                luas = '{$data['luas']}',
                tipe_kontrakan = '{$data['tipe_kontrakan']}',
                status = '{$data['status']}',
                foto = '$thumbnail',
                kontak_pemilik = '{$data['kontak_pemilik']}'
                WHERE id = '$id'";

        if (mysqli_query($conn, $sql)) {
            // Only add new photos if there are any
            if (!empty($foto_list)) {
                // Get existing photos to delete files
                $existing_photos = mysqli_query($conn, "SELECT foto FROM foto_kontrakan WHERE id_kontrakan = '$id'");
                while ($photo = mysqli_fetch_assoc($existing_photos)) {
                    if (file_exists($target_dir . $photo['foto'])) {
                        unlink($target_dir . $photo['foto']);
                    }
                }
                
                // Delete old photo records
                mysqli_query($conn, "DELETE FROM foto_kontrakan WHERE id_kontrakan = '$id'");
                
                // Insert new photos
                foreach ($foto_list as $file) {
                    $file_clean = mysqli_real_escape_string($conn, $file);
                    mysqli_query($conn, "INSERT INTO foto_kontrakan (id_kontrakan, foto) VALUES ('$id', '$file_clean')");
                }
            }
            
            // Set session message for redirect
            $_SESSION['message'] = 'Kontrakan berhasil diperbarui';
            $_SESSION['message_type'] = 'success';
            
            echo json_encode(['status' => 'success', 'message' => 'Kontrakan diperbarui']);
        } else {
            echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get') {
    // Get single kontrakan data for editing
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $sql = "SELECT dk.*, GROUP_CONCAT(fk.foto) AS foto_lain 
            FROM data_kontrakan dk
            LEFT JOIN foto_kontrakan fk ON dk.id = fk.id_kontrakan
            WHERE dk.id = '$id'
            GROUP BY dk.id";
    
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        $data['foto_lain'] = !empty($data['foto_lain']) ? explode(',', $data['foto_lain']) : [];
        echo json_encode(['status' => 'success', 'data' => $data]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak ditemukan']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>