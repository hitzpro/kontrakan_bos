<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
ob_start();
header('Content-Type: application/json');
require_once '../../config/db.php'; // koneksi kamu

$id_pemilik = 1;

// Check if form is submitted for add/edit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'add') {
        // Add new kontrakan
        $nama_kontrakan = mysqli_real_escape_string($conn, $_POST['nama_kontrakan']);
        $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
        $lokasi = mysqli_real_escape_string($conn, $_POST['lokasi']);
        $alamat_lengkap = mysqli_real_escape_string($conn, $_POST['alamat_lengkap']);
        $harga = mysqli_real_escape_string($conn, $_POST['harga']);
        $fasilitas = mysqli_real_escape_string($conn, $_POST['fasilitas']);
        $luas = mysqli_real_escape_string($conn, $_POST['luas']);
        $tipe_kontrakan = mysqli_real_escape_string($conn, $_POST['tipe_kontrakan']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        $kontak_pemilik = mysqli_real_escape_string($conn, $_POST['kontak_pemilik']);
        
        // Handle file upload
        $foto = '';
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            $target_dir = "../../images/kontrakan/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            
            $file_name = time() . '_' . basename($_FILES["foto"]["name"]);
            $target_file = $target_dir . $file_name;
            
            if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                $foto = $file_name;
            }
        }
        
        $sql = "INSERT INTO data_kontrakan (id_pemilik, nama_kontrakan, deskripsi, lokasi, alamat_lengkap, harga, fasilitas, luas, tipe_kontrakan, status, foto, kontak_pemilik) 
                VALUES ('$id_pemilik', '$nama_kontrakan', '$deskripsi', '$lokasi', '$alamat_lengkap', '$harga', '$fasilitas', '$luas', '$tipe_kontrakan', '$status', '$foto', '$kontak_pemilik')";
        
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "Data kontrakan berhasil ditambahkan";
            $_SESSION['message_type'] = "success";
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Data kontrakan berhasil ditambahkan'
            ]);
        } else {
            $_SESSION['message'] = "Gagal menambahkan data: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
            
            echo json_encode([
                'status' => 'error',
                'message' => 'Gagal menambahkan data: ' . mysqli_error($conn)
            ]);
        }
        
    } elseif ($_POST['action'] == 'update') {
        // Edit kontrakan
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $nama_kontrakan = mysqli_real_escape_string($conn, $_POST['nama_kontrakan']);
        $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
        $lokasi = mysqli_real_escape_string($conn, $_POST['lokasi']);
        $alamat_lengkap = mysqli_real_escape_string($conn, $_POST['alamat_lengkap']);
        $harga = mysqli_real_escape_string($conn, $_POST['harga']);
        $fasilitas = mysqli_real_escape_string($conn, $_POST['fasilitas']);
        $luas = mysqli_real_escape_string($conn, $_POST['luas']);
        $tipe_kontrakan = mysqli_real_escape_string($conn, $_POST['tipe_kontrakan']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        $kontak_pemilik = mysqli_real_escape_string($conn, $_POST['kontak_pemilik']);
        
        // Get current foto
        $current_foto_query = "SELECT foto FROM data_kontrakan WHERE id = '$id'";
        $result = mysqli_query($conn, $current_foto_query);
        $row = mysqli_fetch_assoc($result);
        $current_foto = $row['foto'];
        
        // Handle file upload if new foto is provided
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            $target_dir = "../../images/kontrakan/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            
            $file_name = time() . '_' . basename($_FILES["foto"]["name"]);
            $target_file = $target_dir . $file_name;
            
            if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                // Delete old foto if exists
                if (!empty($current_foto) && file_exists($target_dir . $current_foto)) {
                    unlink($target_dir . $current_foto);
                }
                $foto = $file_name;
            } else {
                $foto = $current_foto;
            }
        } else {
            $foto = $current_foto;
        }
        
        $sql = "UPDATE data_kontrakan SET 
                id_pemilik = '$id_pemilik',
                nama_kontrakan = '$nama_kontrakan',
                deskripsi = '$deskripsi',
                lokasi = '$lokasi',
                alamat_lengkap = '$alamat_lengkap',
                harga = '$harga',
                fasilitas = '$fasilitas',
                luas = '$luas',
                tipe_kontrakan = '$tipe_kontrakan',
                status = '$status',
                foto = '$foto',
                kontak_pemilik = '$kontak_pemilik'
                WHERE id = '$id'";
        
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "Data kontrakan berhasil diperbarui";
            $_SESSION['message_type'] = "success";
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Data kontrakan berhasil diperbarui'
            ]);
        } else {
            $_SESSION['message'] = "Gagal memperbarui data: " . mysqli_error($conn);
            $_SESSION['message_type'] = "error";
            
            echo json_encode([
                'status' => 'error',
                'message' => 'Gagal memperbarui data: ' . mysqli_error($conn)
            ]);
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid action'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method or missing action parameter'
    ]);
}
?>