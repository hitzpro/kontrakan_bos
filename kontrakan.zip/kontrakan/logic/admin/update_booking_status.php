<?php
session_start();

// Ensure no output before header() calls
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to browser
ini_set('log_errors', 1); // Log errors instead

if (!isset($_SESSION['admin_user_id'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized access'
    ]);
    exit();
}

// Include database connection
require_once '../../config/db.php'; // Pastikan koneksi mysqli ada di variabel $conn

function debug_log($message) {
    if (is_array($message) || is_object($message)) {
        error_log(print_r($message, true));
    } else {
        error_log($message);
    }
}

function is_valid_status($status) {
    $validStatuses = ['belum bayar', 'menunggu', 'terkonfirmasi', 'dibatalkan'];
    return in_array($status, $validStatuses);
}

function insert_to_penyewaan($conn, $bookingId) {
    debug_log("Starting insert_to_penyewaan function for booking ID: $bookingId");
    
    // Get booking data with detailed debug info
    $query = "SELECT * FROM booking WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    
    if (!$stmt) {
        debug_log("Prepare statement failed: " . mysqli_error($conn));
        return false;
    }
    
    mysqli_stmt_bind_param($stmt, "i", $bookingId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $booking = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$booking) {
        debug_log("No booking found with ID: $bookingId");
        return false;
    }
    
    debug_log("Booking data retrieved: " . print_r($booking, true));
    
    // Get penyewa ID
    $userQuery = "SELECT id FROM pengguna WHERE id = ?";
    $userStmt = mysqli_prepare($conn, $userQuery);
    
    if (!$userStmt) {
        debug_log("Prepare user statement failed: " . mysqli_error($conn));
        return false;
    }
    
    mysqli_stmt_bind_param($userStmt, "i", $booking['id_penyewa']);
    mysqli_stmt_execute($userStmt);
    $userResult = mysqli_stmt_get_result($userStmt);
    $user = mysqli_fetch_assoc($userResult);
    mysqli_stmt_close($userStmt);
    
    if (!$user) {
        debug_log("No user found with ID: " . $booking['id_penyewa']);
        return false;
    }
    
    $idPenyewa = $user['id'];
    debug_log("User ID retrieved: $idPenyewa");
    
    // Check if entry already exists
    $checkQuery = "SELECT id FROM penyewaan WHERE id_booking = ?";
    $checkStmt = mysqli_prepare($conn, $checkQuery);
    
    if (!$checkStmt) {
        debug_log("Prepare check statement failed: " . mysqli_error($conn));
        return false;
    }
    
    mysqli_stmt_bind_param($checkStmt, "i", $bookingId);
    mysqli_stmt_execute($checkStmt);
    mysqli_stmt_store_result($checkStmt);
    $exists = mysqli_stmt_num_rows($checkStmt) > 0;
    mysqli_stmt_close($checkStmt);
    
    if ($exists) {
        debug_log("Entry already exists in penyewaan table for booking ID: $bookingId");
        return true; // Already exists, no need to insert
    }
    
    // FIX: Use tanggal_mulai from booking if present, otherwise use tanggal_booking
    $tanggalMulai = !empty($booking['tanggal_mulai']) ? $booking['tanggal_mulai'] : $booking['tanggal_booking'];
    
    // FIX: Check if tanggal_selesai already exists in booking
    if (!empty($booking['tanggal_selesai'])) {
        $tanggalSelesai = $booking['tanggal_selesai'];
        debug_log("Using existing tanggal_selesai from booking: $tanggalSelesai");
    } else {
        // Calculate tanggal_selesai based on booking data
        $durasiSewa = isset($booking['periode_sewa']) && $booking['periode_sewa'] > 0 ? $booking['periode_sewa'] : 1;
        
        // Calculate tanggal_selesai using MySQL DATE_ADD
        $dateQuery = "SELECT DATE_ADD(?, INTERVAL ? MONTH) as tanggal_selesai";
        $dateStmt = mysqli_prepare($conn, $dateQuery);
        
        if (!$dateStmt) {
            debug_log("Prepare date statement failed: " . mysqli_error($conn));
            return false;
        }
        
        mysqli_stmt_bind_param($dateStmt, "si", $tanggalMulai, $durasiSewa);
        mysqli_stmt_execute($dateStmt);
        $dateResult = mysqli_stmt_get_result($dateStmt);
        $dateRow = mysqli_fetch_assoc($dateResult);
        $tanggalSelesai = $dateRow['tanggal_selesai'];
        mysqli_stmt_close($dateStmt);
        debug_log("Calculated tanggal_selesai: $tanggalSelesai");
    }
    
    // FIX: Get harga_sewa from kontrakan if not set in booking
    $hargaSewa = $booking['harga_sewa'] ?? null;
    if (empty($hargaSewa) && !empty($booking['id_kontrakan'])) {
        $hargaQuery = "SELECT harga FROM data_kontrakan WHERE id = ?";
        $hargaStmt = mysqli_prepare($conn, $hargaQuery);
        if ($hargaStmt) {
            mysqli_stmt_bind_param($hargaStmt, "i", $booking['id_kontrakan']);
            mysqli_stmt_execute($hargaStmt);
            $hargaResult = mysqli_stmt_get_result($hargaStmt);
            $hargaRow = mysqli_fetch_assoc($hargaResult);
            $hargaSewa = $hargaRow['harga'] ?? 0;
            mysqli_stmt_close($hargaStmt);
            debug_log("Retrieved harga_sewa from kontrakan: $hargaSewa");
        }
    }
    
    // FIX: Default value for periode_sewa
    $durasiSewa = isset($booking['periode_sewa']) && $booking['periode_sewa'] > 0 ? $booking['periode_sewa'] : 1;
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Insert into penyewaan table
        $insertQuery = "INSERT INTO penyewaan (
            id_booking, 
            id_penyewa, 
            id_kontrakan, 
            tanggal_mulai, 
            tanggal_selesai, 
            durasi_sewa, 
            harga_sewa, 
            total_bayar, 
            metode_pembayaran, 
            bukti_pembayaran, 
            status_pembayaran, 
            status_sewa, 
            keterangan
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'aktif', ?)";
        
        // Always use 'lunas' for status_pembayaran when booking is confirmed
        $statusPembayaran = 'lunas';
        
        $insertStmt = mysqli_prepare($conn, $insertQuery);
        
        if (!$insertStmt) {
            debug_log("Prepare insert statement failed: " . mysqli_error($conn));
            mysqli_rollback($conn);
            return false;
        }
        
        mysqli_stmt_bind_param(
            $insertStmt, 
            "iiissiddssss", 
            $booking['id'], 
            $idPenyewa, 
            $booking['id_kontrakan'], 
            $tanggalMulai, 
            $tanggalSelesai, 
            $durasiSewa, 
            $hargaSewa, 
            $booking['total_bayar'], 
            $booking['metode_pembayaran'], 
            $booking['bukti_pembayaran'], 
            $statusPembayaran, 
            $booking['keterangan']
        );
        
        $success = mysqli_stmt_execute($insertStmt);
        
        if (!$success) {
            debug_log("Failed to insert into penyewaan: " . mysqli_stmt_error($insertStmt));
            mysqli_rollback($conn);
            mysqli_stmt_close($insertStmt);
            return false;
        }
        
        // Get the ID of the newly inserted penyewaan record
        $penyewaanId = mysqli_insert_id($conn);
        debug_log("Successfully inserted into penyewaan table with ID: $penyewaanId for booking ID: $bookingId");
        mysqli_stmt_close($insertStmt);
        
        // FIX: Insert into pembayaran even if bukti_pembayaran is empty - just check total_bayar
        if ($booking['total_bayar'] > 0) {
            // Insert into pembayaran table
            $insertPaymentQuery = "INSERT INTO pembayaran (
                id_penyewaan,
                jumlah,
                tanggal_pembayaran,
                metode,
                bukti_pembayaran
            ) VALUES (?, ?, NOW(), ?, ?)";
            
            $paymentStmt = mysqli_prepare($conn, $insertPaymentQuery);
            
            if (!$paymentStmt) {
                debug_log("Prepare payment statement failed: " . mysqli_error($conn));
                mysqli_rollback($conn);
                return false;
            }
            
            $buktiBayar = !empty($booking['bukti_pembayaran']) ? $booking['bukti_pembayaran'] : '';
            $metodeBayar = !empty($booking['metode_pembayaran']) ? $booking['metode_pembayaran'] : 'tunai';
            
            mysqli_stmt_bind_param(
                $paymentStmt,
                "idss",
                $penyewaanId,
                $booking['total_bayar'],
                $metodeBayar,
                $buktiBayar
            );
            
            $paymentSuccess = mysqli_stmt_execute($paymentStmt);
            
            if (!$paymentSuccess) {
                debug_log("Failed to insert into pembayaran: " . mysqli_stmt_error($paymentStmt));
                mysqli_rollback($conn);
                mysqli_stmt_close($paymentStmt);
                return false;
            }
            
            debug_log("Successfully inserted into pembayaran table for penyewaan ID: $penyewaanId");
            mysqli_stmt_close($paymentStmt);
        } else {
            debug_log("No payment record inserted because total_bayar is 0");
        }
        
        // Commit the transaction
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        debug_log("Exception during transaction: " . $e->getMessage());
        return false;
    }
}

function update_booking_status($conn, $bookingId, $status, $keterangan = '') {
    debug_log("Starting update_booking_status function for booking ID: $bookingId to status: $status");

    // Check if booking exists
    $checkQuery = "SELECT status_booking, id_penyewa, id_kontrakan FROM booking WHERE id = ?";
    $checkStmt = mysqli_prepare($conn, $checkQuery);
    mysqli_stmt_bind_param($checkStmt, "i", $bookingId);
    mysqli_stmt_execute($checkStmt);
    $result = mysqli_stmt_get_result($checkStmt);
    $currentBooking = mysqli_fetch_assoc($result);
    mysqli_stmt_close($checkStmt);

    if (!$currentBooking) {
        debug_log("No booking found with ID: $bookingId");
        return false;
    }

    debug_log("Current booking status: " . $currentBooking['status_booking']);

    // Validasi transisi status
    if ($currentBooking['status_booking'] === 'dibatalkan' && $status !== 'dibatalkan') {
        debug_log("Invalid transition from 'dibatalkan' to '$status'");
        return false;
    }

    // Begin transaction to ensure consistency
    mysqli_begin_transaction($conn);
    
    try {
        // Update status
        if (!empty($keterangan)) {
            $query = "UPDATE booking SET status_booking = ?, keterangan = ? WHERE id = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "ssi", $status, $keterangan, $bookingId);
        } else {
            $query = "UPDATE booking SET status_booking = ? WHERE id = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "si", $status, $bookingId);
        }

        $updateSuccess = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        debug_log("Update status result: " . ($updateSuccess ? "Success" : "Failed"));

        if (!$updateSuccess) {
            throw new Exception("Failed to update booking status");
        }

        if ($status === 'terkonfirmasi') {
            // Update status_pembayaran to "lunas" in booking table when status is confirmed
            $updatePaymentQuery = "UPDATE penyewaan SET status_pembayaran = 'lunas' WHERE id = ?";
            $updatePaymentStmt = mysqli_prepare($conn, $updatePaymentQuery);
            mysqli_stmt_bind_param($updatePaymentStmt, "i", $bookingId);
            $updatePaymentSuccess = mysqli_stmt_execute($updatePaymentStmt);
            mysqli_stmt_close($updatePaymentStmt);
            
            debug_log("Update payment status result: " . ($updatePaymentSuccess ? "Success" : "Failed"));
            
            if (!$updatePaymentSuccess) {
                throw new Exception("Failed to update payment status to lunas");
            }
            
            // Update kontrakan availability
            $availabilityResult = update_kontrakan_availability($conn, $bookingId);
            debug_log("Update kontrakan availability result: " . ($availabilityResult ? "Success" : "Failed"));
            
            if (!$availabilityResult) {
                throw new Exception("Failed to update kontrakan availability");
            }
            
            // Insert into penyewaan table when status is confirmed
            // Modified to use 'lunas' as status_pembayaran
            $insertResult = insert_to_penyewaan($conn, $bookingId);
            debug_log("Insert to penyewaan result: " . ($insertResult ? "Success" : "Failed"));
            
            if (!$insertResult) {
                debug_log("Failed to insert to penyewaan. Check connection and database structure.");
                throw new Exception("Failed to create rental record");
            }
        } elseif ($status === 'dibatalkan') {
            // Set kontrakan status to 'tersedia' when booking is canceled
            $availabilityResult = update_kontrakan_availability($conn, $bookingId, true);
            debug_log("Update kontrakan availability for cancellation: " . ($availabilityResult ? "Success" : "Failed"));
            
            if (!$availabilityResult) {
                throw new Exception("Failed to update kontrakan availability after cancellation");
            }
        }
        
        // Commit the transaction if everything succeeded
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        // Rollback transaction if any operation failed
        mysqli_rollback($conn);
        debug_log("Transaction failed: " . $e->getMessage());
        return false;
    }
}


function update_kontrakan_availability($conn, $bookingId, $makeAvailable = false) {
    debug_log("Updating kontrakan availability for booking ID: $bookingId, make available: " . ($makeAvailable ? "Yes" : "No"));

    $query = "SELECT id_kontrakan FROM booking WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $bookingId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $booking = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$booking) {
        debug_log("No booking found with ID: $bookingId");
        return false;
    }

    $kontrakanId = $booking['id_kontrakan'];
    $newStatus = $makeAvailable ? 'tersedia' : 'tidak tersedia';

    $updateQuery = "UPDATE data_kontrakan SET status = ? WHERE id = ?";
    $updateStmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($updateStmt, "si", $newStatus, $kontrakanId);
    $success = mysqli_stmt_execute($updateStmt);
    mysqli_stmt_close($updateStmt);

    debug_log("Kontrakan status update result: " . ($success ? "Success" : "Failed"));
    return $success;
}

// Validate request - all validation code must come before any potential output
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
    exit();
}

if (!isset($_POST['id']) || !isset($_POST['status'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Missing required parameters'
    ]);
    exit();
}

$bookingId = (int) $_POST['id'];
$status = $_POST['status'];
$keterangan = isset($_POST['keterangan']) ? $_POST['keterangan'] : '';

if ($bookingId <= 0) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid booking ID'
    ]);
    exit();
}

if (!is_valid_status($status)) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid status value'
    ]);
    exit();
}

// Process the request and ensure no HTML is output
try {
    debug_log("Executing update_booking_status.php");
    debug_log("Parameters: ID=$bookingId, Status=$status, Notes=$keterangan");

    // Verify required database tables exist
    $tables = ['booking', 'pengguna', 'penyewaan', 'pembayaran', 'data_kontrakan'];
    $missingTables = [];
    
    foreach ($tables as $table) {
        $tableCheck = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
        if (!$tableCheck) {
            debug_log("Error checking table $table: " . mysqli_error($conn));
            throw new Exception("Database connection error");
        }
        if (mysqli_num_rows($tableCheck) == 0) {
            $missingTables[] = $table;
        }
    }
    
    if (!empty($missingTables)) {
        debug_log("Error: Missing required tables: " . implode(", ", $missingTables));
        throw new Exception("Database configuration error. Contact administrator.");
    }

    // Check for booking data before updating
    $bookingCheck = mysqli_prepare($conn, "SELECT id, id_penyewa, id_kontrakan FROM booking WHERE id = ?");
    if (!$bookingCheck) {
        debug_log("Error preparing booking check: " . mysqli_error($conn));
        throw new Exception("Database query error");
    }
    
    mysqli_stmt_bind_param($bookingCheck, "i", $bookingId);
    mysqli_stmt_execute($bookingCheck);
    mysqli_stmt_store_result($bookingCheck);
    
    if (mysqli_stmt_num_rows($bookingCheck) == 0) {
        mysqli_stmt_close($bookingCheck);
        debug_log("Error: Booking ID $bookingId not found");
        throw new Exception("Booking ID tidak ditemukan");
    }
    mysqli_stmt_close($bookingCheck);

    $result = update_booking_status($conn, $bookingId, $status, $keterangan);

    // Ensure we only output valid JSON, nothing else
    header('Content-Type: application/json');
    
    if ($result) {
        $_SESSION['toast_message'] = "Status booking berhasil diperbarui";
        $_SESSION['toast_type'] = "success";

        echo json_encode([
            'status' => 'success',
            'message' => 'Status booking berhasil diperbarui'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Gagal memperbarui status booking'
        ]);
    }
} catch (Exception $e) {
    debug_log("General error: " . $e->getMessage());
    
    // Make sure this is the only output
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Terjadi kesalahan: ' . $e->getMessage()
    ]);
}
?>