<?php
/**
 * toast_messages.php - Handle toast messages from session
 * Include this file at the top of your page to add toast message functionality
 */

// Function to create hidden input fields for session messages
function get_toast_message_input() {
    $message = '';
    $message_type = 'info';
    
    // Check for toast message in session
    if (isset($_SESSION['toast_message']) && !empty($_SESSION['toast_message'])) {
        $message = $_SESSION['toast_message'];
        
        if (isset($_SESSION['toast_type']) && !empty($_SESSION['toast_type'])) {
            $message_type = $_SESSION['toast_type'];
        }
        
        // Clear session message after retrieving
        unset($_SESSION['toast_message']);
        unset($_SESSION['toast_type']);
    }
    
    // Create hidden input elements
    $html = '
    <!-- Hidden inputs for toast messages -->
    <input type="hidden" id="session-message" value="' . htmlspecialchars($message) . '">
    <input type="hidden" id="session-message-type" value="' . htmlspecialchars($message_type) . '">
    ';
    
    return $html;
}

/**
 * Set toast message in session
 * @param string $message - Message to display
 * @param string $type - Message type (success, error, warning, info)
 */
function set_toast_message($message, $type = 'info') {
    $_SESSION['toast_message'] = $message;
    $_SESSION['toast_type'] = $type;
}

/**
 * Display SweetAlert toast based on session
 * This function can be called directly to show a toast
 * @param string $message - Message to display
 * @param string $type - Message type (success, error, warning, info)
 */
function show_toast($message, $type = 'info') {
    echo '<script>
    document.addEventListener("DOMContentLoaded", function() {
        Swal.fire({
            title: "",
            text: "' . addslashes($message) . '",
            icon: "' . $type . '",
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true
        });
    });
    </script>';
}
?>