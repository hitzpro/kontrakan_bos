<?php
// Include database connection
require_once '../config/db.php';

// Query to get all sewa data with related information
$query = "SELECT 
            p.id,
            p.id_booking,
            p.id_penyewa,
            p.id_kontrakan,
            p.tanggal_mulai,
            p.tanggal_selesai,
            p.durasi_sewa,
            p.harga_sewa,
            p.total_bayar,
            p.metode_pembayaran,
            p.bukti_pembayaran,
            p.status_pembayaran,
            p.status_sewa,
            p.keterangan,
            k.nama_kontrakan,
            k.lokasi,
            k.alamat_lengkap,
            k.tipe_kontrakan,
            u.nama_pengguna as nama_penyewa
          FROM 
            penyewaan p
          JOIN 
            data_kontrakan k ON p.id_kontrakan = k.id
          JOIN 
            pengguna u ON p.id_penyewa = u.id
          ORDER BY 
            p.id DESC";

$result = mysqli_query($conn, $query);

// Check if query was successful
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

// Fetch all rows as an associative array
$sewaData = [];
while ($row = mysqli_fetch_assoc($result)) {
    $sewaData[] = $row;
}

// Close the connection
mysqli_close($conn);

// Output the data as a JavaScript variable
echo '<script>
    const initialSewaData = ' . json_encode($sewaData) . ';
</script>';
?>