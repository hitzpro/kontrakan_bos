<?php
/**
 * get_booking_detail.php - API endpoint to get specific booking details
 * Returns JSON data of a single booking with complete penyewa and kontrakan details
 */

// Start the session
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_user_id'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized access'
    ]);
    exit();
}

// Include database connection
require_once '../../config/db.php'; // pastikan $conn adalah mysqli

// Debug function to log process
function debug_log($message) {
    if (is_array($message) || is_object($message)) {
        error_log(print_r($message, true));
    } else {
        error_log($message);
    }
}

/**
 * Get booking detail by ID
 * @param mysqli $conn - Database connection
 * @param int $bookingId - Booking ID
 * @return array|null - Booking details or null if not found
 */
function get_booking_detail($conn, $bookingId) {
    debug_log("Starting get_booking_detail function for booking ID: " . $bookingId);

    $query = "
        SELECT 
            b.id, 
            b.id_penyewa, 
            b.id_kontrakan, 
            b.tanggal_booking, 
            b.tanggal_mulai, 
            b.tanggal_selesai, 
            b.total_bayar, 
            b.metode_pembayaran, 
            b.bukti_pembayaran, 
            b.status_booking, 
            b.keterangan,
            p.nama_pengguna AS nama_penyewa,
            p.email AS email_penyewa,
            p.no_telepon AS no_telepon_penyewa,
            k.nama_kontrakan,
            k.lokasi,
            k.alamat_lengkap,
            k.harga,
            k.fasilitas,
            k.luas,
            k.tipe_kontrakan,
            k.kontak_pemilik
        FROM booking b
        LEFT JOIN pengguna p ON b.id_penyewa = p.id
        LEFT JOIN data_kontrakan k ON b.id_kontrakan = k.id
        WHERE b.id = ?
    ";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        debug_log("Prepare failed: " . $conn->error);
        return null;
    }

    $stmt->bind_param("i", $bookingId);

    if (!$stmt->execute()) {
        debug_log("Execute failed: " . $stmt->error);
        return null;
    }

    $result = $stmt->get_result();
    $booking = $result->fetch_assoc();

    if (!$booking) {
        debug_log("No booking found with ID: " . $bookingId);
        return null;
    }

    // Parse facilities if exists
    if (!empty($booking['fasilitas'])) {
        $booking['fasilitas_list'] = explode(',', $booking['fasilitas']);
    } else {
        $booking['fasilitas_list'] = [];
    }

    return $booking;
}

// Validate and get booking ID
$bookingId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($bookingId <= 0) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid booking ID'
    ]);
    exit();
}

// Main execution
try {
    debug_log("Executing get_booking_detail.php for ID: " . $bookingId);

    // Get booking details
    $booking = get_booking_detail($conn, $bookingId);

    if ($booking) {
        // Send JSON response
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'success',
            'booking' => $booking
        ]);
    } else {
        // Send error response
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'error',
            'message' => 'Booking tidak ditemukan'
        ]);
    }

} catch (Exception $e) {
    debug_log("General error: " . $e->getMessage());

    // Send error response
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Terjadi kesalahan: ' . $e->getMessage()
    ]);
}
?>
