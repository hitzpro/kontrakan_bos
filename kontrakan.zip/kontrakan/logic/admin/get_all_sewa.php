<?php
// Include database connection
require_once '../../config/db.php';

// Set header as JSON
header('Content-Type: application/json');

// Check if user is logged in and is admin (implement based on your authentication system)
// session_start();
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
//     echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
//     exit;
// }

try {
    // Prepare SQL query
    $sql = "SELECT p.*, 
            dk.nama_kontrakan, dk.lokasi, dk.alamat_lengkap, dk.tipe_kontrakan,
            pg.nama_pengguna as nama_penyewa
            FROM penyewaan p
            LEFT JOIN data_kontrakan dk ON p.id_kontrakan = dk.id
            LEFT JOIN pengguna pg ON p.id_penyewa = pg.id
            ORDER BY p.id DESC";
            
    $result = mysqli_query($conn, $sql);
    
    if (!$result) {
        throw new Exception(mysqli_error($conn));
    }
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        // Format data if needed
        $row['harga_sewa'] = (float) $row['harga_sewa'];
        $row['total_bayar'] = (float) $row['total_bayar'];
        
        $data[] = $row;
    }
    
    echo json_encode([
        'status' => 'success',
        'data' => $data
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal memuat data: ' . $e->getMessage()
    ]);
}

// Close connection
mysqli_close($conn);
?>