<?php
// Include database connection
header('Content-Type: application/json');

// Make sure no output is sent before headers
include_once '../../config/db.php';
session_start();

// Error handling to catch any PHP errors and return them as JSON
function handleError($errno, $errstr, $errfile, $errline) {
    echo json_encode([
        'success' => false, 
        'message' => "PHP Error: $errstr in $errfile on line $errline"
    ]);
    exit;
}
set_error_handler('handleError');

try {
    // Pastikan request adalah POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Metode request tidak valid']);
        exit;
    }

    // Validasi input
    if (!isset($_POST['id']) || empty($_POST['id']) || !isset($_POST['status']) || empty($_POST['status'])) {
        echo json_encode(['success' => false, 'message' => 'Parameter tidak lengkap']);
        exit;
    }

    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Validasi status
    $allowedStatuses = ['aktif', 'selesai', 'dibatalkan'];
    if (!in_array($status, $allowedStatuses)) {
        echo json_encode(['success' => false, 'message' => 'Status tidak valid']);
        exit;
    }

    // Dapatkan informasi penyewaan saat ini
    $checkQuery = "SELECT 
        p.status_sewa, 
        p.id_kontrakan, 
        p.id_penyewa, 
        p.total_bayar, 
        p.metode_pembayaran,
        k.nama_kontrakan AS nama_kontrakan, 
        u.nama_pengguna AS nama_user 
    FROM penyewaan p
    LEFT JOIN data_kontrakan k ON p.id_kontrakan = k.id
    LEFT JOIN pengguna u ON p.id_penyewa = u.id
    WHERE p.id = '$id'
    ";

    $checkResult = mysqli_query($conn, $checkQuery);

    if (!$checkResult) {
        throw new Exception("Database error: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($checkResult) == 0) {
        echo json_encode(['success' => false, 'message' => 'Data penyewaan tidak ditemukan']);
        exit;
    }

    $penyewaanData = mysqli_fetch_assoc($checkResult);
    $currentStatus = $penyewaanData['status_sewa'];

    // Validasi perpindahan status
    $validTransition = true;
    $errorMessage = '';

    if ($currentStatus == 'menunggu konfirmasi') {
        if (!in_array($status, ['aktif', 'dibatalkan'])) {
            $validTransition = false;
            $errorMessage = 'Perpindahan status tidak valid';
        }
    } elseif ($currentStatus == 'aktif') {
        if ($status != 'selesai') {
            $validTransition = false;
            $errorMessage = 'Penyewaan aktif hanya dapat diubah menjadi selesai';
        }
    } else {
        $validTransition = false;
        $errorMessage = 'Status saat ini tidak dapat diubah';
    }

    if (!$validTransition) {
        echo json_encode(['success' => false, 'message' => $errorMessage]);
        exit;
    }

    // Update status penyewaan
    $updateQuery = "UPDATE penyewaan SET status_sewa = '$status' WHERE id = '$id'";
    $updateResult = mysqli_query($conn, $updateQuery);

    if (!$updateResult) {
        throw new Exception("Database error: " . mysqli_error($conn));
    }

    // Jika status diubah menjadi "aktif", update status kontrakan menjadi "tidak tersedia" dan tambahkan data pembayaran
    if ($status == 'aktif') {
        $kontrakanId = $penyewaanData['id_kontrakan'];
        $namaUser = $penyewaanData['nama_user'];
        $namaKontrakan = $penyewaanData['nama_kontrakan'];
        $totalHarga = $penyewaanData['total_bayar'];
        
        // Update status kontrakan
        $updateKontrakanQuery = "UPDATE data_kontrakan SET status = 'tidak tersedia' WHERE id = '$kontrakanId'";
        $kontrakanResult = mysqli_query($conn, $updateKontrakanQuery);
        
        if (!$kontrakanResult) {
            throw new Exception("Error updating kontrakan status: " . mysqli_error($conn));
        }
        
        // Update status pembayaran menjadi lunas
        $updatePembayaranStatusQuery = "UPDATE penyewaan SET status_pembayaran = 'lunas' WHERE id = '$id'";
        $pembayaranStatusResult = mysqli_query($conn, $updatePembayaranStatusQuery);
        
        if (!$pembayaranStatusResult) {
            throw new Exception("Error updating payment status: " . mysqli_error($conn));
        }
        
        // Insert data pembayaran
        $keterangan = "Hasil dari penyewaan $namaUser untuk $namaKontrakan";
        $metode = $penyewaanData['metode_pembayaran'];

        $insertPembayaranQuery = "INSERT INTO pembayaran (id_penyewaan, jumlah, metode, keterangan) 
                                VALUES ('$id', '$totalHarga', '$metode', '$keterangan')";
        
        $pembayaranResult = mysqli_query($conn, $insertPembayaranQuery);
        
        if (!$pembayaranResult) {
            throw new Exception("Error inserting payment data: " . mysqli_error($conn));
        }
    }
    
    // Jika status diubah menjadi "selesai", update status kontrakan menjadi "tersedia"
    elseif ($status == 'selesai') {
        $kontrakanId = $penyewaanData['id_kontrakan'];
        
        $updateKontrakanQuery = "UPDATE data_kontrakan SET status = 'tersedia' WHERE id = '$kontrakanId'";
        $kontrakanResult = mysqli_query($conn, $updateKontrakanQuery);
        
        if (!$kontrakanResult) {
            throw new Exception("Error updating kontrakan status: " . mysqli_error($conn));
        }
    }
    
    $statusMessages = [
        'aktif' => 'Penyewaan berhasil dikonfirmasi',
        'selesai' => 'Penyewaan berhasil diselesaikan',
        'dibatalkan' => 'Penyewaan berhasil dibatalkan'
    ];
    
    echo json_encode(['success' => true, 'message' => $statusMessages[$status]]);

} catch (Exception $e) {
    // Return any exceptions as JSON
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}