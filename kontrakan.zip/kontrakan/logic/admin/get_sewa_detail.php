<?php
// Include database connection
require_once '../../config/db.php';

// Set header as JSON
header('Content-Type: application/json');

// Check if user is logged in and is admin (implement based on your authentication system)
// session_start();
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
//     echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
//     exit;
// }

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['status' => 'error', 'message' => 'ID tidak diberikan']);
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

try {
    // Prepare SQL query
    $sql = "SELECT p.*, 
            dk.nama_kontrakan, dk.lokasi, dk.alamat_lengkap, dk.tipe_kontrakan,
            pg.nama_pengguna as nama_penyewa
            FROM penyewaan p
            LEFT JOIN data_kontrakan dk ON p.id_kontrakan = dk.id
            LEFT JOIN pengguna pg ON p.id_penyewa = pg.id
            WHERE p.id = '$id'";
            
    $result = mysqli_query($conn, $sql);
    
    if (!$result) {
        throw new Exception(mysqli_error($conn));
    }
    
    if (mysqli_num_rows($result) === 0) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak ditemukan']);
        exit;
    }
    
    $data = mysqli_fetch_assoc($result);
    
    // Format data if needed
    $data['harga_sewa'] = (float) $data['harga_sewa'];
    $data['total_bayar'] = (float) $data['total_bayar'];
    
    echo json_encode([
        'status' => 'success',
        'data' => $data
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal memuat data: ' . $e->getMessage()
    ]);
}

// Close connection
mysqli_close($conn);
?>