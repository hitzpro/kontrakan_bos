<?php
session_start();

if (!isset($_SESSION['admin_user_id'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized access'
    ]);
    exit();
}

// Include MySQLi DB connection
require_once '../../config/db.php';

// Debug function
function debug_log($message) {
    error_log(is_array($message) || is_object($message) ? print_r($message, true) : $message);
}

function get_all_bookings($conn) {
    debug_log("Starting get_all_bookings function");

    $query = "
        SELECT 
            b.id, 
            b.id_penyewa, 
            b.id_kontrakan, 
            b.tanggal_booking, 
            b.tanggal_mulai, 
            b.tanggal_selesai, 
            b.total_bayar, 
            b.metode_pembayaran, 
            b.bukti_pembayaran, 
            b.status_booking, 
            b.keterangan,
            p.nama_pengguna AS nama_penyewa,
            p.email,
            p.no_telepon,
            k.nama_kontrakan,
            k.lokasi,
            k.alamat_lengkap,
            k.harga,
            k.kontak_pemilik
        FROM booking b
        LEFT JOIN pengguna p ON b.id_penyewa = p.id
        LEFT JOIN data_kontrakan k ON b.id_kontrakan = k.id
        ORDER BY b.tanggal_booking DESC
    ";

    $result = $conn->query($query);

    if (!$result) {
        debug_log("Database error: " . $conn->error);
        return [];
    }

    $bookings = [];
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }

    return $bookings;
}

try {
    debug_log("Executing get_bookings.php");

    $bookings = get_all_bookings($conn);

    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'success',
        'bookings' => $bookings
    ]);

} catch (Exception $e) {
    debug_log("General error: " . $e->getMessage());

    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Terjadi kesalahan: ' . $e->getMessage()
    ]);
}
