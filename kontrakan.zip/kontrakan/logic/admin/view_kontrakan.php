<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Include database connection
require_once '../../config/db.php';
header('Content-Type: application/json');


// // Check if user is authorized
// session_start();
// if (!isset($_SESSION['admin_id'])) {
//     echo json_encode([
//         'status' => 'error',
//         'message' => 'Unauthorized access'
//     ]);
//     exit;
// }

// Get action parameter
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Handle different actions
switch ($action) {
    case 'get_kontrakan':
        getKontrakanDetail($conn);
        break;
    default:
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid action'
        ]);
        break;
}

/**
 * Get detailed information about a specific kontrakan
 * @param mysqli $conn Database connection
 */
function getKontrakanDetail($conn) {
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo json_encode([
            'status' => 'error',
            'message' => 'ID kontrakan tidak ditemukan'
        ]);
        return;
    }

    $id = mysqli_real_escape_string($conn, $_GET['id']);

    $query = "SELECT * FROM data_kontrakan WHERE id = '$id'";
    $result = mysqli_query($conn, $query);

    if (!$result || mysqli_num_rows($result) == 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Kontrakan tidak ditemukan'
        ]);
        return;
    }

    $kontrakan = mysqli_fetch_assoc($result);

    // Ambil foto tambahan
    $fotos = [];
    $fotoQuery = mysqli_query($conn, "SELECT foto FROM foto_kontrakan WHERE id_kontrakan = '$id'");
    while ($row = mysqli_fetch_assoc($fotoQuery)) {
        $fotos[] = $row['foto'];
    }

    // Tambahkan ke hasil
    $kontrakan['foto_lain'] = $fotos;

    echo json_encode([
        'status' => 'success',
        'data' => $kontrakan
    ]);
}

?>