<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Include database connection
require_once '../../config/db.php';
header('Content-Type: application/json');


// // Check if user is authorized
// session_start();
// if (!isset($_SESSION['admin_id'])) {
//     echo json_encode([
//         'status' => 'error',
//         'message' => 'Unauthorized access'
//     ]);
//     exit;
// }

// Get action parameter
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Handle different actions
switch ($action) {
    case 'get_kontrakan':
        getKontrakanDetail($conn);
        break;
    default:
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid action'
        ]);
        break;
}

/**
 * Get detailed information about a specific kontrakan
 * @param mysqli $conn Database connection
 */
function getKontrakanDetail($conn) {
    // Check if ID is provided
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo json_encode([
            'status' => 'error',
            'message' => 'ID kontrakan tidak ditemukan'
        ]);
        return;
    }

    $id = mysqli_real_escape_string($conn, $_GET['id']);
    
    // Query to get kontrakan details directly from data_kontrakan table
    $query = "SELECT * FROM data_kontrakan WHERE id = '$id'";
    
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Database error: ' . mysqli_error($conn)
        ]);
        return;
    }
    
    if (mysqli_num_rows($result) > 0) {
        $kontrakan = mysqli_fetch_assoc($result);
        
        // Return kontrakan details as JSON
        echo json_encode([
            'status' => 'success',
            'data' => $kontrakan
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Kontrakan tidak ditemukan'
        ]);
    }
}
?>