<?php
session_start();
require_once "../../config/db.php";
header('Content-Type: application/json');

// Debug log
error_log("🔍 REUPLOAD NOTIFICATION: POST data received: " . print_r($_POST, true));

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rentalId = mysqli_real_escape_string($conn, $_POST["rental_id"]);
    $namaPenyewa = mysqli_real_escape_string($conn, $_POST["nama_penyewa"]);
    $namaKontrakan = mysqli_real_escape_string($conn, $_POST["nama_kontrakan"]);

    // Cek apakah data penyewaan valid dan pakai metode transfer
    $query = "SELECT * FROM penyewaan WHERE id = '$rentalId' AND metode_pembayaran = 'transfer'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        echo json_encode([
            "success" => false,
            "message" => "Gagal mengambil data penyewaan.",
            "query" => $query
        ]);
        exit;
    }

    if (mysqli_num_rows($result) === 0) {
        echo json_encode([
            "success" => false,
            "message" => "Data penyewaan tidak ditemukan atau tidak menggunakan metode transfer."
        ]);
        exit;
    }

    // Kirim notifikasi (bisa jadi via sistem notifikasi internal, email, atau cukup update status db)
    // Misalnya kita update kolom `keterangan` untuk menandai diminta upload ulang
    $pesan = "Silakan upload ulang bukti pembayaran untuk kontrakan $namaKontrakan dengan ID penyewaan #$rentalId.";
    $updateQuery = "UPDATE penyewaan SET keterangan = '$pesan' WHERE id = '$rentalId'";

    if (mysqli_query($conn, $updateQuery)) {
        echo json_encode([
            "success" => true,
            "message" => "Notifikasi berhasil dikirim dan keterangan diperbarui."
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Gagal mengirim notifikasi atau update keterangan.",
            "query" => $updateQuery
        ]);
    }
} else {
    echo json_encode([
        "success" => false,
        "message" => "Metode request tidak diizinkan."
    ]);
}
?>
