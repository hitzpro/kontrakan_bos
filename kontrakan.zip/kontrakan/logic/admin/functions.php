<?php
/**
 * Perpanjangan Sewa Admin Backend
 * Functions to handle perpanjangan sewa management
 */

// Include database configuration if not already included
if (!isset($conn)) {
    require_once '../config/db.php';
}

/**
 * Fetch perpanjangan sewa data with pagination and search
 * @param mysqli $conn Database connection
 * @return void Outputs JSON response directly
 */
function getPerpanjanganData($conn) {
    // Get pagination and search parameters
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $offset = ($page - 1) * $limit;
    
    // Base query for data with joins
    $query = "SELECT ps.*, dk.nama_kontrakan, p.nama_pengguna as nama_penyewa
              FROM perpanjangan_sewa ps
              JOIN data_kontrakan dk ON ps.id_kontrakan = dk.id
              JOIN pengguna p ON ps.id_penyewa = p.id";
    
    // Add search condition if provided
    if (!empty($search)) {
        $search = "%$search%";
        $query .= " WHERE p.nama_pengguna LIKE ? OR dk.nama_kontrakan LIKE ? OR ps.status LIKE ?";
        $countQuery = "SELECT COUNT(*) as total FROM perpanjangan_sewa ps 
                      JOIN data_kontrakan dk ON ps.id_kontrakan = dk.id
                      JOIN pengguna p ON ps.id_penyewa = p.id
                      WHERE p.nama_pengguna LIKE ? OR dk.nama_kontrakan LIKE ? OR ps.status LIKE ?";
        
        // Prepare count statement
        $countStmt = $conn->prepare($countQuery);
        $countStmt->bind_param("sss", $search, $search, $search);
    } else {
        $countQuery = "SELECT COUNT(*) as total FROM perpanjangan_sewa";
        $countStmt = $conn->prepare($countQuery);
    }
    
    // Get total records for pagination
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $totalRows = $countResult->fetch_assoc()['total'];
    $totalPages = ceil($totalRows / $limit);
    
    // Add pagination to the query
    $query .= " ORDER BY ps.tanggal_pengajuan DESC LIMIT ? OFFSET ?";
    
    // Prepare and execute the query
    $stmt = $conn->prepare($query);
    
    if (!empty($search)) {
        $stmt->bind_param("sssii", $search, $search, $search, $limit, $offset);
    } else {
        $stmt->bind_param("ii", $limit, $offset);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Fetch all data rows
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    
    // Return JSON response
    echo json_encode([
        'status' => 'success',
        'data' => $data,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total_rows' => $totalRows,
            'total_pages' => $totalPages
        ]
    ]);
}

/**
 * Update perpanjangan sewa status (approve or reject)
 * @param mysqli $conn Database connection
 * @return void Outputs JSON response directly
 */
function updatePerpanjanganStatus($conn) {
    // Check required parameters
    if (!isset($_POST['id']) || !isset($_POST['status'])) {
        echo json_encode(['status' => 'error', 'message' => 'Parameter yang diperlukan tidak lengkap']);
        return;
    }
    
    // Get and validate parameters
    $id = intval($_POST['id']);
    $status = $_POST['status'];
    
    // Validate status value
    $allowedStatuses = ['disetujui', 'ditolak'];
    if (!in_array($status, $allowedStatuses)) {
        echo json_encode(['status' => 'error', 'message' => 'Nilai status tidak valid']);
        return;
    }
    
    // Begin transaction
    $conn->begin_transaction();
    
    try {
        // Update the status
        $query = "UPDATE perpanjangan_sewa SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("si", $status, $id);
        $stmt->execute();
        
        // If approved, update related tables or perform additional actions
        if ($status === 'disetujui') {
            // Get perpanjangan data
            $getPerpanjangan = "SELECT * FROM perpanjangan_sewa WHERE id = ?";
            $stmtGet = $conn->prepare($getPerpanjangan);
            $stmtGet->bind_param("i", $id);
            $stmtGet->execute();
            $result = $stmtGet->get_result();
            $perpanjangan = $result->fetch_assoc();
            
            // Update the original penyewaan if there's an association
            if (isset($perpanjangan['id_penyewaan']) && $perpanjangan['id_penyewaan'] > 0) {
                $updatePenyewaan = "UPDATE penyewaan SET tanggal_selesai = ? WHERE id = ?";
                $stmtUpdate = $conn->prepare($updatePenyewaan);
                $stmtUpdate->bind_param("si", $perpanjangan['tanggal_selesai'], $perpanjangan['id_penyewaan']);
                $stmtUpdate->execute();
                
                // You might also want to update the kontrakan status or availability
            }
        }
        
        // Commit the transaction
        $conn->commit();
        
        // Return success response
        echo json_encode([
            'status' => 'success', 
            'message' => $status === 'disetujui' ? 'Perpanjangan berhasil disetujui' : 'Perpanjangan berhasil ditolak'
        ]);
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui status: ' . $e->getMessage()]);
    }
}