<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include '../../config/db.php'; // Pastikan koneksi database sudah benar

header('Content-Type: application/json');

if (isset($_GET['action']) && $_GET['action'] === 'get_kontrakan' && isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk mengambil data kontrakan berdasarkan id
    $query = "SELECT * FROM data_kontrakan WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $kontrakan = $result->fetch_assoc();
        // Mengembalikan status success dan data kontrakan
        echo json_encode([
            'status' => 'success',
            'data' => $kontrakan
        ]);
    } else {
        // Data tidak ditemukan
        echo json_encode([
            'status' => 'error',
            'message' => 'Kontrakan tidak ditemukan'
        ]);
    }

    $stmt->close();
    $conn->close();
} else {
    // Parameter tidak valid
    echo json_encode([
        'status' => 'error',
        'message' => 'Request tidak valid'
    ]);
}
?>
