<?php
// Include database connection
include_once '../../config/db.php';

// Pastikan request memiliki ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID penyewaan tidak valid']);
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

// Query untuk mendapatkan detail penyewaan
$query = "SELECT p.*, dk.nama_kontrakan, pg.nama_pengguna 
          FROM penyewaan p
          LEFT JOIN data_kontrakan dk ON p.id_kontrakan = dk.id
          LEFT JOIN pengguna pg ON p.id_penyewa = pg.id
          WHERE p.id = '$id'";

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    $rental = mysqli_fetch_assoc($result);
    echo json_encode(['success' => true, 'rental' => $rental]);
} else {
    echo json_encode(['success' => false, 'message' => 'Data penyewaan tidak ditemukan']);
}