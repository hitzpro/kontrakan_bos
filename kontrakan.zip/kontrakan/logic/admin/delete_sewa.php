<?php
// Include database connection
require_once '../../config/db.php';

// Set header as JSON
header('Content-Type: application/json');

// Check if user is logged in and is admin (implement based on your authentication system)
// session_start();
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
//     echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
//     exit;
// }

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Metode request tidak valid']);
    exit;
}

// Check if ID is provided
if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode(['status' => 'error', 'message' => 'ID tidak diberikan']);
    exit;
}

$id = mysqli_real_escape_string($conn, $_POST['id']);

// Start transaction
mysqli_begin_transaction($conn);

try {
    // First, check if the record exists
    $checkSql = "SELECT id FROM penyewaan WHERE id = '$id'";
    $checkResult = mysqli_query($conn, $checkSql);
    
    if (!$checkResult || mysqli_num_rows($checkResult) === 0) {
        throw new Exception('Data tidak ditemukan');
    }
    
    // Delete the record
    $sql = "DELETE FROM penyewaan WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
    
    if (!$result) {
        throw new Exception(mysqli_error($conn));
    }
    
    // Commit transaction
    mysqli_commit($conn);
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Data berhasil dihapus'
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    mysqli_rollback($conn);
    
    echo json_encode([
        'status' => 'error',
        'message' => 'Gagal menghapus data: ' . $e->getMessage()
    ]);
}

// Close connection
mysqli_close($conn);
?>