<?php
include('config/db.php');

echo date_default_timezone_get() . "<br>";
echo date('Y-m-d H:i:s');
